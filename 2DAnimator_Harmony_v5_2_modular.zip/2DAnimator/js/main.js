/**
 * Arranque: pantalla de inicio (resolución / borrador), tema, herramienta inicial y API pública window.A2D para los módulos de funciones.
 */
"use strict";
try {
  theme(localStorage.getItem("2dTheme") || "dark");
} catch (_) {
  theme("dark");
}
setTool("select");
syncLabels();
tl();
requestAnimationFrame(fit);
window.A2D = {
  S,
  F,
  L,
  owner,
  uid,
  clone,
  num,
  hint,
  pts,
  resample,
  closedPoly,
  pushUndo,
  dirty,
  all,
  render,
  tl,
  go,
  msel,
  EASE,
  pt,
  setTool,
  bezE,
  trAt,
  pivotOf,
  rigAt,
  rigApply,
  rigChain,
  cleanRig,
  ext: {},
};
openStart(true); // pantalla de inicio: resolución, borrador automático o abrir proyecto
