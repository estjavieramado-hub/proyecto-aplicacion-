/**
 * Exportación: descarga de archivos, guardado, PNG, SVG y tamaño del lienzo.
 */
"use strict";
const download = (blob, name) => {
  const a = document.createElement("a"),
    u = URL.createObjectURL(blob);
  a.href = u;
  a.download = name;
  a.click();
  setTimeout(() => URL.revokeObjectURL(u), 1000);
};
const fname = () => (S.name === "Sin título" ? "MiAnimacion" : S.name);
function save() {
  download(new Blob([JSON.stringify(proj(), null, 2)], { type: "application/json" }), fname() + ".2da.json");
  S.dirty = false;
  $("saveStatus").textContent = "Proyecto descargado";
}
function png() {
  const o = document.createElement("canvas");
  o.width = S.width;
  o.height = S.height;
  const c = o.getContext("2d");
  c.fillStyle = "#fff";
  c.fillRect(0, 0, o.width, o.height);
  drawStrokes(c, F().strokes);
  o.toBlob((b) => download(b, `fotograma-${S.f + 1}.png`));
}
function svgOf(s) {
  const p = pts(s),
    o = s.opacity * (BR[s.brush]?.al ?? 1),
    f = (v) => v.toFixed(1),
    P = (a) => a.map((q) => f(q.x) + "," + f(q.y)).join(" ");
  if (s.kind === "fill") return `<polygon points="${P(p)}" fill="${s.color}" opacity="${o}"/>`;
  if (isRib(s, p)) {
    const r = ribbon(p, s);
    return (
      `<polygon points="${P(r.poly)}" fill="${s.color}" opacity="${o}"/>` +
      r.caps
        .map(
          ([x, y, rr]) => `<circle cx="${f(x)}" cy="${f(y)}" r="${f(rr)}" fill="${s.color}" opacity="${o}"/>`
        )
        .join("")
    );
  }
  const t = [];
  if (bezSvg(s, t)) return t[0];
  return p.length === 1
    ? `<circle cx="${p[0].x}" cy="${p[0].y}" r="${s.size / 2}" fill="${s.color}" opacity="${o}"/>`
    : `<polyline points="${P(p)}" fill="none" stroke="${s.color}" stroke-width="${s.size}" stroke-linecap="round" stroke-linejoin="round" opacity="${o}"/>`;
}
function svg() {
  const el = [];
  if (S.layers.some((l) => l.mode) || F().strokes.some((t) => BR[t.brush]?.grain || BR[t.brush]?.soft))
    hint("Aviso: máscaras, recortes, grano y desenfoque no se exportan a SVG (usa PNG).");
  S.layers.forEach((l) => {
    if (l.visible && l.mode !== "mask") {
      const g = [];
      F().strokes.forEach((s) => {
        if (owner(s) === l) g.push(svgOf(s));
      });
      if (g.length) el.push(svgGroup(l, S.f, g));
    }
  });
  download(
    new Blob(
      [
        `<svg xmlns="http://www.w3.org/2000/svg" width="${S.width}" height="${S.height}" viewBox="0 0 ${S.width} ${S.height}"><rect width="100%" height="100%" fill="white"/>${el.join("\n")}</svg>`,
      ],
      { type: "image/svg+xml" }
    ),
    `fotograma-${S.f + 1}.svg`
  );
}
function sizeCanvas() {
  [cv, ov].forEach((c) => {
    c.width = S.width;
    c.height = S.height;
    c.style.width = S.width + "px";
    c.style.height = S.height + "px";
  });
  const p = $("paper");
  p.style.width = S.width + "px";
  p.style.height = S.height + "px";
}
