/**
 * Cargar, crear y abrir proyectos; renombrar proyecto.
 */
"use strict";
function load(d) {
  const v = validateProject(d);
  if (S.playing) stop();
  S.name = v.name;
  S.width = v.width;
  S.height = v.height;
  S.fps = v.fps;
  S.keyCol = v.keyCol;
  S.inbCol = v.inbCol;
  S.groups = v.groups;
  S.layers = v.layers;
  S.frames = v.frames;
  S.f = 0;
  S.l = S.layers.length - 1;
  S.sel = null;
  S.rng = null;
  S.pen = null;
  S.cur = null;
  S.undo = [];
  S.redo = [];
  S.dirty = false;
  S.rig = v.rig || null;
  S.curve = v.curve || [0.42, 0, 0.58, 1];
  S.ref = null;
  if (v.ref) setRef(v.ref.src, v.ref.op);
  window.A2D && A2D.ext.onLoad && A2D.ext.onLoad();
  sizeCanvas();
  $("fpsInput").value = S.fps;
  $("keyCol").value = S.keyCol;
  $("inbCol").value = S.inbCol;
  $("projectNameLabel").textContent = S.name;
  fit();
  tl();
}
function newProj() {
  openStart(false); // diálogo de resoluciones (js/ui/start-dialog.js)
}
$("projectFileInput").onchange = async (e) => {
  const f = e.target.files[0];
  if (!f) return;
  try {
    if (f.size > 2e8) throw Error("El archivo es demasiado grande.");
    const d = JSON.parse(await f.text());
    if (d.format !== "2DAnimatorProject") throw Error("Formato de proyecto no reconocido");
    load(d);
    $("saveStatus").textContent = "Proyecto abierto";
  } catch (err) {
    alert("No se pudo abrir el proyecto: " + err.message);
  }
  e.target.value = "";
};
$("projectNameLabel").ondblclick = () => {
  const v = prompt("Nombre del proyecto", S.name);
  if (v && v.trim()) {
    S.name = v.trim().slice(0, 60);
    $("projectNameLabel").textContent = S.name;
    dirty();
  }
};
