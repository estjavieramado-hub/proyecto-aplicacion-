/**
 * Validación y saneado de proyectos (rig, pistas, capas, grupos, fotogramas) al abrir archivos.
 */
"use strict";
const cleanRk = (K) => {
  if (!Array.isArray(K)) return undefined;
  const seen = new Set(),
    o = [];
  K.forEach((k) => {
    if (!k || !Number.isFinite(+k.f)) return;
    const f = Math.round(num(k.f, 0, 0, 5000));
    if (seen.has(f)) return;
    seen.add(f);
    o.push({
      f,
      r: num(k.r, 0, -3600, 3600),
      c:
        Array.isArray(k.c) && k.c.length === 4 && k.c.every(Number.isFinite)
          ? k.c.map((v, i) => num(v, 0, i % 2 ? -1 : 0, i % 2 ? 2 : 1))
          : undefined,
    });
  });
  return o.length ? o.sort((a, b) => a.f - b.f) : undefined;
};
const cleanRig = (r) => {
  if (!r || !Array.isArray(r.bones)) return null;
  const ids = new Set(),
    bs = [];
  r.bones.slice(0, 200).forEach((b) => {
    if (!b || typeof b.id !== "string" || !b.id || ids.has(b.id)) return;
    ids.add(b.id);
    bs.push({
      id: b.id,
      name: String(b.name || "Hueso").slice(0, 40),
      parent: typeof b.parent === "string" ? b.parent : undefined,
      x: num(b.x, 0, -1e5, 1e5),
      y: num(b.y, 0, -1e5, 1e5),
      len: num(b.len, 50, 1, 1e5),
      ang: num(b.ang, 0, -360, 360),
      mn: num(b.mn, -180, -360, 360),
      mx: num(b.mx, 180, -360, 360),
      rk: cleanRk(b.rk),
    });
  });
  if (!bs.length) return null;
  const by = new Map(bs.map((b) => [b.id, b]));
  bs.forEach((b) => {
    if (b.parent && !by.has(b.parent)) b.parent = undefined;
    let c = b,
      g = 0;
    while (c && c.parent && g++ < 300) c = by.get(c.parent);
    if (g >= 300) b.parent = undefined;
  });
  bs.forEach((b) => {
    if (b.mn > b.mx) [b.mn, b.mx] = [b.mx, b.mn];
  });
  return {
    bones: bs,
    poses: (Array.isArray(r.poses) ? r.poses : [])
      .filter((q) => q && typeof q === "object")
      .slice(0, 100)
      .map((q) => ({
        name: String(q.name || "Pose").slice(0, 40),
        a: Object.fromEntries(
          Object.entries(q.a && typeof q.a === "object" ? q.a : {})
            .filter(([k, v]) => ids.has(k) && Number.isFinite(+v))
            .map(([k, v]) => [k, num(v, 0, -720, 720)])
        ),
      })),
  };
};
const cleanTr = (K) => {
  if (!Array.isArray(K)) return undefined;
  const seen = new Set(),
    o = [];
  K.forEach((k) => {
    if (!k || typeof k !== "object" || !Number.isFinite(+k.f)) return;
    const f = Math.round(num(k.f, 0, 0, 5000));
    if (seen.has(f)) return;
    seen.add(f);
    const c = {};
    ["x", "y", "r", "s", "o"].forEach((q) => {
      const a = k.c && k.c[q];
      if (Array.isArray(a) && a.length === 4 && a.every(Number.isFinite))
        c[q] = a.map((v, i) => num(v, 0, i % 2 ? -1 : 0, i % 2 ? 2 : 1));
    });
    o.push({
      f,
      x: num(k.x, 0, -1e5, 1e5),
      y: num(k.y, 0, -1e5, 1e5),
      r: num(k.r, 0, -3600, 3600),
      s: num(k.s, 100, 1, 10000),
      o: num(k.o, 100, 0, 100),
      c: Object.keys(c).length ? c : undefined,
    });
  });
  return o.length ? o.sort((a, b) => a.f - b.f) : undefined;
};
function validateProject(d) {
  if (!d || typeof d !== "object" || Array.isArray(d) || d.format !== "2DAnimatorProject")
    throw Error("El archivo no es un proyecto de 2D Animator.");
  if (Array.isArray(d.frames) && d.frames.length > 5000) throw Error("Demasiados fotogramas (máximo 5000).");
  const gids = new Set(),
    lids = new Set();
  let groups = (Array.isArray(d.groups) ? d.groups : [])
    .filter((g) => g && typeof g.id === "string" && g.id && !gids.has(g.id) && gids.add(g.id))
    .map((g) => ({ id: g.id, name: String(g.name || "Grupo").slice(0, 40), open: g.open !== false }));
  let layers = (Array.isArray(d.layers) ? d.layers : [])
    .filter((l) => l && typeof l === "object")
    .map((l) => {
      const id = typeof l.id === "string" && l.id && !lids.has(l.id) ? l.id : uid();
      lids.add(id);
      return {
        id,
        name: String(l.name || "Capa").slice(0, 40),
        visible: l.visible !== false,
        locked: !!l.locked,
        g: gids.has(l.g) ? l.g : undefined,
        mode: ["clip", "mask"].includes(l.mode) ? l.mode : undefined,
        pv:
          Array.isArray(l.pv) && l.pv.length === 2 && l.pv.every(Number.isFinite)
            ? l.pv.map((v) => num(v, 0, -1e5, 1e5))
            : undefined,
        tr: cleanTr(l.tr),
        bone: typeof l.bone === "string" ? l.bone : undefined,
        color: HEX.test(l.color) ? l.color : undefined,
        op: l.op === undefined ? undefined : num(l.op, 1, 0.01, 1),
      };
    });
  if (!layers.length) {
    layers = animeLayers();
    groups = S.groups;
  }
  delete layers[0].mode;
  const rig = cleanRig(d.rig);
  layers.forEach((l) => {
    if (l.bone && !(rig && rig.bones.some((b) => b.id === l.bone))) delete l.bone;
  });
  const ids = layers.map((l) => l.id);
  return {
    name: String(d.name || "Proyecto").slice(0, 60),
    width: Math.round(num(d.width, 1280, 64, 8192)),
    height: Math.round(num(d.height, 720, 64, 8192)),
    fps: Math.round(num(d.fps, 24, 1, 60)),
    keyCol: HEX.test(d.keyCol) ? d.keyCol : "#f5a623",
    inbCol: HEX.test(d.inbCol) ? d.inbCol : "#4fc3a1",
    groups,
    layers,
    rig,
    curve:
      Array.isArray(d.curve) && d.curve.length === 4 && d.curve.every(Number.isFinite)
        ? d.curve.map((v, i) => num(v, 0, i % 2 ? -1 : 0, i % 2 ? 2 : 1))
        : null,
    ref:
      typeof d.ref?.src === "string" &&
      /^data:image\/(jpeg|png|webp);base64,/.test(d.ref.src) &&
      d.ref.src.length < 4e6
        ? { src: d.ref.src, op: num(d.ref.op, 0.4, 0.05, 1) }
        : null,
    frames: (Array.isArray(d.frames) && d.frames.length ? d.frames : [{}]).map((f) => ({
      id: typeof f?.id === "string" && f.id ? f.id : uid(),
      strokes: clean(f?.strokes, ids, ids[0]),
      exp: Math.round(num(f?.exp, 1, 1, 99)),
      mk: typeof f?.mk === "string" && f.mk ? f.mk.slice(0, 40) : undefined,
    })),
  };
}
