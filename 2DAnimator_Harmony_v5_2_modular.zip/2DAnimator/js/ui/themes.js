/**
 * Temas de color (Oscuro, Gris medio, Claro, Medianoche).
 */
"use strict";
const BASE = [
  0, 17, 26, 28, 29, 31, 34, 35, 38, 42, 43, 45, 51, 56, 58, 63, 68, 69, 70, 74, 76, 89, 143, 153, 154, 187,
  208, 221, 230, 232, 255,
];
const THEMES = {
  dark: (g) => [g, g, g],
  medium: (g) => {
    const v = Math.round(g * 0.8 + 56);
    return [v, v, v];
  },
  light: (g) => {
    const v = 255 - g;
    return [v, v, v];
  },
  midnight: (g) => [Math.round(g * 0.72), Math.round(g * 0.82 + 4), Math.min(255, Math.round(g * 0.95 + 22))],
};
function theme(n) {
  const f = THEMES[n] || THEMES.dark;
  BASE.forEach((g, i) => document.documentElement.style.setProperty("--g" + i, `rgb(${f(g).join(",")})`));
  document.documentElement.dataset.theme = n;
  brushUI();
  $("theme").value = n;
  try {
    localStorage.setItem("2dTheme", n);
  } catch (_) {}
}
$("theme").onchange = (e) => theme(e.target.value);
