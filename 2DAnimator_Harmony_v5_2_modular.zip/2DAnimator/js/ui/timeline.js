/**
 * Línea de tiempo: filas de capas/grupos, celdas, cabezal, arrastre de claves e interpolación por rango.
 */
"use strict";
const gOf = (id) => S.groups.find((g) => g.id === id),
  kids = (id) => S.layers.filter((l) => l.g === id);
const cellS = (f, ids) => (S.frames[f] ? S.frames[f].strokes : []).filter((s) => ids.includes(owner(s).id));
const cellCls = (f, ids) => {
  const ss = cellS(f, ids);
  return ss.length ? (ss.every((s) => s.inb) ? " k ib" : " k") : "";
};
const pad = (j) => {
  while (S.frames.length <= j) S.frames.push({ id: uid(), strokes: [] });
};
function selLayer(i) {
  if (i === S.l) return;
  S.l = i;
  const l = S.layers[i];
  if (l && l.color) {
    S.color = l.color;
    S.opacity = l.op || 1;
    $("strokeColor").value = S.color;
    $("opacity").value = S.opacity * 100;
    syncLabels();
  }
}
const cellIds = (t) =>
  t.dataset.gid
    ? kids(t.dataset.gid).map((l) => l.id)
    : t.dataset.l !== undefined
      ? [S.layers[+t.dataset.l].id]
      : null;
function tl() {
  const n = S.frames.length,
    cols = Math.max(n + 12, 28),
    sec = (j) => ((j + 1) % S.fps === 0 ? " sec" : ""),
    R = S.rng,
    rs = document.documentElement.style;
  rs.setProperty("--cw", S.cw + "px");
  rs.setProperty("--kc", S.keyCol);
  rs.setProperty("--ic", S.inbCol);
  const cells = (ids, attr, li) =>
    Array.from(
      { length: cols },
      (_, j) =>
        `<i class="c${j === S.f ? " cur" : ""}${sec(j)}${j >= n ? " x" : ""}${R && R.key === ids.join(",") && j >= R.a && j <= R.b ? " rng" : ""}${j < n ? cellCls(j, ids) : ""}${li === S.l && j === S.f ? " on" : ""}" data-f="${j}" ${attr}></i>`
    ).join("");
  let h = `<div class="row hd"><div class="nm">Capas · ${S.layers.length}</div>${Array.from({ length: cols }, (_, j) => `<i class="c${j === S.f ? " cur" : ""}${sec(j)}${j >= n ? " x" : ""}${j < n && S.frames[j].mk ? " mk" : ""}${j < n && S.frames[j].exp > 1 ? " hx" : ""}" data-f="${j}"${j < n ? ' data-h="1"' : ""} title="${j < n && S.frames[j].mk ? esc(S.frames[j].mk) + " · " : ""}Fotograma ${j + 1}${j < n && S.frames[j].exp > 1 ? " · exposición ×" + S.frames[j].exp : ""}">${j < n && S.frames[j].exp > 1 ? "×" + S.frames[j].exp : j === 0 || (j + 1) % 5 === 0 ? j + 1 : "·"}</i>`).join("")}</div>`;
  const lrow = (l, i, sub) =>
      `<div class="row"><div class="nm${i === S.l ? " on" : ""}${sub ? " sub" : ""}" data-i="${i}"><b data-a="visible" class="${l.visible ? "" : "off"}" title="Mostrar / ocultar">${ic(l.visible ? "eye" : "eyeoff")}</b><b data-a="locked" title="Bloquear">${ic(l.locked ? "lock" : "unlock")}</b><span title="Doble clic para renombrar">${l.mode === "clip" ? ic("clip") : l.mode === "mask" ? ic("mask") : ""}${esc(l.name)}</span></div>${cells([l.id], `data-l="${i}"`, i)}</div>`,
    done = new Set();
  for (let i = S.layers.length - 1; i >= 0; i--) {
    const l = S.layers[i];
    if (!l.g) {
      h += lrow(l, i, 0);
      continue;
    }
    if (done.has(l.g)) continue;
    done.add(l.g);
    const G = gOf(l.g),
      K = kids(l.g),
      ids = K.map((x) => x.id),
      av = K.every((x) => x.visible),
      al = K.every((x) => x.locked),
      on = S.layers[S.l] && S.layers[S.l].g === l.g;
    h += `<div class="row grow"><div class="nm${on ? " on" : ""}" data-gid="${G.id}"><b data-a="gopen" title="Expandir / contraer">${ic(G.open ? "chev" : "chevr")}</b><b data-a="visible" class="${av ? "" : "off"}" title="Mostrar / ocultar grupo">${ic(av ? "eye" : "eyeoff")}</b><b data-a="locked" title="Bloquear grupo">${ic(al ? "lock" : "unlock")}</b><span title="Grupo: se comporta como una sola capa. Doble clic para renombrar">${ic("folder")}${esc(G.name)}</span></div>${cells(ids, `data-gid="${G.id}"`, -1)}</div>`;
    if (G.open)
      for (let k = S.layers.length - 1; k >= 0; k--) if (S.layers[k].g === l.g) h += lrow(S.layers[k], k, 1);
  }
  const b = $("tlBody");
  b.innerHTML = h;
  const c = b.querySelector(".hd .c.cur");
  if (c) {
    const r = c.getBoundingClientRect(),
      br = b.getBoundingClientRect();
    if (r.left < br.left + 200) b.scrollLeft -= br.left + 210 - r.left;
    else if (r.right > br.right) b.scrollLeft += r.right - br.right + 20;
  }
  $("frameCounter").textContent =
    `Fotograma ${S.f + 1}/${n} · ${(tickEnd(S.f) / S.fps).toFixed(2)} s de ${(ticksTotal() / S.fps).toFixed(2)} s`;
  ["fromFrame", "toFrame"].forEach((id, k) => {
    const s = $(id);
    if (s.options.length !== n) {
      const v = s.value;
      s.innerHTML = S.frames.map((_, i) => `<option value="${i}">Fotograma ${i + 1}</option>`).join("");
      s.value = v && +v < n ? v : k ? Math.min(1, n - 1) : 0;
    }
  });
  tweenUI();
  window.A2D && A2D.ext.onTl && A2D.ext.onTl();
}
function tweenUI() {
  const R = S.rng;
  let ok = false,
    msg =
      "Para interpolar: selecciona un fotograma clave y haz Shift+clic en otro de la misma capa o grupo. Los fotogramas vacíos entre ambos se rellenan.";
  if (R && R.a < R.b) {
    const both = R.ids.some((id) => cellS(R.a, [id]).length && cellS(R.b, [id]).length),
      gaps = R.b - R.a - 1;
    if (!both) msg = "Los dos extremos deben tener dibujo en la misma capa o grupo.";
    else if (gaps < 1)
      msg = "Los fotogramas son contiguos: usa «Intermedios» del panel para insertar nuevos.";
    else {
      ok = true;
      msg = `Rango ${R.a + 1} → ${R.b + 1}: se interpolarán los fotogramas vacíos entre las dos claves.`;
    }
  }
  $("tweenInfo").textContent = msg;
  $("tweenBtn").hidden = $("tweenEase").hidden = !ok;
}
function tweenGo() {
  const R = S.rng,
    fn = EASE[$("tweenEase").value];
  if (!R) return;
  let n = 0;
  pushUndo();
  const bad = (m) => {
    restore(S.undo.pop());
    hint(m);
  };
  for (const id of R.ids) {
    const lay = S.layers.find((l) => l.id === id),
      A = S.frames[R.a].strokes.filter((s) => owner(s) === lay),
      B = S.frames[R.b].strokes.filter((s) => owner(s) === lay);
    if (!A.length || !B.length) continue;
    for (let j = R.a + 1; j < R.b; j++) {
      if (S.frames[j].strokes.some((s) => owner(s) === lay)) continue;
      const g = interp(A, B, fn((j - R.a) / (R.b - R.a)));
      if (!g)
        return bad(
          `No se pudo interpolar «${lay.name}»: ambos extremos necesitan el mismo número y tipo de trazos, en el mismo orden.`
        );
      g.forEach((s) => (s.inb = true));
      S.frames[j].strokes.push(...g);
      n++;
    }
  }
  if (!n) return bad("No hay fotogramas vacíos entre las claves.");
  dirty();
  all();
  hint(n + " fotograma(s) intermedio(s) creado(s) y marcados como intermedios.");
}
$("tweenBtn").onclick = tweenGo;
function moveCell(d, j, copy) {
  pushUndo();
  pad(j);
  const src = S.frames[d.f],
    mv = src.strokes.filter((s) => d.ids.includes(owner(s).id));
  if (!copy) src.strokes = src.strokes.filter((s) => !mv.includes(s));
  S.frames[j].strokes.push(...(copy ? clone(mv) : mv));
  S.f = j;
  S.sel = null;
  dirty();
  all();
  hint(copy ? "Fotograma copiado." : "Fotograma movido. Alt+arrastrar para copiar.");
}
function markKey() {
  const ss = cellS(S.f, [L().id]);
  if (!ss.length) return hint("Esta celda está vacía.");
  pushUndo();
  const to = !ss.every((s) => s.inb);
  ss.forEach((s) => (s.inb = to));
  dirty();
  all();
  hint(to ? "Marcado como intermedio." : "Marcado como clave.");
}
function all() {
  render();
  tl();
}
$("markBtn").onclick = markKey;
$("keyCol").oninput = (e) => {
  S.keyCol = e.target.value;
  dirty();
  tl();
};
$("inbCol").oninput = (e) => {
  S.inbCol = e.target.value;
  dirty();
  tl();
};
$("tlBody").onpointerdown = (e) => {
  const t = e.target;
  if (t.dataset.h) {
    S.scrub = true;
    go(+t.dataset.f);
    return;
  }
  if (t.classList.contains("k") && e.button === 0 && !e.shiftKey) S.cd = { f: +t.dataset.f, ids: cellIds(t) };
};
document.addEventListener("pointermove", (e) => {
  if (!S.scrub) return;
  const t = document.elementFromPoint(e.clientX, e.clientY);
  if (t && t.dataset && t.dataset.h && +t.dataset.f !== S.f) go(+t.dataset.f);
});
document.addEventListener("pointerup", (e) => {
  S.scrub = false;
  const d = S.cd;
  S.cd = null;
  if (!d || !d.ids) return;
  const t = document.elementFromPoint(e.clientX, e.clientY);
  if (!t || t.dataset.f === undefined || +t.dataset.f === d.f) return;
  moveCell(d, +t.dataset.f, e.altKey);
  S.cdMoved = true;
  setTimeout(() => {
    S.cdMoved = false;
  }, 0);
});
$("tlBody").onclick = (e) => {
  if (S.cdMoved) return;
  const t = e.target,
    nm = t.closest(".nm"),
    a = t.dataset.a;
  if (nm && nm.dataset.gid) {
    const G = gOf(nm.dataset.gid),
      K = kids(G.id);
    if (a === "gopen") G.open = !G.open;
    else if (a) {
      pushUndo();
      const v = K.every((x) => x[a]);
      K.forEach((x) => (x[a] = !v));
    } else selLayer(S.layers.indexOf(K.at(-1)));
    dirty();
    all();
    return;
  }
  if (nm && nm.dataset.i !== undefined) {
    const i = +nm.dataset.i;
    if (a) {
      const l = S.layers[i];
      pushUndo();
      l[a] = !l[a];
      dirty();
    } else selLayer(i);
    all();
    return;
  }
  if ((t.dataset.f !== undefined && !t.dataset.h) || t.dataset.h) {
    const j = +t.dataset.f,
      ids = cellIds(t);
    if (S.playing) stop();
    if (e.shiftKey && ids && j !== S.f)
      S.rng = { a: Math.min(S.f, j), b: Math.max(S.f, j), ids, key: ids.join(",") };
    else S.rng = null;
    pad(j);
    if (t.dataset.l !== undefined) selLayer(+t.dataset.l);
    else if (t.dataset.gid) selLayer(S.layers.indexOf(kids(t.dataset.gid).at(-1)));
    S.f = j;
    S.sel = null;
    all();
  }
};
$("tlBody").ondblclick = (e) => {
  const nm = e.target.closest(".nm");
  if (!nm || e.target.dataset.a) return;
  if (nm.dataset.gid) {
    const G = gOf(nm.dataset.gid),
      v = prompt("Nombre del grupo", G.name);
    if (v && v.trim()) {
      G.name = v.trim().slice(0, 40);
      dirty();
      all();
    }
    return;
  }
  const l = S.layers[+nm.dataset.i],
    v = prompt("Nombre de la capa", l.name);
  if (v && v.trim()) {
    pushUndo();
    l.name = v.trim().slice(0, 40);
    dirty();
    all();
  }
};
$("cellZoom").oninput = (e) => {
  S.cw = +e.target.value;
  tl();
};
