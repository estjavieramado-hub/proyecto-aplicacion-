/**
 * Acciones de los menús (data-act) y atajos de teclado.
 */
"use strict";
const ARROW = { arrowleft: [-1, 0], arrowright: [1, 0], arrowup: [0, -1], arrowdown: [0, 1] };
const ACTS = {
  new: newProj,
  open: () => $("projectFileInput").click(),
  save,
  svg,
  png,
  undo,
  redo,
  del: delSel,
  selall: selAll,
  ref: () => $("refInput").click(),
  smooth: smoothAct,
  clear: clearLayer,
  fit,
  zin: () => zc(1.2),
  zout: () => zc(1 / 1.2),
  grid: () => $("showGrid").click(),
  onion: () => setOnion(),
  copy: () => copySel(false),
  cut: () => copySel(true),
  paste: () => pasteSel(0),
  dup: dupSel,
  front: () => arrange("front"),
  fwd: () => arrange("fwd"),
  bwd: () => arrange("bwd"),
  back: () => arrange("back"),
  snap: () => $("snapOn").click(),
  tobez: () => {
    if (!S.sel) return hint("Selecciona un trazo.");
    pushUndo();
    toBezier(S.sel);
    dirty();
    render();
  },
  addf: () => addF(0),
  dupf: () => addF(1),
  delf: delF,
  play,
};
document.addEventListener("click", (e) => {
  const b = e.target.closest("[data-act]");
  if (b && ACTS[b.dataset.act]) ACTS[b.dataset.act]();
  const bt = e.target.closest("button");
  if (bt) bt.blur();
});
document.addEventListener("keydown", (e) => {
  if (e.target.matches("input,select,textarea")) return;
  const k = e.key.toLowerCase(),
    c = e.ctrlKey || e.metaKey;
  if (c) {
    const bracket =
      e.code === "BracketRight"
        ? e.shiftKey
          ? "front"
          : "fwd"
        : e.code === "BracketLeft"
          ? e.shiftKey
            ? "back"
            : "bwd"
          : null;
    let done = true;
    if (k === "a") selAll();
    else if (k === "s") save();
    else if (k === "z") {
      if (S.pen && !e.shiftKey) Pen.undoPoint(); // dibujando con la pluma: deshace el último punto
      else e.shiftKey ? redo() : undo();
    } else if (k === "y") redo();
    else if (k === "c") copySel(false);
    else if (k === "x") copySel(true);
    else if (k === "v") pasteSel(0);
    else if (k === "d") dupSel();
    else if (bracket) arrange(bracket);
    else if (k === "0") fit();
    else if (k === "1") zc(1 / S.zoom);
    else if (k === "+" || k === "=") zc(1.25);
    else if (k === "-") zc(0.8);
    else done = false; // otras combinaciones: las gestiona el navegador
    if (done) e.preventDefault();
    return;
  }
  if (k === " ") {
    e.preventDefault();
    S.space = true;
    cv.style.cursor = "grab";
  } else if (k === "enter") {
    S.pen ? Pen.end() : play();
  } else if (k === "escape") {
    Pen.cancel();
    S.sel = null;
    S.ms = [];
    S.nodes = [];
    S.nodeSel = -1;
    render();
  } else if (k === "q") setOnion();
  else if (k === "k") markKey();
  else if (k === "insert") addF(0);
  else if (k === "delete" || k === "backspace") {
    S.pen ? Pen.undoPoint() : delSel();
  } else if (k.startsWith("arrow") && !S.pen && nudgeSel(...ARROW[k].map((v) => v * (e.shiftKey ? 10 : 1)))) {
    e.preventDefault(); // empujó la selección: no cambia de fotograma
  } else if (k === "arrowright" || k === ".") go(S.f + 1);
  else if (k === "arrowleft" || k === ",") go(S.f - 1);
  else if (KEYS[k]) setTool(KEYS[k]);
});
document.addEventListener("keyup", (e) => {
  if (e.key === " ") {
    S.space = false;
    cur();
  }
});
