/**
 * Separadores arrastrables: ancho del panel derecho y alto del timeline (se recuerdan en localStorage).
 */
(() => {
  const ls = (k, v) => {
    try {
      if (v === undefined) return localStorage.getItem(k);
      localStorage.setItem(k, v);
    } catch (_) {}
  };
  const $ = (id) => document.getElementById(id);
  // separadores
  const root = document.documentElement.style,
    cl = (v, a, b) => Math.max(a, Math.min(b, v));
  const init = (k, p, d) => root.setProperty(p, (ls(k) || d) + "px");
  init("2dPW", "--pw", 290);
  init("2dTH", "--th", 270);
  function drag(el, fn) {
    el.onpointerdown = (e) => {
      el.setPointerCapture(e.pointerId);
      el.classList.add("on");
      const mv = (ev) => fn(ev),
        up = () => {
          el.classList.remove("on");
          el.removeEventListener("pointermove", mv);
          el.removeEventListener("pointerup", up);
          window.dispatchEvent(new Event("resize"));
        };
      el.addEventListener("pointermove", mv);
      el.addEventListener("pointerup", up);
    };
  }
  drag($("spV"), (e) => {
    const w = cl(innerWidth - e.clientX, 220, 520);
    root.setProperty("--pw", w + "px");
    ls("2dPW", w);
  });
  drag($("spH"), (e) => {
    const h = cl(innerHeight - e.clientY, 140, innerHeight - 220);
    root.setProperty("--th", h + "px");
    ls("2dTH", h);
  });
})();
