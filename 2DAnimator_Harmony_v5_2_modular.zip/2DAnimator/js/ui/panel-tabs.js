/**
 * Panel derecho con pestañas (Herramienta · Animar · Asistentes · Rig) y muestra de color de la barra de herramientas.
 * Clasifica por título las secciones, incluidas las que inyectan otros módulos.
 */
(() => {
  const $ = (id) => document.getElementById(id),
    ls = (k, v) => {
      try {
        if (v === undefined) return localStorage.getItem(k);
        localStorage.setItem(k, v);
      } catch (_) {}
    };
  const TABS = [
    ["tool", "Herramienta", /^(Propiedades|Pincel|Simetr|Transformar selecc|Relleno|Borrador|Nodos|Organizar|Vista)/],
    ["anim", "Animar", /^(Intermedios|Graph|Transformaci)/],
    ["assist", "Asistentes", /^(Asistente)/],
    ["rig", "Rig", /^(Esqueleto)/],
  ];
  const props = document.querySelector(".props"),
    hint = $("hintBox");
  // agrupa h3+.pb y <details> por pestaña
  [...props.children].forEach((el) => {
    if (el.tagName === "H3") {
      const pb = el.nextElementSibling;
      if (pb && pb.classList.contains("pb")) {
        const w = document.createElement("section");
        w.className = "sec";
        el.before(w);
        w.append(el, pb);
        w.dataset.title = el.textContent;
      }
    }
  });
  const secs = () => [...props.children].filter((e) => e.tagName === "SECTION" || e.tagName === "DETAILS");
  function classify() {
    secs().forEach((e) => {
      if (e.dataset.tab) return;
      const s = e.dataset.title || (e.querySelector("summary") || {}).textContent || "";
      e.dataset.tab = (TABS.find((t) => t[2].test(s.trim())) || TABS[0])[0];
    });
  }
  function tab(n) {
    props.dataset.tab = n;
    ls("2dPropTab", n);
    [...$("ptabs").children].forEach((b) => b.classList.toggle("on", b.dataset.t === n));
  }
  $("ptabs").innerHTML = TABS.map((t) => `<button data-t="${t[0]}">${t[1]}</button>`).join("");
  $("ptabs").onclick = (e) => {
    const b = e.target.closest("button");
    if (b) tab(b.dataset.t);
  };
  classify();
  props.append(hint);
  tab(ls("2dPropTab") || "tool");
  // al elegir herramienta de rig, abre su pestaña
  document.querySelectorAll(".tool").forEach((b) =>
    b.addEventListener("click", () => {
      if (["bone", "pose"].includes(b.dataset.tool)) tab("rig");
      else if (props.dataset.tab === "rig") tab("tool");
    })
  );
  // muestra de color
  const chip = $("chip"),
    fill = $("chipFill"),
    col = $("strokeColor");
  chip.onclick = () => col.click();
  setInterval(() => {
    if (fill.style.background !== col.value) fill.style.background = col.value;
  }, 250);
})();
