/**
 * Detalles de interfaz: menús que se abren con clic, tooltips de herramientas con su atajo y barra de estado.
 * Depende de: S, L, cv, $, esc (globales de core/state.js).
 */
"use strict";
(() => {
  /* menús: clic abre, pasar el ratón cambia de menú, Esc o clic fuera cierran */
  const menus = [...document.querySelectorAll(".menubar .m")],
    closeAll = () => menus.forEach((m) => m.classList.remove("open"));
  menus.forEach((m) => {
    m.addEventListener("click", (e) => {
      if (e.target.closest(".dd")) return closeAll();
      const was = m.classList.contains("open");
      closeAll();
      m.classList.toggle("open", !was);
    });
    m.addEventListener("mouseenter", () => {
      if (menus.some((x) => x.classList.contains("open"))) {
        closeAll();
        m.classList.add("open");
      }
    });
  });
  document.addEventListener("pointerdown", (e) => {
    if (!e.target.closest(".m")) closeAll();
  });
  document.addEventListener("keydown", (e) => {
    if (e.key === "Escape") closeAll();
  });

  /* tooltips: «Nombre (Atajo) — descripción» */
  const tip = document.createElement("div");
  tip.id = "tip";
  document.body.append(tip);
  document.querySelectorAll(".tool[title]").forEach((b) => {
    b.dataset.tip = b.title;
    b.setAttribute("aria-label", b.title.split(" (")[0]);
    b.removeAttribute("title");
  });
  document.addEventListener("pointerover", (e) => {
    const b = e.target.closest(".tool[data-tip]");
    if (!b) return tip.classList.remove("on");
    const m = b.dataset.tip.match(/^(.*?)\s*\(([^)]+)\)\s*(?:—\s*(.*))?$/),
      [n, k, d] = m ? [m[1], m[2], m[3] || ""] : [b.dataset.tip, "", ""],
      r = b.getBoundingClientRect();
    tip.innerHTML = `<b>${esc(n)}</b>${k ? `<kbd>${esc(k)}</kbd>` : ""}${d ? `<small>${esc(d)}</small>` : ""}`;
    tip.style.left = r.right + 8 + "px";
    tip.style.top = r.top + r.height / 2 + "px";
    tip.classList.add("on");
  });
  document.addEventListener("pointerdown", () => tip.classList.remove("on"));

  /* barra de estado */
  const stage = $("stage"),
    pos = $("stPos");
  stage.addEventListener("pointermove", (e) => {
    const r = cv.getBoundingClientRect(),
      x = Math.round(((e.clientX - r.left) * cv.width) / r.width),
      y = Math.round(((e.clientY - r.top) * cv.height) / r.height);
    pos.textContent = x >= 0 && y >= 0 && x <= cv.width && y <= cv.height ? `${x}, ${y} px` : "—";
  });
  stage.addEventListener("pointerleave", () => (pos.textContent = "—"));
  const set = (id, t) => {
    const n = $(id);
    if (n.textContent !== t) n.textContent = t;
  };
  setInterval(() => {
    set("stRes", `${S.width} × ${S.height}`);
    set("stFps", `${S.fps} fps`);
    set("stTool", $("toolName").textContent);
    set("stLayer", L() ? L().name : "—");
    set("stFrame", `${S.f + 1} / ${S.frames.length}`);
    set("stTime", `${((S.f + 1) / S.fps).toFixed(2)} s`);
  }, 200);
})();
