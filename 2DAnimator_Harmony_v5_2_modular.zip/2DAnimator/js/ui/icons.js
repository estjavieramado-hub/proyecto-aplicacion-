/**
 * Biblioteca de iconos SVG (estilo trazo, 24x24). Se inyecta como sprite en el <body>.
 * Uso en HTML:  <svg class="ic"><use href="#i-play"/></svg>   ·   Uso en JS:  ic("play")
 * Para añadir un icono: agrega una entrada a ICON_PATHS (solo el contenido interior del <svg>).
 */
"use strict";
const ICON_PATHS = {
  select: '<path d="M5 3l14 8-6.5 1.8L10 19z"/>',
  lasso: '<path d="M6 14C2 10 6 4 13 4s9 4 6 8-9 4-10 7c-.5 2 2 2.5 3 1" stroke-dasharray="3 2.5"/>',
  node: '<path d="M4 18C8 4 16 4 20 18"/><rect x="2" y="16" width="4.5" height="4.5" fill="currentColor"/><rect x="17.5" y="16" width="4.5" height="4.5" fill="currentColor"/><circle cx="12" cy="6.5" r="2.2"/>',
  bezier:
    '<path d="M12 19l7-7 3 3-7 7z"/><path d="M18 13l-1.5-7.5L2 2l3.5 14.5L13 18z"/><path d="M2 2l7.6 7.6"/><circle cx="11" cy="11" r="1.6"/>',
  pencil: '<path d="M17 3a2.8 2.8 0 014 4L7.5 20.5 2 22l1.5-5.5z"/><path d="M15 5l4 4"/>',
  eraser:
    '<path d="M20 20H9L3.7 14.7a1 1 0 010-1.4l9.6-9.6a1 1 0 011.4 0l5.6 5.6a1 1 0 010 1.4L11 20"/><path d="M7 11l6 6"/>',
  line: '<path d="M5 19L19 5"/>',
  rectangle: '<rect x="4" y="5.5" width="16" height="13" rx="1.5"/>',
  ellipse: '<ellipse cx="12" cy="12" rx="9" ry="6.5"/>',
  fill: '<path d="M5 11l7-7 8 8-7 7z"/><path d="M20 15c1.5 2 2 3 2 4a2 2 0 01-4 0c0-1 .5-2 2-4z" fill="currentColor"/>',
  xform: '<path d="M5 9l-3 3 3 3M9 5l3-3 3 3M15 19l-3 3-3-3M19 9l3 3-3 3M2 12h20M12 2v20"/>',
  bone: '<circle cx="6" cy="18" r="2.6"/><circle cx="18" cy="6" r="2.6"/><path d="M8 16l8-8"/>',
  pose: '<circle cx="12" cy="4.5" r="2.3"/><path d="M12 7.5v6.5M6 10.5l6-1.5 6 1.5M12 14l-3.5 7M12 14l3.5 7"/>',
  hand: '<path d="M8 13V5.5a1.5 1.5 0 013 0V12M11 11V4a1.5 1.5 0 013 0v8M14 11V5.5a1.5 1.5 0 013 0V14M17 9.5a1.5 1.5 0 013 0V15a7 7 0 01-7 7h-1a7 7 0 01-5.6-2.8L4 15.5a1.6 1.6 0 012.5-2L8 15"/>',
  scissors:
    '<circle cx="6" cy="6" r="2.6"/><circle cx="6" cy="18" r="2.6"/><path d="M8 7.5L20 18M8 16.5L20 6"/>',
  polygon: '<path d="M12 3l8.5 6.2-3.2 10H6.7l-3.2-10z"/>',
  star: '<path d="M12 3l2.7 5.8 6.3.8-4.6 4.4 1.2 6.2L12 17l-5.6 3.2 1.2-6.2L3 9.6l6.3-.8z"/>',
  eyedropper: '<path d="M17 3.5l3.5 3.5-2 2-3.5-3.5z"/><path d="M15 8L5 18v3h3l10-10"/><path d="M14 9l1.5 1.5"/>',
  zoom: '<circle cx="10.5" cy="10.5" r="6.5"/><path d="M15.5 15.5L21 21M10.5 8v5M8 10.5h5"/>',
  first: '<path d="M6 5v14"/><path d="M19 5v14L9 12z" fill="currentColor"/>',
  prev: '<path d="M18 5v14L7 12z" fill="currentColor"/>',
  play: '<path d="M7 4.5v15l13-7.5z" fill="currentColor"/>',
  pause: '<path d="M7 5h3.5v14H7zM13.5 5H17v14h-3.5z" fill="currentColor"/>',
  next: '<path d="M6 5v14l11-7z" fill="currentColor"/>',
  last: '<path d="M18 5v14"/><path d="M5 5v14l10-7z" fill="currentColor"/>',
  eye: '<path d="M1.5 12S5.5 5 12 5s10.5 7 10.5 7-4 7-10.5 7S1.5 12 1.5 12z"/><circle cx="12" cy="12" r="3"/>',
  eyeoff:
    '<path d="M3 3l18 18M10.6 5.1A9.7 9.7 0 0112 5c6.5 0 10.5 7 10.5 7a17 17 0 01-3.2 3.9M6.6 6.6A17 17 0 001.5 12S5.5 19 12 19a9.7 9.7 0 004.2-1"/>',
  lock: '<rect x="5" y="11" width="14" height="10" rx="2"/><path d="M8 11V7a4 4 0 018 0v4"/>',
  unlock: '<rect x="5" y="11" width="14" height="10" rx="2"/><path d="M8 11V7a4 4 0 017.5-1.5"/>',
  chev: '<path d="M6 9l6 6 6-6"/>',
  chevr: '<path d="M9 6l6 6-6 6"/>',
  plus: '<path d="M12 5v14M5 12h14"/>',
  minus: '<path d="M5 12h14"/>',
  x: '<path d="M6 6l12 12M18 6L6 18"/>',
  up: '<path d="M12 19V5M6 11l6-6 6 6"/>',
  down: '<path d="M12 5v14M6 13l6 6 6-6"/>',
  left: '<path d="M19 12H5M11 6l-6 6 6 6"/>',
  right: '<path d="M5 12h14M13 6l6 6-6 6"/>',
  copy: '<rect x="8" y="8" width="12" height="12" rx="2"/><path d="M16 8V6a2 2 0 00-2-2H6a2 2 0 00-2 2v8a2 2 0 002 2h2"/>',
  folder: '<path d="M3 7a2 2 0 012-2h4l2 2h8a2 2 0 012 2v8a2 2 0 01-2 2H5a2 2 0 01-2-2z"/>',
  clip: '<path d="M7 4v8a3 3 0 003 3h7M13 11l4 4-4 4"/>',
  mask: '<circle cx="12" cy="12" r="9"/><path d="M12 3a9 9 0 010 18z" fill="currentColor"/>',
  onion:
    '<rect x="2" y="7" width="12" height="14" rx="2" fill="currentColor" opacity=".28"/><rect x="6" y="4.5" width="12" height="14" rx="2" fill="currentColor" opacity=".55"/><rect x="10" y="2" width="12" height="14" rx="2" fill="currentColor"/>',
  key: '<path d="M12 3l8 9-8 9-8-9z" fill="currentColor"/>',
  flag: '<path d="M5 21V4M5 4h12l-2 4 2 4H5"/>',
  layers: '<path d="M12 3l9 5-9 5-9-5z"/><path d="M3 13l9 5 9-5"/>',
  fit: '<path d="M4 9V5h4M20 9V5h-4M4 15v4h4M20 15v4h-4"/>',
};
const ic = (n) => `<svg class="ic"><use href="#i-${n}"/></svg>`;
document.body.insertAdjacentHTML(
  "afterbegin",
  '<svg width="0" height="0" style="position:absolute" aria-hidden="true"><defs>' +
    Object.entries(ICON_PATHS)
      .map(
        ([k, v]) =>
          `<symbol id="i-${k}" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round">${v}</symbol>`
      )
      .join("") +
    "</defs></svg>"
);
