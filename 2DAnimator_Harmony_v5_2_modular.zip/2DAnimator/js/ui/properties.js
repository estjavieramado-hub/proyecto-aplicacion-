/**
 * Panel de propiedades: color, grosor, opacidad, suavidad, onion skin y guía de calco.
 */
"use strict";
const SW = [
  "#24272d",
  "#ffffff",
  "#e0556b",
  "#f28c28",
  "#f2c94c",
  "#4caf50",
  "#3d9be9",
  "#8e5bd6",
  "#7a4b2a",
  "#888888",
  "#ff7aa2",
  "#37c6b1",
  "#1b3a6b",
  "#b00020",
  "#c9c9c9",
  "#000000",
];
$("swatches").innerHTML = SW.map(
  (c) => `<button style="background:${c}" data-c="${c}" title="${c}"></button>`
).join("");
function syncLabels() {
  $("sizeValue").textContent = $("strokeSize").value + " px";
  $("opacityValue").textContent = $("opacity").value + "%";
  $("stabValue").textContent = $("stab").value;
}
function setProp(k, v) {
  S[k] = v;
  if (S.sel && k !== "stab") {
    if (!S.propU) {
      pushUndo();
      S.propU = true;
    }
    msel().forEach((t) => {
      t[k === "color" ? "color" : k === "size" ? "size" : "opacity"] = v;
    });
    dirty();
    render();
  }
  syncLabels();
}
$("strokeColor").oninput = (e) => setProp("color", e.target.value);
$("swatches").onclick = (e) => {
  const c = e.target.dataset.c;
  if (c) {
    $("strokeColor").value = c;
    setProp("color", c);
  }
};
$("strokeSize").oninput = (e) => setProp("size", +e.target.value);
$("opacity").oninput = (e) => setProp("opacity", +e.target.value / 100);
$("stab").oninput = (e) => setProp("stab", +e.target.value);
["showGrid", "lineAssistant", "lineReference", "symmetry", "symN"].forEach((id) => ($(id).onchange = render));
$("guideOpacity").oninput = (e) => {
  $("guideOpacityValue").textContent = e.target.value + "%";
  render();
};
$("reverseGuideBtn").onclick = () => {
  S.rev = !S.rev;
  render();
};
$("skipPrev").onclick = () => {
  S.skip--;
  render();
};
$("skipNext").onclick = () => {
  S.skip++;
  render();
};
function setOnion(v) {
  S.onion = v === undefined ? !S.onion : v;
  $("onionBtn").classList.toggle("on", S.onion);
  render();
}
$("onionBtn").onclick = () => setOnion();
$("onionBefore").oninput = (e) => {
  S.nb = Math.max(0, Math.min(8, +e.target.value || 0));
  render();
};
$("onionAfter").oninput = (e) => {
  S.na = Math.max(0, Math.min(8, +e.target.value || 0));
  render();
};
