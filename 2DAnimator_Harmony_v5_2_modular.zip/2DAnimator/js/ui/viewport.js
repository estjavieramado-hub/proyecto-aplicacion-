/**
 * Vista del lienzo: zoom, ajustar a ventana y rueda del ratón.
 */
"use strict";
function view() {
  $("paper").style.transform = `translate(${S.px}px,${S.py}px) scale(${S.zoom})`;
  $("zoomLabel").textContent = Math.round(S.zoom * 100) + "%";
}
function fit() {
  const r = $("stage").getBoundingClientRect();
  S.zoom = Math.max(0.1, Math.min((r.width - 40) / S.width, (r.height - 40) / S.height));
  S.px = (r.width - S.width * S.zoom) / 2;
  S.py = (r.height - S.height * S.zoom) / 2;
  view();
  render();
}
function zoomAt(k, cx, cy) {
  const z = Math.max(0.1, Math.min(32, S.zoom * k)),
    r = z / S.zoom;
  S.px = cx - (cx - S.px) * r;
  S.py = cy - (cy - S.py) * r;
  S.zoom = z;
  view();
  overlay(); // los nodos y asas tienen tamaño fijo en pantalla: se redibujan con el nuevo zoom
}
const zc = (k) => {
  const r = $("stage").getBoundingClientRect();
  zoomAt(k, r.width / 2, r.height / 2);
};
$("stage").addEventListener(
  "wheel",
  (e) => {
    e.preventDefault();
    const r = $("stage").getBoundingClientRect();
    zoomAt(e.deltaY < 0 ? 1.1 : 0.9, e.clientX - r.left, e.clientY - r.top);
  },
  { passive: false }
);
window.addEventListener("resize", fit);
