/**
 * Pantalla de inicio y «Nuevo proyecto»: resoluciones predefinidas, tamaño personalizado, FPS y nombre.
 * Depende de: S, $, esc, load(), dirty(). Se abre al arrancar (main.js) y desde Archivo › Nuevo proyecto.
 * Para añadir una resolución, agrega una fila [nombre, ancho, alto] a RES_PRESETS.
 */
"use strict";
const RES_PRESETS = [
  [
    "Vídeo",
    [
      ["HD 720p", 1280, 720],
      ["Full HD 1080p", 1920, 1080],
      ["2K QHD", 2560, 1440],
      ["4K UHD", 3840, 2160],
    ],
  ],
  [
    "Cine",
    [
      ["DCI 2K", 2048, 1080],
      ["Panorámico 2.39:1", 1920, 804],
    ],
  ],
  [
    "Redes sociales",
    [
      ["Vertical 9:16", 1080, 1920],
      ["Cuadrado 1:1", 1080, 1080],
      ["Retrato 4:5", 1080, 1350],
    ],
  ],
  [
    "Clásico y sprites",
    [
      ["SD 4:3", 640, 480],
      ["NTSC 480p", 720, 480],
      ["Sprite 512", 512, 512],
      ["Sprite 256", 256, 256],
    ],
  ],
];
const RES_MIN = 64,
  RES_MAX = 8192;
const fitBox = (w, h, bw, bh) => {
  const k = Math.min(bw / w, bh / h);
  return `width:${Math.max(4, Math.round(w * k))}px;height:${Math.max(4, Math.round(h * k))}px`;
};
const ratioText = (w, h) => {
  const g = (a, b) => (b ? g(b, a % b) : a),
    d = g(w, h);
  return w / d <= 32 && h / d <= 32 ? `${w / d}:${h / d}` : `${(w / h).toFixed(2)}:1`;
};
function readDraft() {
  try {
    const d = JSON.parse(localStorage.getItem("2dAnimatorAutosave") || "null");
    return d && d.format === "2DAnimatorProject" ? d : null;
  } catch (_) {
    return null;
  }
}
function openStart(first) {
  if (document.getElementById("startDlg")) return;
  if (!first && S.dirty && !confirm("Hay cambios sin guardar. ¿Crear un proyecto nuevo de todos modos?")) return;
  let last = {};
  try {
    last = JSON.parse(localStorage.getItem("2dLastRes") || "{}") || {};
  } catch (_) {}
  const draft = first ? readDraft() : null,
    st = { w: last.w || 1920, h: last.h || 1080, lock: true },
    prev = document.activeElement,
    el = document.createElement("div");
  el.id = "startDlg";
  const draftInfo = draft
    ? `${esc(String(draft.name || "Proyecto").slice(0, 40))} · ${+draft.width || 1280}×${+draft.height || 720} · ${
        Array.isArray(draft.frames) ? draft.frames.length : 1
      } fotogramas`
    : "";
  el.innerHTML = `<div class="sd" role="dialog" aria-modal="true" aria-labelledby="sdTitle">
    <div class="sd-l">
      <h2 id="sdTitle">${first ? "Bienvenido a 2D Animator" : "Nuevo proyecto"}</h2>
      <p class="muted">Elige la resolución del lienzo antes de empezar.</p>
      ${
        draft
          ? `<button class="sd-draft" id="sdDraft">${ic("folder")}<span><b>Continuar el borrador automático</b><small>${draftInfo}</small></span></button>`
          : ""
      }
      ${RES_PRESETS.map(
        ([g, a]) =>
          `<h4>${g}</h4><div class="sd-grid">${a
            .map(
              ([n, w, h]) =>
                `<button class="sd-card" data-w="${w}" data-h="${h}"><span class="th"><i style="${fitBox(w, h, 56, 34)}"></i></span><b>${n}</b><span>${w} × ${h}</span></button>`
            )
            .join("")}</div>`
      ).join("")}
    </div>
    <div class="sd-r">
      <div class="sd-prev"><i id="sdPrev"></i></div>
      <p class="sd-sum" id="sdSum"></p>
      <div class="sd-size">
        <label>Ancho (px)<input id="sdW" type="number" min="${RES_MIN}" max="${RES_MAX}" /></label>
        <button id="sdLock" class="on" title="Mantener la proporción" aria-label="Mantener la proporción" aria-pressed="true">${ic("lock")}</button>
        <label>Alto (px)<input id="sdH" type="number" min="${RES_MIN}" max="${RES_MAX}" /></label>
      </div>
      <button id="sdSwap">${ic("fit")} Girar (intercambiar ancho y alto)</button>
      <label>Fotogramas por segundo
        <select id="sdFps">${[8, 12, 15, 24, 25, 30, 60].map((f) => `<option value="${f}"${f === (last.fps || 24) ? " selected" : ""}>${f} fps</option>`).join("")}</select>
      </label>
      <label>Nombre del proyecto<input id="sdName" type="text" maxlength="60" placeholder="Sin título" /></label>
      <div class="sd-btns">
        <button id="sdOpen">Abrir…</button>
        ${first ? "" : '<button id="sdCancel">Cancelar</button>'}
        <button id="sdGo" class="primary">Crear proyecto</button>
      </div>
    </div>
  </div>`;
  document.body.append(el);
  const q = (id) => el.querySelector("#" + id),
    W = q("sdW"),
    H = q("sdH"),
    cl = (v) => Math.round(Math.max(RES_MIN, Math.min(RES_MAX, +v || RES_MIN)));
  const sync = (src) => {
    if (src !== "w") W.value = st.w;
    if (src !== "h") H.value = st.h;
    q("sdPrev").style.cssText = fitBox(st.w, st.h, 200, 120);
    const mp = (st.w * st.h) / 1e6,
      big = st.w > 4096 || st.h > 4096 || st.w * st.h > 16e6;
    q("sdSum").textContent = `${st.w} × ${st.h} · ${ratioText(st.w, st.h)} · ${mp.toFixed(1)} MP`;
    q("sdSum").classList.toggle("warn", big);
    if (big) q("sdSum").textContent += " · puede ir lento";
    el.querySelectorAll(".sd-card").forEach((c) => c.classList.toggle("on", +c.dataset.w === st.w && +c.dataset.h === st.h));
  };
  const close = () => {
    el.remove();
    document.removeEventListener("keydown", onKey, true);
    if (prev && prev.focus) prev.focus();
  };
  const onKey = (e) => {
    if (e.key === "Escape") {
      e.stopPropagation();
      close();
    } else if (e.key === "Enter" && e.target.matches("input")) q("sdGo").click();
  };
  document.addEventListener("keydown", onKey, true);
  el.addEventListener("click", (e) => {
    const c = e.target.closest(".sd-card");
    if (c) {
      st.w = +c.dataset.w;
      st.h = +c.dataset.h;
      sync();
    }
  });
  W.oninput = () => {
    const r = st.w / st.h;
    st.w = cl(W.value);
    if (st.lock) st.h = cl(st.w / r);
    sync("w");
  };
  H.oninput = () => {
    const r = st.w / st.h;
    st.h = cl(H.value);
    if (st.lock) st.w = cl(st.h * r);
    sync("h");
  };
  W.onchange = H.onchange = () => sync();
  q("sdLock").onclick = (e) => {
    st.lock = !st.lock;
    e.currentTarget.classList.toggle("on", st.lock);
    e.currentTarget.setAttribute("aria-pressed", st.lock);
  };
  q("sdSwap").onclick = () => {
    [st.w, st.h] = [st.h, st.w];
    sync();
  };
  q("sdOpen").onclick = () => {
    close();
    $("projectFileInput").click();
  };
  if (q("sdCancel")) q("sdCancel").onclick = close;
  if (q("sdDraft"))
    q("sdDraft").onclick = () => {
      close();
      load(draft);
    };
  q("sdGo").onclick = () => {
    const w = cl(st.w),
      h = cl(st.h),
      fps = +q("sdFps").value;
    try {
      localStorage.setItem("2dLastRes", JSON.stringify({ w, h, fps }));
    } catch (_) {}
    close();
    load({ format: "2DAnimatorProject", name: q("sdName").value.trim() || "Sin título", width: w, height: h, fps });
    dirty();
    $("saveStatus").textContent = `Proyecto nuevo · ${w}×${h}`;
  };
  sync();
  q("sdGo").focus();
}
