/**
 * Panel de pinceles vectoriales con vista previa y opciones de presión/inclinación.
 */
"use strict";
function brushUI() {
  const box = $("brushes");
  box.innerHTML = Object.entries(BR)
    .map(
      ([k, b]) =>
        `<button data-b="${k}" class="${k === S.brush ? "on" : ""}" title="${b.n}"><canvas width="96" height="30"></canvas><span>${b.n}</span></button>`
    )
    .join("");
  box.querySelectorAll("button").forEach((btn) => {
    const c = btn.querySelector("canvas").getContext("2d"),
      col = getComputedStyle(btn).color;
    c.clearRect(0, 0, 96, 30);
    drawStroke(
      c,
      {
        kind: "path",
        brush: btn.dataset.b,
        color: col,
        size: 8,
        opacity: 1,
        points: Array.from({ length: 30 }, (_, i) => ({
          x: 8 + i * 2.7,
          y: 15 + Math.sin((i / 30) * Math.PI * 2) * 7,
          w: 0.3 + 0.7 * Math.sin((i / 29) * Math.PI),
        })),
      },
      col
    );
  });
}
$("brushes").onclick = (e) => {
  const b = e.target.closest("[data-b]");
  if (b) {
    S.brush = b.dataset.b;
    brushUI();
    if (S.tool !== "pencil") setTool("pencil");
  }
};
$("pressure").onchange = (e) => {
  S.press = e.target.checked;
};
$("tiltOn").onchange = (e) => {
  S.tiltOn = e.target.checked;
};
