/**
 * Paneles de opciones de herramienta: relleno y formas, borrador e imán, nodos, orden y alineación.
 * Depende de: S, $, msel, pushUndo, dirty, render, Node, arrange, align, syncLabels.
 */
"use strict";
$("fillColor").oninput = (e) => {
  S.fillColor = e.target.value;
  const f = msel().filter((t) => t.kind === "fill");
  if (f.length) {
    if (!S.propU) {
      pushUndo();
      S.propU = true;
    }
    f.forEach((t) => (t.color = S.fillColor));
    dirty();
    render();
  }
};
$("fillOn").onchange = (e) => (S.fillOn = e.target.checked);
$("polySides").oninput = (e) => (S.sides = Math.round(num(e.target.value, 5, 3, 24)));
$("starRatio").oninput = (e) => (S.starRatio = num(e.target.value, 50, 10, 95));
$("cornerR").oninput = (e) => {
  S.corner = +e.target.value;
  $("cornerV").textContent = S.corner + " px";
};
$("eMode").onchange = (e) => (S.eMode = e.target.value);
$("eSize").oninput = (e) => {
  S.eSize = +e.target.value;
  $("eSizeV").textContent = S.eSize + " px";
  overlay();
};
$("snapOn").onchange = (e) => {
  S.snap = e.target.checked;
  Snap.clear();
  overlay();
  hint(S.snap ? "Imán activado: se ajusta a puntos, guías y a la cuadrícula si está visible." : "Imán desactivado.");
};
const NDACT = {
  corner: () => Node.corner(),
  smooth: () => Node.smooth(),
  del: () => Node.remove() || hint("Selecciona nodos con la herramienta Nodos (A)."),
  cut: () => Node.cut(),
  close: () => Node.toggleClosed(),
  rev: () => Node.reverse(),
  simp: () => Node.simplify(),
};
document.querySelectorAll("[data-nd]").forEach((b) => (b.onclick = () => NDACT[b.dataset.nd]()));
document.querySelectorAll("[data-arr]").forEach((b) => (b.onclick = () => arrange(b.dataset.arr)));
document.querySelectorAll("[data-al]").forEach((b) => (b.onclick = () => align(b.dataset.al)));
