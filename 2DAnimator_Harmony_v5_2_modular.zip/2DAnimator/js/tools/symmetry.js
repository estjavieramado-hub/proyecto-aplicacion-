/**
 * Simetría de dibujo (vertical, horizontal, radial) y confirmación de trazos nuevos (commit).
 */
"use strict";
function rotOf(s, g) {
  const c = clone(s);
  if (c.kind === "rect" || c.kind === "ellipse") toBezier(c);
  const R = rotM(g),
    cx = S.width / 2,
    cy = S.height / 2;
  c.points.forEach((p) => {
    const q = R(p.x - cx, p.y - cy);
    p.x = cx + q[0];
    p.y = cy + q[1];
    if ("ix" in p)
      ["i", "o"].forEach((k) => {
        const v = R(p[k + "x"], p[k + "y"]);
        p[k + "x"] = v[0];
        p[k + "y"] = v[1];
      });
  });
  return c;
}
function mirrorOf(s, fx, fy) {
  const c = clone(s);
  c.points.forEach((p) => {
    if (fx) {
      p.x = S.width - p.x;
      if ("ix" in p) {
        p.ix = -p.ix;
        p.ox = -p.ox;
      }
    }
    if (fy) {
      p.y = S.height - p.y;
      if ("iy" in p) {
        p.iy = -p.iy;
        p.oy = -p.oy;
      }
    }
  });
  return c;
}
function mirrors(s) {
  const v = $("symmetry").value,
    o = [];
  if (v === "v" || v === "vh") o.push(mirrorOf(s, 1, 0));
  if (v === "h" || v === "vh") o.push(mirrorOf(s, 0, 1));
  if (v === "vh") o.push(mirrorOf(s, 1, 1));
  if (v === "r") {
    const n = Math.round(num($("symN").value, 6, 2, 16));
    for (let i = 1; i < n; i++) o.push(rotOf(s, (360 * i) / n));
  }
  return o;
}
const commit = (s) => F().strokes.push(s, ...mirrors(s));
