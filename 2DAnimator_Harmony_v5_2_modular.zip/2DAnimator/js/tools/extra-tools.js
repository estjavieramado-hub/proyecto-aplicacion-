/**
 * Herramientas nuevas y ayudas de forma:
 *   · Polígono y Estrella (se crean como Bézier cerrado, editables con Nodos)
 *   · Rectángulo con esquinas redondeadas; Shift = cuadrado/círculo/45°, Alt = desde el centro
 *   · Cuentagotas (I): toma color, grosor, opacidad y pincel; con selección se los aplica (Alt: solo tomar)
 *   · Zoom (Z): clic acerca, Alt/Shift+clic aleja, arrastrar encuadra una zona
 *   · fillOf(): relleno automático para formas cerradas («Rellenar al dibujar»)
 * Depende de: S, F, L, owner, hit, pts, msel, pushUndo, dirty, all, render, hint, zoomAt, view, $, num, Snap.
 */
"use strict";

/* ---------- geometría de formas ---------- */
const corner0 = (x, y, ox = 0, oy = 0, ix = 0, iy = 0) => ({ x, y, ox, oy, ix, iy });
function polyPoints(c, r, rot, sides, star, ratio) {
  const n = star ? sides * 2 : sides;
  return Array.from({ length: n }, (_, i) => {
    const a = rot + (i * Math.PI * 2) / n;
    const rr = star && i % 2 ? r * ratio : r;
    return corner0(c.x + Math.cos(a) * rr, c.y + Math.sin(a) * rr);
  });
}
function roundRectPoints(a, b, rad) {
  const x0 = Math.min(a.x, b.x);
  const x1 = Math.max(a.x, b.x);
  const y0 = Math.min(a.y, b.y);
  const y1 = Math.max(a.y, b.y);
  const r = Math.max(0, Math.min(rad, (x1 - x0) / 2, (y1 - y0) / 2));
  const k = r * 0.5523;
  return [
    corner0(x0 + r, y0, 0, 0, -k, 0),
    corner0(x1 - r, y0, k, 0, 0, 0),
    corner0(x1, y0 + r, 0, 0, 0, -k),
    corner0(x1, y1 - r, 0, k, 0, 0),
    corner0(x1 - r, y1, 0, 0, k, 0),
    corner0(x0 + r, y1, -k, 0, 0, 0),
    corner0(x0, y1 - r, 0, 0, 0, k),
    corner0(x0, y0 + r, 0, -k, 0, 0),
  ];
}
/** Actualiza S.cur (rectángulo, elipse, línea, polígono, estrella) según el puntero y las teclas. */
function shapeUpdate(p, e) {
  const t = S.tool;
  const s = S.start;
  const q = e.shiftKey ? p : Snap.pt(p, { from: s });
  if (t === "polygon" || t === "star") {
    const dx = q.x - s.x;
    const dy = q.y - s.y;
    const rot = e.shiftKey ? -Math.PI / 2 : Math.atan2(dy, dx);
    S.cur.points = polyPoints(s, Math.hypot(dx, dy), rot, S.sides, t === "star", S.starRatio / 100);
    return;
  }
  let a = s;
  let b = q;
  if (t === "line") {
    if (e.shiftKey) {
      const d = Math.hypot(q.x - s.x, q.y - s.y);
      const g = Math.round(Math.atan2(q.y - s.y, q.x - s.x) / (Math.PI / 4)) * (Math.PI / 4);
      b = { x: s.x + Math.cos(g) * d, y: s.y + Math.sin(g) * d };
    }
  } else {
    if (e.shiftKey) {
      const dx = q.x - s.x;
      const dy = q.y - s.y;
      const m = Math.max(Math.abs(dx), Math.abs(dy));
      b = { x: s.x + (dx < 0 ? -m : m), y: s.y + (dy < 0 ? -m : m) };
    }
    if (e.altKey) a = { x: 2 * s.x - b.x, y: 2 * s.y - b.y }; // el punto de inicio es el centro
  }
  if (t === "rectangle" && S.corner > 0) {
    S.cur.kind = "bezier";
    S.cur.closed = true;
    S.cur.points = roundRectPoints(a, b, S.corner);
  } else {
    if (t === "rectangle") {
      S.cur.kind = "rect";
      delete S.cur.closed;
    }
    S.cur.points = [a, b];
  }
}
/** Relleno (polígono) para una forma cerrada, para insertarlo justo debajo de su contorno. */
function fillOf(s) {
  const closed = s.kind === "rect" || s.kind === "ellipse" || (s.kind === "bezier" && s.closed);
  if (!closed) return null;
  return {
    kind: "fill",
    color: S.fillColor,
    size: 1,
    opacity: S.opacity,
    layerId: s.layerId,
    points: pts(s).map((q) => ({ x: q.x, y: q.y })),
  };
}

/* ---------- cuentagotas ---------- */
const hex2 = (v) => v.toString(16).padStart(2, "0");
function setFillColor(c) {
  S.fillColor = c;
  $("fillColor").value = c;
}
function eyedrop(p, e) {
  const s = hit(p);
  let col;
  if (s) col = s.color;
  else {
    const d = ctx.getImageData(Math.round(p.x), Math.round(p.y), 1, 1).data;
    col = "#" + hex2(d[0]) + hex2(d[1]) + hex2(d[2]);
  }
  const asFill = e.shiftKey || (s && s.kind === "fill");
  const targets = !e.altKey ? msel().filter((t) => !owner(t).locked) : [];
  if (targets.length) {
    pushUndo();
    targets.forEach((t) => {
      if (asFill) {
        if (t.kind === "fill") t.color = col;
      } else {
        t.color = col;
        if (s && s.kind !== "fill") {
          t.size = s.size;
          t.opacity = s.opacity;
          if (s.brush && t.kind === "path") t.brush = s.brush;
        }
      }
    });
    dirty();
  }
  if (asFill) setFillColor(col);
  else {
    S.color = col;
    $("strokeColor").value = col;
    if (s && s.kind !== "fill") {
      S.size = s.size;
      S.opacity = s.opacity;
      $("strokeSize").value = s.size;
      $("opacity").value = s.opacity * 100;
      if (s.brush && BR[s.brush]) S.brush = s.brush;
      syncLabels();
      if (typeof brushUI === "function") brushUI();
    }
  }
  render();
  hint(
    (asFill ? "Color de relleno " : "Color de trazo ") +
      col +
      (targets.length ? " aplicado a la selección." : " tomado. (Con trazos seleccionados se les aplica; Alt: solo tomar.)")
  );
}

/* ---------- zoom ---------- */
function zoomRect(x0, y0, x1, y1) {
  const r = $("stage").getBoundingClientRect();
  const w = Math.max(4, Math.abs(x1 - x0));
  const h = Math.max(4, Math.abs(y1 - y0));
  const z = Math.max(0.1, Math.min(32, Math.min((r.width - 40) / w, (r.height - 40) / h)));
  S.zoom = z;
  S.px = r.width / 2 - ((x0 + x1) / 2) * z;
  S.py = r.height / 2 - ((y0 + y1) / 2) * z;
  view();
  render();
}
/** Zoom con el centro en un punto del lienzo. */
function zoomOn(k, p) {
  zoomAt(k, S.px + p.x * S.zoom, S.py + p.y * S.zoom);
  render();
}
