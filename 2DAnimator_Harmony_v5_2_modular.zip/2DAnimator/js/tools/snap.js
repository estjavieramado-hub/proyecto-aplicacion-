/**
 * Imán (snap): ajusta un punto a puntos de otros trazos, al centro/bordes del lienzo,
 * a guías de alineación (mismo X / mismo Y que otro punto) y a la cuadrícula visible.
 * Uso:  const q = Snap.pt(p, {from: puntoAnterior, skip: Set<punto>, skipS: Set<trazo>});
 * Si el imán está apagado devuelve `p` tal cual. Snap.draw(c) pinta la guía activa.
 * Depende de: S, F, owner, pts, $.
 */
"use strict";
const Snap = (() => {
  const GRID = 40;
  /** Puntos «imantables» del fotograma actual. */
  function anchors(o) {
    const out = [];
    F().strokes.forEach((s) => {
      if ((o.skipS && o.skipS.has(s)) || s.kind === "fill" || !owner(s).visible) return;
      let P = s.points;
      if (s.kind === "path") P = [P[0], P.at(-1)];
      else if (s.kind === "rect") P = pts(s).slice(0, 4);
      else if (s.kind === "ellipse") {
        const a = P[0],
          b = P.at(-1),
          cx = (a.x + b.x) / 2,
          cy = (a.y + b.y) / 2;
        P = [
          { x: cx, y: a.y },
          { x: b.x, y: cy },
          { x: cx, y: b.y },
          { x: a.x, y: cy },
          { x: cx, y: cy },
        ];
      }
      P.forEach((q) => q && !(o.skip && o.skip.has(q)) && out.push(q));
    });
    out.push(
      { x: 0, y: 0 },
      { x: S.width, y: 0 },
      { x: 0, y: S.height },
      { x: S.width, y: S.height },
      { x: S.width / 2, y: S.height / 2 }
    );
    return out;
  }
  function pt(p, o = {}) {
    S.snapInfo = null;
    if (!S.snap || !p) return p;
    const r = 9 / S.zoom;
    const A = anchors(o);
    let best = null,
      bd = r;
    for (const q of A) {
      const d = Math.hypot(q.x - p.x, q.y - p.y);
      if (d < bd) {
        bd = d;
        best = q;
      }
    }
    if (best) {
      S.snapInfo = { kind: "point", x: best.x, y: best.y };
      return { x: best.x, y: best.y };
    }
    let x = p.x,
      y = p.y,
      gx = null,
      gy = null;
    const refs = o.from ? [o.from, ...A] : A;
    let dx = r * 0.7,
      dy = r * 0.7;
    for (const q of refs) {
      if (Math.abs(q.x - p.x) < dx) {
        dx = Math.abs(q.x - p.x);
        x = q.x;
        gx = q.x;
      }
      if (Math.abs(q.y - p.y) < dy) {
        dy = Math.abs(q.y - p.y);
        y = q.y;
        gy = q.y;
      }
    }
    if ($("showGrid").checked) {
      if (gx === null) {
        const g = Math.round(p.x / GRID) * GRID;
        if (Math.abs(g - p.x) < r) {
          x = g;
          gx = g;
        }
      }
      if (gy === null) {
        const g = Math.round(p.y / GRID) * GRID;
        if (Math.abs(g - p.y) < r) {
          y = g;
          gy = g;
        }
      }
    }
    if (gx !== null || gy !== null) S.snapInfo = { kind: "guide", x, y, gx, gy };
    return { x, y };
  }
  const clear = () => {
    S.snapInfo = null;
  };
  function draw(c) {
    const i = S.snapInfo;
    if (!i || !S.snap) return;
    c.save();
    c.lineWidth = 1 / S.zoom;
    c.strokeStyle = "#ff2d95";
    c.setLineDash([5 / S.zoom, 4 / S.zoom]);
    if (i.gx != null) {
      c.beginPath();
      c.moveTo(i.gx, 0);
      c.lineTo(i.gx, S.height);
      c.stroke();
    }
    if (i.gy != null) {
      c.beginPath();
      c.moveTo(0, i.gy);
      c.lineTo(S.width, i.gy);
      c.stroke();
    }
    c.setLineDash([]);
    c.beginPath();
    c.arc(i.x, i.y, 6 / S.zoom, 0, 7);
    c.stroke();
    c.restore();
  }
  return { pt, clear, draw };
})();
