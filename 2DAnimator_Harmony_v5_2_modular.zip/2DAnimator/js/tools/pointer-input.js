/**
 * Entrada de puntero sobre el lienzo: pointerdown/move/up, doble clic, presión e inclinación del lápiz.
 * Reparte los eventos entre las herramientas: Pluma (pen.js), Nodos y Tijeras (node-edit.js),
 * Selección con asas (selection-tools.js), Borrador (eraser.js), Cuentagotas, Zoom y formas (extra-tools.js).
 */
"use strict";
const pt = (e) => {
  const r = cv.getBoundingClientRect();
  return { x: ((e.clientX - r.left) * cv.width) / r.width, y: ((e.clientY - r.top) * cv.height) / r.height };
};
const SHAPES = { rectangle: "rect", ellipse: "ellipse", line: "line", polygon: "bezier", star: "bezier" };

cv.addEventListener("pointerdown", (e) => {
  if (S.tool === "hand" || e.button === 1 || S.space) {
    S.pan = { x: e.clientX - S.px, y: e.clientY - S.py };
    cv.setPointerCapture(e.pointerId);
    return;
  }
  if (e.button !== 0 || S.playing) return;
  if (S.tool === "xform" || S.tool === "bone" || S.tool === "pose") return;
  if (S.final && S.layers.some(hasXf)) {
    hint("Desactiva «Vista final» (panel Transformación) para dibujar o editar.");
    return;
  }
  const t = S.tool,
    p = pt(e);
  S.mouse = p;
  if (t === "zoom") {
    S.marquee = { mode: "zoom", x0: p.x, y0: p.y, x1: p.x, y1: p.y };
    cv.setPointerCapture(e.pointerId);
    return;
  }
  if (t === "eyedropper") {
    eyedrop(p, e);
    return;
  }
  if (t === "select" || t === "lasso") {
    if (t === "select" && S.sel && SelXf.start(p)) {
      cv.setPointerCapture(e.pointerId);
      render();
      return;
    }
    const s = t === "select" ? hit(p) : null,
      m = msel();
    if (e.shiftKey && s) {
      S.ms = m.includes(s) ? m.filter((x) => x !== s) : [...m, s];
      S.sel = S.ms.includes(s) ? s : S.ms[0] || null;
      render();
      return;
    }
    if (s) {
      if (!m.includes(s)) S.ms = [s];
      S.sel = s;
      pushUndo();
      if (e.altKey) {
        // Alt + arrastrar: duplica y mueve las copias
        const k = S.ms.indexOf(s),
          copies = clone(S.ms);
        F().strokes.push(...copies);
        S.ms = copies;
        S.sel = copies[k];
      }
      const mm = msel();
      S.drag = { x: p.x, y: p.y, moved: false, m: mm, orig: mm.map((q) => clone(q.points)), box: tbox(mm) };
      cv.setPointerCapture(e.pointerId);
      $("strokeColor").value = s.color;
      $("strokeSize").value = s.size;
      $("opacity").value = s.opacity * 100;
      syncLabels();
    } else {
      if (t === "select") S.marquee = { mode: "select", x0: p.x, y0: p.y, x1: p.x, y1: p.y, add: e.shiftKey };
      else S.lasso = { pts: [p], add: e.shiftKey };
      if (!e.shiftKey) {
        S.sel = null;
        S.ms = [];
      }
      cv.setPointerCapture(e.pointerId);
    }
    render();
    return;
  }
  if (t === "node") {
    cv.setPointerCapture(e.pointerId);
    Node.down(p, e);
    return;
  }
  if (t === "scissors") {
    Node.scissors(p);
    return;
  }
  if (!L().visible || L().locked) return hint("La capa activa está oculta o bloqueada.");
  cv.setPointerCapture(e.pointerId);
  if (t === "fill") {
    fillAt(p);
    return;
  }
  if (t === "bezier") {
    Pen.down(p, e);
    return;
  }
  if (t === "eraser") {
    S.erasing = true;
    eraseBegin(p);
    return;
  }
  pushUndo();
  S.start = SHAPES[t] && !e.shiftKey ? Snap.pt(p) : p;
  S.pr = 0.6;
  S.lz = { x: p.x, y: p.y };
  const kind = SHAPES[t] || "path";
  S.cur = {
    kind,
    color: S.color,
    size: S.size,
    opacity: S.opacity,
    layerId: L().id,
    points: [kind === "path" ? { x: p.x, y: p.y, w: pres(e, p, null), tl: tilt(e) } : S.start],
  };
  if (t === "polygon" || t === "star") S.cur.closed = true;
  if (kind === "path") S.cur.brush = S.brush;
  render();
});

/** Imán para mover la selección: ajusta la caja (esquinas y centro) a otros puntos. Devuelve [dx, dy]. */
function snapBox(D, dx, dy) {
  const b = D.box,
    skipS = new Set(D.m);
  let best = null;
  for (const c of [
    { x: b.x, y: b.y },
    { x: b.x + b.w, y: b.y },
    { x: b.x, y: b.y + b.h },
    { x: b.x + b.w, y: b.y + b.h },
    { x: b.x + b.w / 2, y: b.y + b.h / 2 },
  ]) {
    const q = Snap.pt({ x: c.x + dx, y: c.y + dy }, { skipS });
    if (!S.snapInfo) continue;
    const ax = q.x - (c.x + dx),
      ay = q.y - (c.y + dy),
      d = Math.hypot(ax, ay);
    if (!best || d < best.d) best = { d, ax, ay, info: S.snapInfo };
  }
  S.snapInfo = best ? best.info : null;
  return best ? [dx + best.ax, dy + best.ay] : [dx, dy];
}

/** Cursor al pasar sobre asas / nodos / tramos (sin botón pulsado). */
function hoverCursor(p) {
  if (S.playing || S.pan || S.space) return;
  if (S.tool === "select") cv.style.cursor = S.sel ? SelXf.cursor(p) : "default";
  else if (S.tool === "node") cv.style.cursor = Node.cursor(p);
  else if (S.tool === "eraser") overlay();
}

cv.addEventListener("pointermove", (e) => {
  if (S.pan) {
    S.px = e.clientX - S.pan.x;
    S.py = e.clientY - S.pan.y;
    view();
    return;
  }
  const p = pt(e);
  S.mouse = p;
  if (S.tool === "bezier") {
    Pen.move(p, e);
    return;
  }
  if (S.xf) {
    SelXf.move(p, e);
    return;
  }
  if (S.nd) {
    Node.move(p, e);
    return;
  }
  if (S.marquee) {
    S.marquee.x1 = p.x;
    S.marquee.y1 = p.y;
    overlay();
    return;
  }
  if (S.drag) {
    const D = S.drag;
    let dx = p.x - D.x,
      dy = p.y - D.y;
    if (!D.moved && Math.hypot(dx, dy) * S.zoom < 3) return;
    D.moved = true;
    if (e.shiftKey) {
      if (Math.abs(dx) > Math.abs(dy)) dy = 0;
      else dx = 0;
      Snap.clear();
    } else if (S.snap) [dx, dy] = snapBox(D, dx, dy);
    D.m.forEach((t, i) =>
      t.points.forEach((q, j) => {
        q.x = D.orig[i][j].x + dx;
        q.y = D.orig[i][j].y + dy;
      })
    );
    render();
    return;
  }
  if (S.lasso) {
    const a = S.lasso.pts.at(-1);
    if (Math.hypot(p.x - a.x, p.y - a.y) * S.zoom > 3) S.lasso.pts.push(p);
    render();
    return;
  }
  if (S.erasing) {
    erase(p);
    return;
  }
  if (!S.cur) {
    hoverCursor(p);
    return;
  }
  if (S.cur.kind === "path") {
    (e.getCoalescedEvents?.() || [e]).forEach((ev) => {
      const q = pt(ev),
        f = 1 / (1 + S.stab * 0.55);
      S.lz.x += (q.x - S.lz.x) * f;
      S.lz.y += (q.y - S.lz.y) * f;
      const a = S.cur.points.at(-1);
      if (Math.hypot(S.lz.x - a.x, S.lz.y - a.y) >= 0.8)
        S.cur.points.push({ x: S.lz.x, y: S.lz.y, w: pres(ev, S.lz, a), tl: tilt(ev) });
    });
  } else shapeUpdate(p, e);
  render();
});
const tilt = (e) =>
  S.tiltOn && e.pointerType === "pen" && (e.tiltX || e.tiltY)
    ? Math.round(Math.min(1, Math.hypot(e.tiltX, e.tiltY) / 70) * 100) / 100
    : undefined;
function pres(e, p, prev) {
  if (!S.press) return 1;
  if (e.pointerType === "pen") return Math.round((e.pressure || 0.5) * 100) / 100;
  if (!prev) return 0.7;
  S.pr =
    S.pr * 0.7 + Math.max(0.3, Math.min(1, 1 - (Math.hypot(p.x - prev.x, p.y - prev.y) * S.zoom) / 50)) * 0.3;
  return Math.round(S.pr * 100) / 100;
}
/** Fin de la marquesina: zoom a una zona o selección de trazos. */
function marqueeDone(e) {
  const M = S.marquee;
  S.marquee = null;
  const big = Math.max(Math.abs(M.x1 - M.x0), Math.abs(M.y1 - M.y0)) * S.zoom > 4;
  if (M.mode === "zoom") {
    if (big) zoomRect(M.x0, M.y0, M.x1, M.y1);
    else zoomOn(e && (e.altKey || e.shiftKey) ? 0.5 : 2, { x: M.x0, y: M.y0 });
    return;
  }
  if (big) marqueeSelect(M);
  else if (!M.add) {
    S.sel = null;
    S.ms = [];
  }
  render();
  tl();
}
function finish(e) {
  Pen.up();
  if (S.pan) {
    S.pan = null;
    return;
  }
  if (S.xf) {
    SelXf.up();
    return;
  }
  if (S.nd) {
    Node.up();
    return;
  }
  if (S.marquee) {
    marqueeDone(e);
    return;
  }
  if (S.drag) {
    if (S.drag.moved) dirty();
    else S.undo.pop();
    S.drag = null;
    Snap.clear();
    render();
    return;
  }
  if (S.lasso) {
    const Lz = S.lasso;
    S.lasso = null;
    lassoDone(Lz);
    return;
  }
  S.erasing = false;
  S.erased = false;
  eraseEnd();
  if (S.cur) {
    const s = S.cur;
    S.cur = null;
    Snap.clear();
    if (s.kind !== "path") {
      const b = tbox([s]);
      if (s.points.length < 2 || Math.max(b.w, b.h) < 2) {
        S.undo.pop();
        render();
        return;
      }
    }
    if (s.kind === "path" && s.points.length > 2)
      for (let i = 0, n = Math.round(S.stab / 2); i < n; i++) s.points = smooth(s.points);
    if (S.fillOn) {
      const f = fillOf(s);
      if (f) commit(f); // el relleno queda debajo del contorno
    }
    commit(s);
    dirty();
    all();
  }
}
["pointerup", "pointercancel", "lostpointercapture"].forEach((n) => cv.addEventListener(n, finish));
cv.addEventListener("dblclick", (e) => {
  const p = pt(e);
  if (S.pen) {
    Pen.end();
    return;
  }
  if (S.tool === "node") {
    Node.dbl(p);
    return;
  }
  if (S.tool === "select") {
    const h = hit(p);
    if (h) {
      S.sel = h;
      setTool("node");
    }
  }
});
