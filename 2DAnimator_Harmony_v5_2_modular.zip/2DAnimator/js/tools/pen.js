/**
 * Herramienta Pluma (Bézier) — comportamiento tipo Adobe Illustrator.
 *
 * DIBUJAR
 *   Clic                  punto de esquina (sin tiradores)
 *   Clic y arrastrar      punto suave (tiradores simétricos)
 *   Shift                 limita el ángulo a múltiplos de 45°
 *   Alt (al arrastrar)    rompe la simetría: solo se mueve el tirador de salida
 *   Alt + arrastrar       desde el último punto: saca un tirador nuevo (esquina tras curva)
 *   Espacio (al arrastrar) mueve el punto que se está colocando
 *   Ctrl / Cmd            selección directa temporal: mover puntos y tiradores
 *   Clic en el 1.er punto cierra el trazo (arrastrar ajusta sus tiradores)
 *   Clic en el último punto   retrae su tirador de salida (curva → esquina)
 *   Retroceso / Supr / Ctrl+Z borra el último punto · Enter termina abierto · Esc cancela
 *   Imán (panel «Borrador e imán»)  ajusta los puntos a otros trazos, guías y cuadrícula
 *   «Rellenar al dibujar»     al cerrar el trazo crea un relleno debajo del contorno
 *
 * EDITAR (sobre el trazo Bézier seleccionado)
 *   Clic en un tramo      añade un punto
 *   Clic en un punto      lo elimina
 *   Alt + clic en punto   convierte suave → esquina · Alt + arrastrar: esquina → suave
 *
 * UNIR
 *   Clic en el extremo de un trazo abierto  continúa dibujándolo
 *   Clic en el extremo de OTRO trazo mientras dibujas  los une
 *
 * API pública: Pen.down/move/up (los llama pointer-input.js), Pen.end/cancel/undoPoint
 * (atajos de teclado), Pen.drawPreview (render/canvas.js) y Pen.drawOverlay (render/overlay.js).
 * Depende de: S, F, L, owner, clone, pushUndo, dirty, all, render, overlay, commit, mirrors,
 * drawStroke, addNode, bez, Snap, fillOf (núcleo, render y herramientas).
 */
"use strict";
const Pen = (() => {
  const HIT_PX = 9; // radio de captura en píxeles de pantalla
  const ACCENT = "#4a9dff";
  let drag = null; // arrastre en curso: {mode: new|close|cusp|convert|edit, ...}
  let hov = { type: "new" }; // qué hay bajo el cursor (decide cursor y resaltado)
  let mouse = null; // última posición del puntero en coordenadas de lienzo

  /* ---------- utilidades ---------- */
  const rad = () => HIT_PX / S.zoom;
  const near = (a, b) => Math.hypot(a.x - b.x, a.y - b.y) < rad();
  const blank = (x, y) => ({ x, y, ix: 0, iy: 0, ox: 0, oy: 0 });
  const hasH = (a, k) => !!(a[k + "x"] || a[k + "y"]);
  const usable = (s) => {
    const o = owner(s);
    return o.visible && !o.locked;
  };
  const reverse = (P) => {
    P.reverse();
    P.forEach((a) => {
      [a.ix, a.ox] = [a.ox, a.ix];
      [a.iy, a.oy] = [a.oy, a.iy];
    });
  };
  /** Punto suave = ambos tiradores existen y son colineales en sentidos opuestos. */
  function isSmooth(a) {
    const lo = Math.hypot(a.ox, a.oy);
    const li = Math.hypot(a.ix, a.iy);
    if (!lo || !li) return false;
    return Math.abs(a.ox * a.iy - a.oy * a.ix) / (lo * li) < 0.02 && a.ox * a.ix + a.oy * a.iy < 0;
  }
  /** Shift: fuerza el ángulo (respecto a `o`) a múltiplos de 45°. */
  function constrain(o, p, e) {
    if (!e || !e.shiftKey) return p;
    const dx = p.x - o.x;
    const dy = p.y - o.y;
    const d = Math.hypot(dx, dy);
    const a = Math.round(Math.atan2(dy, dx) / (Math.PI / 4)) * (Math.PI / 4);
    return { x: o.x + Math.cos(a) * d, y: o.y + Math.sin(a) * d };
  }

  /* ---------- búsquedas bajo el cursor ---------- */
  function hitHandle(s, p) {
    const r = rad();
    for (let i = 0; i < s.points.length; i++) {
      const a = s.points[i];
      for (const k of ["a", "o", "i"]) {
        if (k !== "a" && !hasH(a, k)) continue;
        const q = k === "a" ? a : { x: a.x + a[k + "x"], y: a.y + a[k + "y"] };
        if (Math.hypot(p.x - q.x, p.y - q.y) < r) return { i, k };
      }
    }
    return null;
  }
  function endpointAt(p) {
    const fs = F().strokes;
    for (let n = fs.length - 1; n >= 0; n--) {
      const s = fs[n];
      if (s.kind !== "bezier" || s.closed || s.points.length < 2 || !usable(s)) continue;
      if (near(p, s.points[0])) return { s, end: "start", pt: s.points[0] };
      if (near(p, s.points.at(-1))) return { s, end: "end", pt: s.points.at(-1) };
    }
    return null;
  }
  function nearestOnPath(s, p) {
    const P = s.points;
    const m = s.closed ? P.length : P.length - 1;
    let best = null;
    for (let i = 0; i < m; i++)
      for (let j = 1; j < 16; j++) {
        const q = bez(P[i], P[(i + 1) % P.length], j / 16);
        const d = Math.hypot(q.x - p.x, q.y - p.y);
        if (!best || d < best.d) best = { d, i, t: j / 16 };
      }
    return best;
  }
  /** Decide qué haría un clic en `p` con las teclas de `e` (también elige el cursor). */
  function probe(p, e) {
    const alt = !!(e && e.altKey);
    const ctrl = !!(e && (e.ctrlKey || e.metaKey));
    const s = S.pen;
    if (s) {
      const P = s.points;
      if (ctrl && hitHandle(s, p)) return { type: "edit", s };
      if (alt && P.length && near(p, P.at(-1))) return { type: "cusp" };
      if (!alt && P.length && near(p, P.at(-1)) && hasH(P.at(-1), "o")) return { type: "retract" };
      if (P.length > 2 && near(p, P[0])) return { type: "close" };
      const j = endpointAt(p);
      return j ? { type: "join", ...j } : { type: "new" };
    }
    const sel = S.sel && S.sel.kind === "bezier" && usable(S.sel) ? S.sel : null;
    if (ctrl && sel && hitHandle(sel, p)) return { type: "edit", s: sel };
    const ep = endpointAt(p);
    if (ep && !alt) return { type: "continue", ...ep };
    if (sel) {
      const h = hitHandle(sel, p);
      if (h && h.k === "a") return { type: alt ? "convert" : "delete", s: sel, i: h.i };
      const n = nearestOnPath(sel, p);
      if (n && n.d < 14 / S.zoom) return { type: "add", s: sel };
    }
    return { type: "new" };
  }

  /* ---------- cursores (SVG, punta de la pluma abajo-izquierda) ---------- */
  const BADGE = {
    close: '<circle cx="24.5" cy="26" r="3.4"/>',
    continue: '<path d="M21.5 29.5l6-8"/>',
    join: '<path d="M21 23.5h7M21 28h7"/>',
    add: '<path d="M20.5 26h8M24.5 22v8"/>',
    delete: '<path d="M20.5 26h8"/>',
    convert: '<path d="M20.5 29l4-7 4 7"/>',
    retract: '<path d="M20.5 29l4-7 4 7"/>',
  };
  const cursors = {};
  function cursor(type = "new") {
    if (type === "edit") return "default";
    if (cursors[type]) return cursors[type];
    const b = BADGE[type] || "";
    const svg =
      '<svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 32 32"><g fill="none" stroke-linecap="round" stroke-linejoin="round">' +
      '<path d="M4.5 27.5L8 14.5 19.5 3.5 28 11.5 17 23z" fill="#fff" stroke="#000" stroke-width="1.6"/>' +
      '<path d="M8 14.5l8.5 4.5" stroke="#000" stroke-width="1.4"/>' +
      (b ? `<g stroke="#fff" stroke-width="4">${b}</g><g stroke="#000" stroke-width="1.8">${b}</g>` : "") +
      "</g></svg>";
    return (cursors[type] = `url("data:image/svg+xml,${encodeURIComponent(svg)}") 4 28, crosshair`);
  }
  const setCursor = (type) => {
    cv.style.cursor = S.space ? "grab" : cursor(type);
  };

  /* ---------- ciclo de vida del trazo en curso ---------- */
  function newPath() {
    pushUndo();
    S.sel = null;
    S.ms = [];
    S.nodeSel = -1;
    S.nodes = [];
    S.pen = {
      kind: "bezier",
      color: S.color,
      size: S.size,
      opacity: S.opacity,
      layerId: L().id,
      closed: false,
      points: [],
    };
  }
  /** Retoma un trazo abierto desde uno de sus extremos (se saca del fotograma mientras se edita). */
  function resume(info) {
    const s = info.s;
    const fs = F().strokes;
    pushUndo();
    s.cont = { idx: fs.indexOf(s), backup: clone({ points: s.points, closed: s.closed }) };
    fs.splice(s.cont.idx, 1);
    if (info.end === "start") reverse(s.points);
    S.pen = s;
    S.sel = null;
    S.ms = [];
  }
  function restoreOriginal(s) {
    const c = s.cont;
    s.points = c.backup.points;
    s.closed = c.backup.closed;
    F().strokes.splice(Math.min(c.idx, F().strokes.length), 0, s);
    delete s.cont;
  }
  function end() {
    const s = S.pen;
    if (!s) return;
    S.pen = null;
    drag = null;
    S.hover = null;
    Snap.clear();
    hov = { type: "new" };
    s.points = s.points.filter((q, i, a) => !i || Math.hypot(q.x - a[i - 1].x, q.y - a[i - 1].y) > 2);
    const cont = s.cont;
    delete s.cont;
    if (s.points.length < 2) {
      if (cont) {
        s.cont = cont;
        restoreOriginal(s);
      }
      S.undo.pop();
      render();
      return;
    }
    if (cont) F().strokes.splice(Math.min(cont.idx, F().strokes.length), 0, s);
    else {
      // trazo nuevo: aplica simetría (y relleno debajo si «Rellenar al dibujar» está activo)
      const f = S.fillOn && s.closed ? fillOf(s) : null;
      if (f) commit(f);
      commit(s);
    }
    S.sel = s;
    S.ms = [s];
    S.nodeSel = -1;
    dirty();
    all();
  }
  function cancel() {
    const s = S.pen;
    if (!s) return;
    S.pen = null;
    drag = null;
    S.hover = null;
    Snap.clear();
    hov = { type: "new" };
    if (s.cont) restoreOriginal(s);
    S.undo.pop();
    render();
  }
  /** Retroceso / Supr mientras se dibuja: quita el último punto. */
  function undoPoint() {
    const s = S.pen;
    if (!s) return;
    drag = null;
    s.points.pop();
    if (!s.points.length) return cancel();
    render();
  }
  function join(info) {
    const s = S.pen;
    const Q = info.s.points.map((a) => ({ ...a }));
    if (info.end === "end") reverse(Q); // el punto de unión pasa a ser el primero
    s.points.push(...Q);
    F().strokes.splice(F().strokes.indexOf(info.s), 1);
    end();
  }
  function removeAnchor(s, i) {
    pushUndo();
    if (s.points.length <= 2) {
      F().strokes.splice(F().strokes.indexOf(s), 1);
      S.sel = null;
    } else {
      s.points.splice(i, 1);
      if (s.closed && s.points.length < 3) s.closed = false;
    }
    S.nodeSel = -1;
    S.nodes = [];
    dirty();
    all();
  }
  function place(p, e) {
    if (!S.pen) newPath();
    const P = S.pen.points;
    const last = P.at(-1);
    const q = last ? constrain(last, e && e.shiftKey ? p : Snap.pt(p, { from: last }), e) : e && e.shiftKey ? p : Snap.pt(p);
    const a = blank(q.x, q.y);
    P.push(a);
    drag = { mode: "new", a, last: p, moved: false };
    render();
  }

  /* ---------- eventos de puntero ---------- */
  function down(p, e) {
    mouse = p;
    hov = probe(p, e);
    const s = S.pen;
    switch (hov.type) {
      case "edit": {
        const h = hitHandle(hov.s, p);
        if (!s) pushUndo();
        drag = {
          mode: "edit",
          s: hov.s,
          i: h.i,
          k: h.k,
          last: p,
          moved: false,
          undo: !s,
          smooth: isSmooth(hov.s.points[h.i]),
        };
        S.nodeSel = h.i;
        S.nodes = [h.i];
        render();
        return;
      }
      case "cusp":
        drag = { mode: "cusp", a: s.points.at(-1), o: p, moved: false };
        return;
      case "retract": {
        const a = s.points.at(-1);
        a.ox = a.oy = 0;
        render();
        return;
      }
      case "close":
        s.closed = true;
        drag = { mode: "close", a: s.points[0], last: p, moved: false };
        render();
        return;
      case "join":
        join(hov);
        return;
      case "continue":
        resume(hov);
        S.hover = p;
        drag = { mode: "cusp", a: S.pen.points.at(-1), o: p, moved: false, keep: true }; // keep: un clic sin arrastrar conserva su tirador
        hov = { type: "new" };
        render();
        return;
      case "delete":
        removeAnchor(hov.s, hov.i);
        return;
      case "convert": {
        pushUndo();
        const a = hov.s.points[hov.i];
        drag = { mode: "convert", a, o: p, moved: false, had: hasH(a, "o") || hasH(a, "i") };
        S.nodeSel = hov.i;
        return;
      }
      case "add":
        pushUndo();
        if (addNode(hov.s, p)) {
          dirty();
          render();
        } else S.undo.pop();
        return;
      default:
        place(p, e);
    }
  }

  function dragMove(p, e) {
    const d = drag;
    const far = (a, b) => Math.hypot(a.x - b.x, a.y - b.y) * S.zoom >= 3;
    if (d.mode === "new" || d.mode === "close") {
      const a = d.a;
      if (S.space) {
        // Espacio: reposiciona el punto sin cambiar sus tiradores
        a.x += p.x - d.last.x;
        a.y += p.y - d.last.y;
        d.last = p;
        render();
        return;
      }
      d.last = p;
      const h = constrain(a, p, e);
      if (!d.moved && !far(h, a)) return;
      d.moved = true;
      a.ox = h.x - a.x;
      a.oy = h.y - a.y;
      if (!(e.altKey && d.mode === "new")) {
        a.ix = -a.ox;
        a.iy = -a.oy;
      } // con Alt el tirador de entrada se queda como estaba
    } else if (d.mode === "cusp") {
      const a = d.a;
      const h = constrain(a, p, e);
      if (!d.moved && !far(h, a)) return;
      d.moved = true;
      a.ox = h.x - a.x; // solo el tirador de salida
      a.oy = h.y - a.y;
    } else if (d.mode === "convert") {
      const a = d.a;
      if (!d.moved && !far(p, d.o)) return;
      d.moved = true;
      const h = constrain(a, p, e);
      a.ox = h.x - a.x;
      a.oy = h.y - a.y;
      a.ix = -a.ox;
      a.iy = -a.oy;
    } else if (d.mode === "edit") {
      const a = d.s.points[d.i];
      d.moved = true;
      if (d.k === "a") {
        a.x += p.x - d.last.x;
        a.y += p.y - d.last.y;
        d.last = p;
      } else {
        const h = constrain(a, p, e);
        const dx = h.x - a.x;
        const dy = h.y - a.y;
        const other = d.k === "o" ? "i" : "o";
        a[d.k + "x"] = dx;
        a[d.k + "y"] = dy;
        if (d.smooth && !e.altKey) {
          // punto suave: el otro tirador mantiene su longitud y gira con este
          const len = Math.hypot(a[other + "x"], a[other + "y"]);
          const m = Math.hypot(dx, dy) || 1;
          a[other + "x"] = (-dx / m) * len;
          a[other + "y"] = (-dy / m) * len;
        }
      }
    }
    render();
  }

  function move(p, e) {
    mouse = p;
    if (drag) return dragMove(p, e);
    hov = probe(p, e);
    setCursor(hov.type);
    const sp = e.shiftKey || hov.type !== "new" ? p : Snap.pt(p, { from: S.pen ? S.pen.points.at(-1) : null });
    if (hov.type !== "new" || e.shiftKey) Snap.clear();
    if (S.pen) {
      const last = S.pen.points.at(-1);
      S.hover = last ? constrain(last, sp, e) : sp;
      render();
    } else overlay();
  }

  function up() {
    const d = drag;
    if (!d) return;
    drag = null;
    if (d.mode === "close") return end();
    if (d.mode === "cusp" && !d.moved && !d.keep) d.a.ox = d.a.oy = 0; // clic sin arrastrar: sin tirador de salida
    if (d.mode === "convert") {
      if (!d.moved && !d.had)
        S.undo.pop(); // clic sobre una esquina: no hay nada que cambiar
      else {
        if (!d.moved) d.a.ox = d.a.oy = d.a.ix = d.a.iy = 0; // clic sobre un punto suave: pasa a esquina
        dirty();
      }
    }
    if (d.mode === "edit" && d.undo) {
      if (d.moved) dirty();
      else S.undo.pop();
    }
    render();
  }

  /* ---------- dibujo de la vista previa y de los nodos ---------- */
  /** Trazo en curso + segmento elástico hasta el cursor (y simetría). */
  function drawPreview(c) {
    const s = S.pen;
    if (!s) return;
    const P = s.points.slice();
    if (S.hover && P.length && !drag && !s.closed) P.push(blank(S.hover.x, S.hover.y));
    const tmp = { ...s, points: P };
    drawStroke(c, tmp);
    mirrors(tmp).forEach((m) => drawStroke(c, m));
  }
  function drawNodes(c, s, showAllHandles, active) {
    const z = S.zoom;
    const r = 4.5 / z;
    const P = s.points;
    c.save();
    c.lineWidth = 1.2 / z;
    P.forEach((a, i) => {
      if (!showAllHandles && i < P.length - 2) return; // al dibujar: solo los dos últimos puntos
      for (const k of ["o", "i"]) {
        if (!hasH(a, k)) continue;
        const hx = a.x + a[k + "x"];
        const hy = a.y + a[k + "y"];
        c.strokeStyle = "#6b7785";
        c.beginPath();
        c.moveTo(a.x, a.y);
        c.lineTo(hx, hy);
        c.stroke();
        c.fillStyle = "#fff";
        c.strokeStyle = ACCENT;
        c.beginPath();
        c.arc(hx, hy, r * 0.8, 0, 7);
        c.fill();
        c.stroke();
      }
    });
    P.forEach((a, i) => {
      c.fillStyle = i === active ? ACCENT : "#fff";
      c.strokeStyle = ACCENT;
      c.beginPath();
      c.rect(a.x - r, a.y - r, 2 * r, 2 * r);
      c.fill();
      c.stroke();
    });
    c.restore();
  }
  function drawOverlay(c) {
    if (S.tool !== "bezier") return;
    const s = S.pen || (S.sel && S.sel.kind === "bezier" ? S.sel : null);
    if (!s) return;
    drawNodes(c, s, !S.pen, S.pen ? s.points.length - 1 : S.nodeSel);
    const ring = (q) => {
      c.beginPath();
      c.arc(q.x, q.y, 8 / S.zoom, 0, 7);
      c.stroke();
    };
    c.save();
    c.lineWidth = 2 / S.zoom;
    c.strokeStyle = ACCENT;
    if (hov.type === "close" && S.pen) ring(S.pen.points[0]);
    if ((hov.type === "continue" || hov.type === "join") && hov.pt) ring(hov.pt);
    c.restore();
  }

  /* Alt / Ctrl / Shift cambian lo que haría un clic: refresca el cursor y la vista previa sin mover el ratón. */
  function refresh(e) {
    if (S.tool !== "bezier" || !mouse || drag) return;
    hov = probe(mouse, e);
    setCursor(hov.type);
    const sp = e.shiftKey || hov.type !== "new" ? mouse : Snap.pt(mouse, { from: S.pen ? S.pen.points.at(-1) : null });
    if (S.pen) {
      const last = S.pen.points.at(-1);
      S.hover = last ? constrain(last, sp, e) : sp;
      render();
    } else overlay();
  }
  ["keydown", "keyup"].forEach((t) =>
    window.addEventListener(t, (e) => {
      if (!["Alt", "Control", "Meta", "Shift"].includes(e.key)) return;
      if (e.key === "Alt" && S.tool === "bezier") e.preventDefault(); // evita que Alt active el menú del navegador
      refresh(e);
    })
  );

  return { down, move, up, end, cancel, undoPoint, drawPreview, drawOverlay, cursor };
})();
