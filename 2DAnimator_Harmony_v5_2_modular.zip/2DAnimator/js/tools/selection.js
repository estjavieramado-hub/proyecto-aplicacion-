/**
 * Selección: caja envolvente, lazo y seleccionar todo.
 */
"use strict";
const bbox = (m) => {
  let x0 = 1e9,
    y0 = 1e9,
    x1 = -1e9,
    y1 = -1e9;
  m.forEach((s) => {
    const g = s.size / 2 + 6;
    pts(s).forEach((p) => {
      x0 = Math.min(x0, p.x - g);
      y0 = Math.min(y0, p.y - g);
      x1 = Math.max(x1, p.x + g);
      y1 = Math.max(y1, p.y + g);
    });
  });
  return { x: x0, y: y0, w: x1 - x0, h: y1 - y0 };
};
function lassoDone(Lz) {
  const q = Lz.pts;
  if (q.length < 3) {
    render();
    tl();
    return;
  }
  const f = F().strokes.filter((s) => {
    const o = owner(s);
    if (!o.visible || o.locked) return false;
    const P = pts(s);
    return P.length && P.filter((a) => inPoly(a, q)).length / P.length >= 0.5;
  });
  S.ms = Lz.add ? [...new Set([...msel(), ...f])] : f;
  S.sel = S.ms[0] || null;
  render();
  hint(
    S.ms.length
      ? S.ms.length + " trazo(s) seleccionado(s). Arrastra para mover, usa Transformar o Supr."
      : "El lazo no encierra ningún trazo."
  );
}
function selAll() {
  if (S.tool !== "select" && S.tool !== "lasso") setTool("select");
  S.ms = F().strokes.filter((s) => {
    const o = owner(s);
    return o.visible && !o.locked;
  });
  S.sel = S.ms[0] || null;
  render();
  hint(S.ms.length + " trazo(s) seleccionado(s).");
}
