/**
 * Herramienta Selección (V) ampliada, como en Illustrator:
 *   · Asas de la caja de selección: escalar (Shift = proporcional, Alt = desde el centro) y rotar
 *     (arrastra justo fuera de una esquina; Shift = pasos de 15°)
 *   · Alt + arrastrar duplica · Shift + arrastrar limita a ejes · el imán ajusta la caja a otros puntos
 *   · Marquesina rectangular en vacío (el lazo sigue en su herramienta)
 *   · Copiar / Cortar / Pegar / Duplicar, Orden (al frente, atrás…) y Alinear / Distribuir
 *   · Flechas: empujar la selección (Shift = 10 px)
 * Depende de: S, F, L, owner, clone, msel, pts, pushUndo, dirty, all, render, hint, toBezier, setTool, delSel, Snap.
 */
"use strict";
/** Caja ajustada a la geometría (sin el margen del grosor). */
function tbox(m) {
  let x0 = 1e9,
    y0 = 1e9,
    x1 = -1e9,
    y1 = -1e9;
  m.forEach((s) =>
    pts(s).forEach((p) => {
      x0 = Math.min(x0, p.x);
      y0 = Math.min(y0, p.y);
      x1 = Math.max(x1, p.x);
      y1 = Math.max(y1, p.y);
    })
  );
  return x0 > x1 ? { x: 0, y: 0, w: 0, h: 0 } : { x: x0, y: y0, w: x1 - x0, h: y1 - y0 };
}
const moveBy = (s, dx, dy) =>
  s.points.forEach((q) => {
    q.x += dx;
    q.y += dy;
  });
const unlocked = (m) => m.filter((s) => !owner(s).locked);

const SelXf = (() => {
  /* nombre, fracción x, fracción y, afecta a x, afecta a y, cursor */
  const H = [
    ["nw", 0, 0, 1, 1, "nwse-resize"],
    ["n", 0.5, 0, 0, 1, "ns-resize"],
    ["ne", 1, 0, 1, 1, "nesw-resize"],
    ["e", 1, 0.5, 1, 0, "ew-resize"],
    ["se", 1, 1, 1, 1, "nwse-resize"],
    ["s", 0.5, 1, 0, 1, "ns-resize"],
    ["sw", 0, 1, 1, 1, "nesw-resize"],
    ["w", 0, 0.5, 1, 0, "ew-resize"],
  ];
  const handles = (b) => H.map(([k, fx, fy, ax, ay, cur]) => ({ k, x: b.x + b.w * fx, y: b.y + b.h * fy, fx: ax, fy: ay, cur, ox: b.x + b.w * (1 - fx), oy: b.y + b.h * (1 - fy) }));
  const active = () => (S.tool === "select" ? unlocked(msel()) : []);

  /** ¿Qué hay bajo el puntero? {mode:'scale'|'rotate', h} o null. */
  function probe(p) {
    const m = active();
    if (!m.length) return null;
    const b = tbox(m);
    const r = 6 / S.zoom;
    const hs = handles(b);
    for (const h of hs) if (Math.hypot(p.x - h.x, p.y - h.y) <= r) return { mode: "scale", h, b, m };
    for (const h of hs.filter((q) => q.fx && q.fy))
      if (Math.hypot(p.x - h.x, p.y - h.y) <= 20 / S.zoom) return { mode: "rotate", h, b, m };
    return null;
  }
  function cursor(p) {
    const q = probe(p);
    return q ? (q.mode === "rotate" ? "crosshair" : q.h.cur) : "default";
  }
  function start(p) {
    const q = probe(p);
    if (!q) return false;
    pushUndo();
    S.xf = {
      mode: q.mode,
      h: q.h,
      b: q.b,
      m: q.m,
      p0: p,
      orig: q.m.map((s) => clone(s.points)),
      moved: false,
      conv: false,
    };
    return true;
  }
  function apply(M) {
    const X = S.xf;
    X.m.forEach((s, i) => {
      s.points = X.orig[i].map((q) => {
        const r = { ...q, x: M.a * q.x + M.c * q.y + M.e, y: M.b * q.x + M.d * q.y + M.f };
        if (s.kind === "bezier")
          ["i", "o"].forEach((k) => {
            const vx = q[k + "x"];
            const vy = q[k + "y"];
            r[k + "x"] = M.a * vx + M.c * vy;
            r[k + "y"] = M.b * vx + M.d * vy;
          });
        return r;
      });
    });
  }
  function move(p, e) {
    const X = S.xf;
    if (!X) return;
    if (!X.moved && Math.hypot(p.x - X.p0.x, p.y - X.p0.y) * S.zoom < 3) return;
    X.moved = true;
    if (X.mode === "scale") {
      const h = X.h;
      const c = { x: X.b.x + X.b.w / 2, y: X.b.y + X.b.h / 2 };
      const ax = e.altKey ? c.x : h.ox;
      const ay = e.altKey ? c.y : h.oy;
      let sx = 1;
      let sy = 1;
      if (h.fx && Math.abs(h.x - ax) > 1e-6) sx = (p.x - ax) / (h.x - ax);
      if (h.fy && Math.abs(h.y - ay) > 1e-6) sy = (p.y - ay) / (h.y - ay);
      if (e.shiftKey) {
        if (h.fx && h.fy) {
          const den = (h.x - ax) ** 2 + (h.y - ay) ** 2 || 1;
          sx = sy = ((p.x - ax) * (h.x - ax) + (p.y - ay) * (h.y - ay)) / den;
        } else if (h.fx) sy = sx;
        else sx = sy;
      }
      apply({ a: sx, b: 0, c: 0, d: sy, e: ax - sx * ax, f: ay - sy * ay });
    } else {
      if (!X.conv) {
        X.conv = true;
        X.m.forEach((s, i) => {
          if (s.kind === "rect" || s.kind === "ellipse") {
            toBezier(s);
            X.orig[i] = clone(s.points);
          }
        });
      }
      const c = { x: X.b.x + X.b.w / 2, y: X.b.y + X.b.h / 2 };
      let th = Math.atan2(p.y - c.y, p.x - c.x) - Math.atan2(X.p0.y - c.y, X.p0.x - c.x);
      if (e.shiftKey) th = Math.round(th / (Math.PI / 12)) * (Math.PI / 12);
      const cs = Math.cos(th);
      const sn = Math.sin(th);
      apply({ a: cs, b: sn, c: -sn, d: cs, e: c.x - (cs * c.x - sn * c.y), f: c.y - (sn * c.x + cs * c.y) });
    }
    render();
  }
  function up() {
    const X = S.xf;
    S.xf = null;
    if (!X) return;
    if (X.moved) dirty();
    else S.undo.pop();
    render();
  }
  function draw(c) {
    const m = active();
    if (!m.length) return;
    const b = tbox(m);
    const z = S.zoom;
    const r = 4.5 / z;
    c.save();
    c.lineWidth = 1 / z;
    c.strokeStyle = "#4a9dff";
    c.setLineDash([]);
    c.strokeRect(b.x, b.y, b.w, b.h);
    c.fillStyle = "#fff";
    handles(b).forEach((h) => {
      c.beginPath();
      c.rect(h.x - r, h.y - r, 2 * r, 2 * r);
      c.fill();
      c.stroke();
    });
    c.restore();
  }
  return { probe, cursor, start, move, up, draw };
})();

/* ---------- marquesina rectangular (selección) ---------- */
function segHitsRect(a, b, r) {
  let t0 = 0;
  let t1 = 1;
  const dx = b.x - a.x;
  const dy = b.y - a.y;
  const P = [-dx, dx, -dy, dy];
  const Q = [a.x - r.x0, r.x1 - a.x, a.y - r.y0, r.y1 - a.y];
  for (let i = 0; i < 4; i++) {
    if (P[i] === 0) {
      if (Q[i] < 0) return false;
    } else {
      const t = Q[i] / P[i];
      if (P[i] < 0) {
        if (t > t1) return false;
        if (t > t0) t0 = t;
      } else {
        if (t < t0) return false;
        if (t < t1) t1 = t;
      }
    }
  }
  return true;
}
function strokeInRect(s, r) {
  const q = pts(s);
  if (!q.length) return false;
  if (q.length === 1) return q[0].x >= r.x0 && q[0].x <= r.x1 && q[0].y >= r.y0 && q[0].y <= r.y1;
  for (let i = 1; i < q.length; i++) if (segHitsRect(q[i - 1], q[i], r)) return true;
  return s.kind === "fill" && inPoly({ x: (r.x0 + r.x1) / 2, y: (r.y0 + r.y1) / 2 }, q);
}
function marqueeSelect(M) {
  const r = {
    x0: Math.min(M.x0, M.x1),
    x1: Math.max(M.x0, M.x1),
    y0: Math.min(M.y0, M.y1),
    y1: Math.max(M.y0, M.y1),
  };
  const f = F().strokes.filter((s) => {
    const o = owner(s);
    return o.visible && !o.locked && strokeInRect(s, r);
  });
  S.ms = M.add ? [...new Set([...msel(), ...f])] : f;
  S.sel = S.ms[0] || null;
  hint(S.ms.length ? S.ms.length + " trazo(s) seleccionado(s)." : "La marquesina no toca ningún trazo.");
}

/* ---------- empujar con las flechas ---------- */
let nudgeAt = 0;
/** Devuelve true si había algo que empujar (nodos seleccionados o trazos). */
function nudgeSel(dx, dy) {
  if (S.tool === "node" && Node.nudge(dx, dy)) return true;
  const m = unlocked(msel());
  if (!m.length || S.tool === "bezier" || S.tool === "node") return false;
  if (Date.now() - nudgeAt > 700) pushUndo();
  nudgeAt = Date.now();
  m.forEach((s) => moveBy(s, dx, dy));
  dirty();
  render();
  return true;
}

/* ---------- portapapeles, duplicar ---------- */
function intoLayer(s) {
  const l = S.layers.find((x) => x.id === s.layerId);
  if (!l || l.locked || !l.visible) s.layerId = L().id;
  return s;
}
function keepSelectTool() {
  if (!["select", "lasso", "node"].includes(S.tool)) setTool("select");
}
function copySel(cutIt) {
  const m = msel();
  if (!m.length) return hint("Selecciona algo para copiar.");
  S.clip = clone(m);
  if (cutIt) delSel();
  else hint(m.length + " trazo(s) copiado(s). Pega con Ctrl+V (también en otros fotogramas).");
}
function pasteSel(off = 0) {
  if (!S.clip.length) return hint("El portapapeles está vacío.");
  pushUndo();
  const n = clone(S.clip).map((s) => {
    intoLayer(s);
    if (off) moveBy(s, off, off);
    return s;
  });
  F().strokes.push(...n);
  keepSelectTool();
  S.ms = n;
  S.sel = n[0];
  dirty();
  all();
}
function dupSel() {
  const m = unlocked(msel());
  if (!m.length) return hint("Selecciona algo para duplicar.");
  pushUndo();
  const n = clone(m).map((s) => {
    moveBy(s, 16, 16);
    return s;
  });
  F().strokes.push(...n);
  S.ms = n;
  S.sel = n[0];
  dirty();
  all();
}

/* ---------- orden de apilado (dentro de su capa) ---------- */
function arrange(mode) {
  const m = msel();
  if (!m.length) return hint("Selecciona algo para reordenar.");
  pushUndo();
  const fs = F().strokes;
  const a = fs.slice();
  if (mode === "front") F().strokes = [...fs.filter((s) => !m.includes(s)), ...fs.filter((s) => m.includes(s))];
  else if (mode === "back") F().strokes = [...fs.filter((s) => m.includes(s)), ...fs.filter((s) => !m.includes(s))];
  else if (mode === "fwd") {
    for (let i = a.length - 2; i >= 0; i--) if (m.includes(a[i]) && !m.includes(a[i + 1])) [a[i], a[i + 1]] = [a[i + 1], a[i]];
    F().strokes = a;
  } else {
    for (let i = 1; i < a.length; i++) if (m.includes(a[i]) && !m.includes(a[i - 1])) [a[i], a[i - 1]] = [a[i - 1], a[i]];
    F().strokes = a;
  }
  dirty();
  all();
  hint("El orden solo afecta a trazos de la misma capa; las capas se apilan según el panel de capas.");
}

/* ---------- alinear y distribuir ---------- */
function align(mode) {
  const m = unlocked(msel());
  if (!m.length) return hint("Selecciona trazos para alinear.");
  const dist = mode === "dh" || mode === "dv";
  if (dist && m.length < 3) return hint("Para distribuir hacen falta al menos 3 trazos.");
  pushUndo();
  if (dist) {
    const hz = mode === "dh";
    const items = m
      .map((s) => ({ s, b: tbox([s]) }))
      .map((o) => ({ ...o, c: hz ? o.b.x + o.b.w / 2 : o.b.y + o.b.h / 2 }))
      .sort((p, q) => p.c - q.c);
    const first = items[0].c;
    const step = (items.at(-1).c - first) / (items.length - 1);
    items.forEach((o, i) => {
      const d = first + step * i - o.c;
      moveBy(o.s, hz ? d : 0, hz ? 0 : d);
    });
  } else {
    // con varios trazos se alinea a su caja común; con uno solo, al lienzo
    const ref = m.length > 1 ? tbox(m) : { x: 0, y: 0, w: S.width, h: S.height };
    m.forEach((s) => {
      const b = tbox([s]);
      let dx = 0;
      let dy = 0;
      if (mode === "l") dx = ref.x - b.x;
      else if (mode === "c") dx = ref.x + ref.w / 2 - (b.x + b.w / 2);
      else if (mode === "r") dx = ref.x + ref.w - (b.x + b.w);
      else if (mode === "t") dy = ref.y - b.y;
      else if (mode === "m") dy = ref.y + ref.h / 2 - (b.y + b.h / 2);
      else if (mode === "b") dy = ref.y + ref.h - (b.y + b.h);
      moveBy(s, dx, dy);
    });
  }
  dirty();
  render();
}
