/**
 * Transformar selección: rotar, escalar, reflejar, inclinar y perspectiva.
 */
"use strict";
function xform(T, V, rot, k = 1) {
  const m = msel().filter((s) => !owner(s).locked);
  if (!m.length) return hint("Selecciona uno o más trazos (clic, Shift+clic o lazo).");
  pushUndo();
  const b = bbox(msel()),
    cx = b.x + b.w / 2,
    cy = b.y + b.h / 2;
  m.forEach((s) => {
    if (rot && (s.kind === "rect" || s.kind === "ellipse")) toBezier(s);
    s.points.forEach((p) => {
      const q = T(p.x - cx, p.y - cy);
      p.x = cx + q[0];
      p.y = cy + q[1];
      if (s.kind === "bezier")
        ["i", "o"].forEach((c) => {
          const v = V(p[c + "x"], p[c + "y"]);
          p[c + "x"] = v[0];
          p[c + "y"] = v[1];
        });
    });
    s.size = Math.max(0.5, Math.min(500, s.size * k));
  });
  dirty();
  render();
}
function warp(f) {
  const m = msel().filter((t) => !owner(t).locked);
  if (!m.length) return hint("Selecciona uno o más trazos (clic, Shift+clic o lazo).");
  pushUndo();
  m.forEach((t) => {
    if (t.kind === "rect" || t.kind === "ellipse") toBezier(t);
    t.points.forEach((p) => {
      const q = f(p.x, p.y);
      if (t.kind === "bezier")
        ["i", "o"].forEach((c) => {
          const v = f(p.x + p[c + "x"], p.y + p[c + "y"]);
          p[c + "x"] = v[0] - q[0];
          p[c + "y"] = v[1] - q[1];
        });
      p.x = q[0];
      p.y = q[1];
    });
  });
  dirty();
  render();
}
const rotM = (g) => {
  const r = (g * Math.PI) / 180,
    c = Math.cos(r),
    n = Math.sin(r);
  return (x, y) => [x * c - y * n, x * n + y * c];
};
document.querySelectorAll("[data-xf]").forEach(
  (b) =>
    (b.onclick = () => {
      const a = b.dataset.xf,
        d = num($("xfAngle").value, 15, -360, 360),
        k = num($("xfScale").value, 100, 5, 1000) / 100;
      if (a === "rl") xform(rotM(-d), rotM(-d), 1);
      else if (a === "rr") xform(rotM(d), rotM(d), 1);
      else if (a === "sc") {
        const f = (x, y) => [x * k, y * k];
        xform(f, f, 0, k);
      } else if (a === "fh") {
        const f = (x, y) => [-x, y];
        xform(f, f, 0);
      } else if (a === "fv") {
        const f = (x, y) => [x, -y];
        xform(f, f, 0);
      } else {
        const b = bbox(msel()),
          cx = b.x + b.w / 2,
          cy = b.y + b.h / 2,
          g = Math.tan((Math.max(-75, Math.min(75, d)) * Math.PI) / 180),
          k = num($("xfPersp").value, 70, 10, 100) / 100;
        warp(
          a === "shx"
            ? (x, y) => [x + (y - cy) * g, y]
            : a === "shy"
              ? (x, y) => [x, y + (x - cx) * g]
              : (x, y) => {
                  const t = (y - b.y) / b.h,
                    u = a === "pt" ? t : 1 - t;
                  return [cx + (x - cx) * (k + (1 - k) * u), y];
                }
        );
      }
    })
);
