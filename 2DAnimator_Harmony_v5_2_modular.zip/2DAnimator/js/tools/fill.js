/**
 * Relleno: detección de formas cerradas y creación del relleno.
 */
"use strict";
function closedPoly(s) {
  const q = pts(s);
  if (q.length < 3) return null;
  if (["rect", "ellipse", "fill"].includes(s.kind) || (s.kind === "bezier" && s.closed)) return q;
  return (s.kind === "path" || s.kind === "bezier") &&
    Math.hypot(q[0].x - q.at(-1).x, q[0].y - q.at(-1).y) < Math.max(14, s.size * 2.5)
    ? q
    : null;
}
const inPoly = (p, q) => {
  let c = false;
  for (let i = 0, j = q.length - 1; i < q.length; j = i++)
    if (
      q[i].y > p.y !== q[j].y > p.y &&
      p.x < ((q[j].x - q[i].x) * (p.y - q[i].y)) / (q[j].y - q[i].y) + q[i].x
    )
      c = !c;
  return c;
};
const area = (q) =>
  Math.abs(
    q.reduce((a, p, i) => {
      const n = q[(i + 1) % q.length];
      return a + p.x * n.y - n.x * p.y;
    }, 0) / 2
  );
function fillAt(p) {
  let best = null,
    ba = 1e12;
  S.layers.forEach((l) => {
    if (!l.visible) return;
    F().strokes.forEach((s) => {
      if (owner(s) !== l) return;
      const q = closedPoly(s);
      if (q && inPoly(p, q)) {
        const a = area(q);
        if (a < ba) {
          ba = a;
          best = { s, q };
        }
      }
    });
  });
  if (!best) return hint("Haz clic dentro de una forma cerrada (cierra los contornos con la pluma Bézier).");
  pushUndo();
  if (best.s.kind === "fill" && owner(best.s) === L()) best.s.color = S.fillColor;
  else
    F().strokes.push({
      kind: "fill",
      color: S.fillColor,
      size: 1,
      opacity: S.opacity,
      layerId: L().id,
      points: best.q.map((q) => ({ x: q.x, y: q.y })),
    });
  dirty();
  all();
}
