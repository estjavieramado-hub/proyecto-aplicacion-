/**
 * Herramienta activa: nombres, atajos, textos de ayuda y setTool().
 */
"use strict";
const NAMES = {
  bone: "Hueso",
  pose: "Pose",
  xform: "Transformar capa",
  lasso: "Lazo",
  fill: "Relleno",
  select: "Selección",
  node: "Editar nodos",
  bezier: "Pluma Bézier",
  pencil: "Pincel",
  eraser: "Borrador",
  line: "Línea",
  rectangle: "Rectángulo",
  ellipse: "Elipse",
  hand: "Mano",
  scissors: "Tijeras",
  eyedropper: "Cuentagotas",
  zoom: "Zoom",
  polygon: "Polígono",
  star: "Estrella",
};
const KEYS = {
  j: "bone",
  m: "pose",
  t: "xform",
  s: "lasso",
  g: "fill",
  v: "select",
  a: "node",
  b: "bezier",
  p: "pencil",
  e: "eraser",
  l: "line",
  r: "rectangle",
  o: "ellipse",
  h: "hand",
  c: "scissors",
  i: "eyedropper",
  z: "zoom",
  n: "polygon",
  w: "star",
};
const TIPS = {
  bone: "Arrastra para crear un hueso. Si empiezas cerca del extremo de otro hueso, se conecta como hijo (articulación).",
  pose: "Arrastra un hueso para rotarlo (crea una clave de rotación en el fotograma actual). Respeta los límites del hueso.",
  xform:
    "Arrastra para mover la capa activa (crea una clave en el fotograma actual). Shift = rotar, Alt = escalar. El resto de valores, en el panel Transformación.",
  lasso:
    "Dibuja un lazo alrededor de los trazos para seleccionarlos (Shift suma). Luego muévelos, transfórmalos o suprímelos. También: arrastrar en vacío con Selección, Ctrl+A.",
  fill: "Clic dentro de una forma cerrada para rellenarla en la capa activa (usa la capa Color). Clic sobre un relleno propio: cambia su color.",
  pencil:
    "Pincel: con tableta la presión cambia el grosor; con ratón se simula con la velocidad. Elige tipo de pincel y suavidad a la derecha.",
  select:
    "Clic para seleccionar · arrastra para mover (Shift: eje, Alt: duplicar) · asas: escalar (Shift proporcional, Alt desde el centro) · fuera de una esquina: rotar · arrastrar en vacío: marquesina · flechas: empujar.",
  node: "Clic en un nodo: seleccionar (Shift suma) · arrastrar nodos, tiradores o un tramo (deforma la curva) · marquesina en vacío · Alt+arrastrar nodo: sacar tiradores (Alt en un tirador: independiente) · doble clic en un nodo: suave↔esquina, en un tramo: añadir nodo · Supr: quitar.",
  bezier:
    "Clic: esquina · arrastrar: curva · Shift: 45° · Alt: romper tirador · Espacio: mover punto · Ctrl: mover puntos · clic en el último punto: quita su tirador · Ctrl+Z: borra el último punto. Clic en el 1.er punto cierra · Enter termina · Esc cancela.",
  scissors: "Haz clic sobre una línea para cortarla en ese punto (los trozos quedan como trazos independientes).",
  eyedropper:
    "Clic en un trazo o color: toma color, grosor, opacidad y pincel. Con trazos seleccionados se los aplica (Alt: solo tomar · Shift: tomar como color de relleno).",
  zoom: "Clic: acercar · Alt o Shift+clic: alejar · arrastrar: encuadrar una zona. Ctrl+0 ajusta, Ctrl+1 al 100%.",
  polygon: "Arrastra desde el centro: el radio y el giro siguen al cursor (Shift: sin girar). Lados en «Relleno y formas».",
  star: "Arrastra desde el centro: radio y giro (Shift: sin girar). Puntas y radio interior en «Relleno y formas».",
  rectangle: "Arrastra para dibujar · Shift: cuadrado · Alt: desde el centro · esquinas redondeadas en «Relleno y formas».",
  ellipse: "Arrastra para dibujar · Shift: círculo · Alt: desde el centro.",
  line: "Arrastra para dibujar una línea · Shift: ángulos de 45°.",
  eraser: "Arrastra para borrar. Modo y tamaño en «Borrador e imán» (parte del trazo o trazo completo).",
};
const cur = () => {
  cv.style.cursor =
    S.tool === "hand"
      ? "grab"
      : S.tool === "bezier"
        ? Pen.cursor("new")
        : S.tool === "zoom"
          ? "zoom-in"
          : S.tool === "select" || S.tool === "node"
            ? "default"
            : "crosshair";
};
function setTool(t) {
  if (S.pen) Pen.end();
  S.tool = t;
  document.querySelectorAll(".tool").forEach((b) => b.classList.toggle("on", b.dataset.tool === t));
  $("toolName").textContent = NAMES[t];
  cur();
  if (t === "node" && S.sel && !["bezier", "fill"].includes(S.sel.kind)) {
    pushUndo();
    toBezier(S.sel);
    dirty();
  }
  if (
    !["select", "node", "lasso", "eyedropper", "zoom", "hand"].includes(t) &&
    !(t === "bezier" && S.sel && S.sel.kind === "bezier")
  )
    S.sel = null;
  S.nodeSel = -1;
  S.nodes = [];
  S.marquee = S.nd = S.xf = null;
  Snap.clear();
  render();
  hint(TIPS[t] || "Herramienta: " + NAMES[t] + ".");
}
document.querySelectorAll(".tool").forEach((b) => (b.onclick = () => setTool(b.dataset.tool)));
