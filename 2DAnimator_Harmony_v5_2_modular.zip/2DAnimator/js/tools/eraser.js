/**
 * Borrador con tamaño propio. Dos modos (panel «Borrador e imán»):
 *   Parte del trazo   corta los trazos bajo el círculo y deja los trozos restantes (como el borrador de Illustrator).
 *                     Los trazos vectoriales tocados pasan a trazo libre (pierden nodos); los rellenos no se tocan.
 *   Trazo completo    elimina el trazo entero (o el relleno) bajo el cursor.
 * Depende de: S, F, owner, pts, dseg, inPoly, pushUndo, dirty, all.
 */
"use strict";
let eLast = null;

function eraseBegin(p) {
  eLast = null;
  S.erased = false;
  erase(p);
}
function eraseEnd() {
  eLast = null;
}
/** Llamado en cada movimiento: interpola entre posiciones para no dejar huecos si el ratón va rápido. */
function erase(p) {
  const r = S.eSize / 2;
  const a = eLast || p;
  const n = Math.max(1, Math.ceil(Math.hypot(p.x - a.x, p.y - a.y) / (r / 2)));
  for (let k = 1; k <= n; k++) eraseAt({ x: a.x + ((p.x - a.x) * k) / n, y: a.y + ((p.y - a.y) * k) / n });
  eLast = p;
}
function touches(s, q, r) {
  const P = pts(s);
  const rr = r + s.size / 2;
  if (P.length === 1) return Math.hypot(P[0].x - q.x, P[0].y - q.y) < rr;
  for (let i = 1; i < P.length; i++) if (dseg(q, P[i - 1], P[i]) < rr) return true;
  return false;
}
/** Parte `s` quitando lo que cae dentro del círculo (q, r). No modifica `s`; devuelve los trozos. */
function cutOut(s, q, r) {
  const rr = r + s.size / 2;
  const P = pts(s);
  const lerp = (u, v, t) => (u === undefined ? undefined : u + (v - u) * t);
  const D = [];
  const step = Math.max(1, rr / 2);
  for (let i = 0; i < P.length - 1; i++) {
    const a = P[i];
    const b = P[i + 1];
    const n = Math.max(1, Math.ceil(Math.hypot(b.x - a.x, b.y - a.y) / step));
    for (let k = 0; k < n; k++) {
      const t = k / n;
      D.push({ x: lerp(a.x, b.x, t), y: lerp(a.y, b.y, t), w: lerp(a.w, b.w, t), tl: lerp(a.tl, b.tl, t) });
    }
  }
  const z = P.at(-1);
  D.push({ x: z.x, y: z.y, w: z.w, tl: z.tl });
  const out = D.map((a) => Math.hypot(a.x - q.x, a.y - q.y) >= rr);
  const runs = [];
  let cur = null;
  D.forEach((a, i) => {
    if (out[i]) (cur = cur || []).push(a);
    else if (cur) {
      runs.push(cur);
      cur = null;
    }
  });
  if (cur) runs.push(cur);
  const closed = s.closed || s.kind === "rect" || s.kind === "ellipse";
  if (closed && runs.length > 1 && out[0] && out.at(-1)) {
    const last = runs.pop();
    runs[0] = [...last, ...runs[0]]; // el tramo final enlaza con el inicial
  }
  return runs
    .filter((u) => u.length >= 2)
    .map((u) => ({
      kind: "path",
      closed: false,
      inb: s.inb,
      brush: s.kind === "path" ? s.brush : undefined,
      color: s.color,
      size: s.size,
      opacity: s.opacity,
      layerId: s.layerId,
      points: u,
    }));
}
function eraseAt(q) {
  const r = S.eSize / 2;
  const whole = S.eMode === "whole";
  const out = [];
  let changed = false;
  F().strokes.forEach((s) => {
    const o = owner(s);
    if (!o.visible || o.locked) return out.push(s);
    if (s.kind === "fill") {
      if (whole && inPoly(q, pts(s))) return void (changed = true);
      return out.push(s);
    }
    if (!touches(s, q, r)) return out.push(s);
    changed = true;
    if (!whole) out.push(...cutOut(s, q, r));
  });
  if (!changed) return;
  if (!S.erased) {
    pushUndo();
    S.erased = true;
  }
  if (S.sel && !out.includes(S.sel)) {
    S.sel = null;
    S.ms = [];
  }
  F().strokes = out;
  dirty();
  all();
}
