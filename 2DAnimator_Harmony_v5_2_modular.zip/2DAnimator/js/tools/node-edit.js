/**
 * Herramienta Nodos (selección directa) — comportamiento tipo Illustrator.
 *
 *   Clic en un nodo           lo selecciona · Shift+clic suma/quita · arrastrar mueve todos los seleccionados
 *   Marquesina (arrastrar en vacío)  selecciona los nodos que quedan dentro · clic en vacío deselecciona
 *   Arrastrar un tirador      lo mueve; en un nodo suave el opuesto se mantiene alineado (Alt: independiente)
 *   Arrastrar un tramo        deforma la curva (los tiradores de sus dos nodos siguen al ratón)
 *   Alt + arrastrar un nodo   saca tiradores simétricos (esquina → suave)
 *   Doble clic en un nodo     alterna suave ↔ esquina · doble clic en un tramo: añade un nodo
 *   Shift (al arrastrar)      limita a ejes / ángulos de 45° · Flechas: empujar nodos (Shift = 10 px)
 *   Supr                      quita los nodos seleccionados
 *
 * Acciones (panel «Nodos del trazo»): esquina, suave, quitar, cortar, cerrar/abrir, invertir, simplificar.
 * También aloja la herramienta Tijeras (Node.scissors) por compartir la lógica de cortar trazos.
 * El resto de eventos de puntero llegan desde pointer-input.js (down / move / up / dbl / cursor).
 * Depende de: S, F, owner, clone, pushUndo, dirty, all, render, hit, pts, bez, rdp, flat, toBezier, hint.
 */
"use strict";
const Node = (() => {
  const HIT = 9;
  const ACCENT = "#4a9dff";
  const rad = () => HIT / S.zoom;
  const bz = () => (S.sel && S.sel.kind === "bezier" ? S.sel : null);
  const hasH = (a, k) => !!(a[k + "x"] || a[k + "y"]);
  const usable = (s) => {
    const o = owner(s);
    return o.visible && !o.locked;
  };
  const wrap = (s, i) => {
    const n = s.points.length;
    return s.closed ? (i + n) % n : i < 0 || i >= n ? -1 : i;
  };
  let nudgeT = 0;

  /** Nodos seleccionados (siempre validados contra el trazo actual). */
  function nodes() {
    const s = bz();
    S.nodes = s ? S.nodes.filter((i) => i >= 0 && i < s.points.length) : [];
    return S.nodes;
  }
  function setNodes(a) {
    S.nodes = a;
    S.nodeSel = a.length ? a[a.length - 1] : -1;
  }
  function isSmooth(a) {
    const lo = Math.hypot(a.ox, a.oy);
    const li = Math.hypot(a.ix, a.iy);
    if (!lo || !li) return false;
    return Math.abs(a.ox * a.iy - a.oy * a.ix) / (lo * li) < 0.02 && a.ox * a.ix + a.oy * a.iy < 0;
  }
  function constrain45(o, p) {
    const dx = p.x - o.x;
    const dy = p.y - o.y;
    const d = Math.hypot(dx, dy);
    const a = Math.round(Math.atan2(dy, dx) / (Math.PI / 4)) * (Math.PI / 4);
    return { x: o.x + Math.cos(a) * d, y: o.y + Math.sin(a) * d };
  }
  const setCorner = (a) => {
    a.ox = a.oy = a.ix = a.iy = 0;
  };
  /** Convierte el nodo i en suave con tiradores calculados a partir de sus vecinos. */
  function setSmooth(s, i) {
    const a = s.points[i];
    const pi = wrap(s, i - 1);
    const ni = wrap(s, i + 1);
    const prev = s.points[pi >= 0 ? pi : i];
    const next = s.points[ni >= 0 ? ni : i];
    const tx = next.x - prev.x;
    const ty = next.y - prev.y;
    const L = Math.hypot(tx, ty) || 1;
    const lo = ni >= 0 ? Math.hypot(next.x - a.x, next.y - a.y) / 3 : 0;
    const li = pi >= 0 ? Math.hypot(a.x - prev.x, a.y - prev.y) / 3 : 0;
    a.ox = (tx / L) * lo;
    a.oy = (ty / L) * lo;
    a.ix = (-tx / L) * li;
    a.iy = (-ty / L) * li;
  }

  /* ---------- búsquedas ---------- */
  /** Los tiradores solo se muestran/capturan en los nodos seleccionados y sus vecinos (todos si no hay selección). */
  function visibleHandle(s, i) {
    const N = nodes();
    if (!N.length) return true;
    return N.some((j) => j === i || wrap(s, j - 1) === i || wrap(s, j + 1) === i);
  }
  function hitPart(s, p) {
    const r = rad();
    const P = s.points;
    for (let i = P.length - 1; i >= 0; i--) {
      if (!visibleHandle(s, i)) continue;
      for (const k of ["o", "i"]) {
        if (hasH(P[i], k) && Math.hypot(p.x - P[i].x - P[i][k + "x"], p.y - P[i].y - P[i][k + "y"]) < r)
          return { i, k };
      }
    }
    for (let i = P.length - 1; i >= 0; i--) if (Math.hypot(p.x - P[i].x, p.y - P[i].y) < r) return { i, k: "a" };
    return null;
  }
  /** Punto más cercano del trazo: {d, i (tramo), t}. `tol` limita la distancia. */
  function nearestSeg(s, p, tol = 8 / S.zoom + s.size / 2) {
    const P = s.points;
    const m = s.closed ? P.length : P.length - 1;
    let best = null;
    for (let i = 0; i < m; i++)
      for (let j = 1; j < 24; j++) {
        const q = bez(P[i], P[(i + 1) % P.length], j / 24);
        const d = Math.hypot(q.x - p.x, q.y - p.y);
        if (!best || d < best.d) best = { d, i, t: j / 24, q };
      }
    return best && best.d <= tol ? best : null;
  }
  /** Inserta un nodo en el tramo i, parámetro t (de Casteljau, no cambia la forma). Devuelve su índice. */
  function insertNode(s, i, t) {
    const P = s.points;
    const a = P[i];
    const b = P[(i + 1) % P.length];
    const p0 = { x: a.x, y: a.y };
    const p1 = { x: a.x + a.ox, y: a.y + a.oy };
    const p2 = { x: b.x + b.ix, y: b.y + b.iy };
    const p3 = { x: b.x, y: b.y };
    const Lp = (u, v) => ({ x: u.x + (v.x - u.x) * t, y: u.y + (v.y - u.y) * t });
    const q0 = Lp(p0, p1);
    const q1 = Lp(p1, p2);
    const q2 = Lp(p2, p3);
    const r0 = Lp(q0, q1);
    const r1 = Lp(q1, q2);
    const m = Lp(r0, r1);
    a.ox = q0.x - a.x;
    a.oy = q0.y - a.y;
    b.ix = q2.x - b.x;
    b.iy = q2.y - b.y;
    P.splice(i + 1, 0, {
      x: m.x,
      y: m.y,
      ix: r0.x - m.x,
      iy: r0.y - m.y,
      ox: r1.x - m.x,
      oy: r1.y - m.y,
    });
    return i + 1;
  }
  /** Selecciona un trazo (convirtiéndolo a vector si hace falta) y refleja sus propiedades en el panel. */
  function pick(o) {
    if (!["bezier", "fill"].includes(o.kind)) {
      pushUndo();
      toBezier(o);
      dirty();
    }
    S.sel = o;
    S.ms = [o];
    setNodes([]);
    $("strokeColor").value = o.color;
    $("strokeSize").value = o.size;
    $("opacity").value = o.opacity * 100;
    syncLabels();
  }

  /* ---------- eventos de puntero ---------- */
  function down(p, e) {
    const s = bz();
    if (s && usable(s)) {
      const h = hitPart(s, p);
      if (h) {
        const a = s.points[h.i];
        if (h.k === "a") {
          const has = S.nodes.includes(h.i);
          if (e.shiftKey) {
            if (has) {
              setNodes(S.nodes.filter((x) => x !== h.i));
              render();
              return;
            }
            setNodes([...S.nodes, h.i]);
          } else if (!has) setNodes([h.i]);
          S.nodeSel = h.i;
          pushUndo();
          if (e.altKey) S.nd = { mode: "pull", s, a, o: p, moved: false };
          else {
            const idx = [...S.nodes];
            S.nd = {
              mode: "move",
              s,
              idx,
              orig: idx.map((i) => ({ x: s.points[i].x, y: s.points[i].y })),
              prim: { x: a.x, y: a.y },
              p0: p,
              moved: false,
            };
          }
        } else {
          if (!S.nodes.includes(h.i)) setNodes([h.i]);
          pushUndo();
          S.nd = { mode: "handle", s, i: h.i, k: h.k, smooth: isSmooth(a), moved: false };
        }
        render();
        return;
      }
      const g = nearestSeg(s, p);
      if (g) {
        const n = s.points.length;
        const a = s.points[g.i];
        const b = s.points[(g.i + 1) % n];
        pushUndo();
        setNodes([g.i, (g.i + 1) % n]);
        S.nd = {
          mode: "segment",
          s,
          i: g.i,
          j: (g.i + 1) % n,
          t: Math.max(0.15, Math.min(0.85, g.t)),
          p0: p,
          o: { ox: a.ox, oy: a.oy, ix: a.ix, iy: a.iy, bix: b.ix, biy: b.iy, box: b.ox, boy: b.oy },
          smoothA: isSmooth(a),
          smoothB: isSmooth(b),
          moved: false,
        };
        render();
        return;
      }
    }
    const o = hit(p);
    if (o) {
      pick(o);
      render();
      tl();
      return;
    }
    S.marquee = { mode: "nodes", x0: p.x, y0: p.y, x1: p.x, y1: p.y, add: e.shiftKey };
    S.nd = { mode: "marquee" };
    render();
  }

  function move(p, e) {
    const d = S.nd;
    if (!d) return;
    if (d.mode === "marquee") {
      S.marquee.x1 = p.x;
      S.marquee.y1 = p.y;
      overlay();
      return;
    }
    const s = d.s;
    if (d.mode === "move") {
      let dx = p.x - d.p0.x;
      let dy = p.y - d.p0.y;
      if (!d.moved && Math.hypot(dx, dy) * S.zoom < 3) return;
      d.moved = true;
      if (e.shiftKey) {
        if (Math.abs(dx) > Math.abs(dy)) dy = 0;
        else dx = 0;
        Snap.clear();
      } else {
        const q = Snap.pt(
          { x: d.prim.x + dx, y: d.prim.y + dy },
          { skip: new Set(d.idx.map((i) => s.points[i])), skipS: new Set([s]) }
        );
        dx = q.x - d.prim.x;
        dy = q.y - d.prim.y;
      }
      d.idx.forEach((i, k) => {
        s.points[i].x = d.orig[k].x + dx;
        s.points[i].y = d.orig[k].y + dy;
      });
    } else if (d.mode === "pull") {
      if (!d.moved && Math.hypot(p.x - d.o.x, p.y - d.o.y) * S.zoom < 3) return;
      d.moved = true;
      const a = d.a;
      const h = e.shiftKey ? constrain45(a, p) : p;
      a.ox = h.x - a.x;
      a.oy = h.y - a.y;
      a.ix = -a.ox;
      a.iy = -a.oy;
    } else if (d.mode === "handle") {
      d.moved = true;
      const a = s.points[d.i];
      const h = e.shiftKey ? constrain45(a, p) : p;
      const dx = h.x - a.x;
      const dy = h.y - a.y;
      const other = d.k === "o" ? "i" : "o";
      a[d.k + "x"] = dx;
      a[d.k + "y"] = dy;
      if (d.smooth && !e.altKey) {
        const len = Math.hypot(a[other + "x"], a[other + "y"]);
        const m = Math.hypot(dx, dy) || 1;
        a[other + "x"] = (-dx / m) * len;
        a[other + "y"] = (-dy / m) * len;
      }
    } else if (d.mode === "segment") {
      const dx = p.x - d.p0.x;
      const dy = p.y - d.p0.y;
      if (!d.moved && Math.hypot(dx, dy) * S.zoom < 3) return;
      d.moved = true;
      const k = 1 / (3 * d.t * (1 - d.t));
      const a = s.points[d.i];
      const b = s.points[d.j];
      a.ox = d.o.ox + dx * k;
      a.oy = d.o.oy + dy * k;
      b.ix = d.o.bix + dx * k;
      b.iy = d.o.biy + dy * k;
      // nodos suaves: el tirador del otro lado gira para seguir alineado
      if (d.smoothA) {
        const len = Math.hypot(d.o.ix, d.o.iy);
        const m = Math.hypot(a.ox, a.oy) || 1;
        a.ix = (-a.ox / m) * len;
        a.iy = (-a.oy / m) * len;
      }
      if (d.smoothB) {
        const len = Math.hypot(d.o.box, d.o.boy);
        const m = Math.hypot(b.ix, b.iy) || 1;
        b.ox = (-b.ix / m) * len;
        b.oy = (-b.iy / m) * len;
      }
    }
    render();
  }

  function up() {
    const d = S.nd;
    if (!d) return;
    S.nd = null;
    Snap.clear();
    if (d.mode === "marquee") {
      const M = S.marquee;
      S.marquee = null;
      const big = Math.max(Math.abs(M.x1 - M.x0), Math.abs(M.y1 - M.y0)) * S.zoom > 4;
      const s = bz();
      const x0 = Math.min(M.x0, M.x1);
      const x1 = Math.max(M.x0, M.x1);
      const y0 = Math.min(M.y0, M.y1);
      const y1 = Math.max(M.y0, M.y1);
      const inRect = (a) => a.x >= x0 && a.x <= x1 && a.y >= y0 && a.y <= y1;
      if (!big) {
        if (!M.add) {
          S.sel = null;
          S.ms = [];
          setNodes([]);
        }
      } else if (s) {
        const inside = s.points.map((_, i) => i).filter((i) => inRect(s.points[i]));
        setNodes(M.add ? [...new Set([...S.nodes, ...inside])] : inside);
      } else {
        const f = F().strokes.find((t) => usable(t) && pts(t).some(inRect));
        if (f) pick(f);
      }
      render();
      tl();
      return;
    }
    if (d.moved) dirty();
    else S.undo.pop();
    render();
  }

  function dbl(p) {
    const s = bz();
    if (!s || !usable(s)) return;
    const h = hitPart(s, p);
    if (h && h.k === "a") {
      pushUndo();
      const a = s.points[h.i];
      if (hasH(a, "o") || hasH(a, "i")) setCorner(a);
      else setSmooth(s, h.i);
      setNodes([h.i]);
      dirty();
      render();
      return;
    }
    const g = nearestSeg(s, p, 14 / S.zoom);
    if (g) {
      pushUndo();
      setNodes([insertNode(s, g.i, g.t)]);
      dirty();
      render();
    }
  }

  /** Cursor según lo que haya bajo el puntero. */
  function cursor(p) {
    const s = bz();
    if (!s) return "default";
    if (hitPart(s, p)) return "move";
    return nearestSeg(s, p) ? "crosshair" : "default";
  }

  /* ---------- acciones sobre nodos (panel y atajos) ---------- */
  function ready() {
    const s = bz();
    if (!s || !usable(s)) {
      hint("Selecciona un trazo vectorial con la herramienta Nodos (A).");
      return null;
    }
    return s;
  }
  const targets = (s) => (nodes().length ? nodes() : s.points.map((_, i) => i));
  function corner() {
    const s = ready();
    if (!s) return;
    pushUndo();
    targets(s).forEach((i) => setCorner(s.points[i]));
    dirty();
    render();
  }
  function smoothNodes() {
    const s = ready();
    if (!s) return;
    pushUndo();
    targets(s).forEach((i) => setSmooth(s, i));
    dirty();
    render();
  }
  /** Quita los nodos seleccionados. Devuelve false si no había ninguno. */
  function remove() {
    const s = bz();
    const N = nodes();
    if (!s || !N.length || !usable(s)) return false;
    pushUndo();
    const keep = s.points.filter((_, i) => !N.includes(i));
    if (keep.length < 2) {
      F().strokes.splice(F().strokes.indexOf(s), 1);
      S.sel = null;
      S.ms = [];
    } else {
      s.points = keep;
      if (s.closed && keep.length < 3) s.closed = false;
    }
    setNodes([]);
    dirty();
    all();
    return true;
  }
  /** Empuja los nodos seleccionados. Devuelve false si no hay nodos seleccionados. */
  function nudge(dx, dy) {
    const s = bz();
    const N = nodes();
    if (!s || !N.length || !usable(s)) return false;
    if (Date.now() - nudgeT > 700) pushUndo();
    nudgeT = Date.now();
    N.forEach((i) => {
      s.points[i].x += dx;
      s.points[i].y += dy;
    });
    dirty();
    render();
    return true;
  }
  function toggleClosed() {
    const s = ready();
    if (!s) return;
    if (!s.closed && s.points.length < 3) return hint("Hacen falta al menos 3 nodos para cerrar el trazo.");
    pushUndo();
    s.closed = !s.closed;
    setNodes([]);
    dirty();
    all();
    hint(s.closed ? "Trazo cerrado." : "Trazo abierto.");
  }
  function reverse() {
    const s = ready();
    if (!s) return;
    pushUndo();
    s.points.reverse();
    s.points.forEach((a) => {
      [a.ix, a.ox] = [a.ox, a.ix];
      [a.iy, a.oy] = [a.oy, a.iy];
    });
    setNodes([]);
    dirty();
    all();
  }
  /** Reduce nodos: aplana la curva, simplifica (RDP) y recalcula tiradores suaves. */
  function simplify() {
    const s = ready();
    if (!s) return;
    const q = flat(s);
    if (q.length < 4) return;
    const R = rdp(q, 1.5);
    if (s.closed && R.length > 3) R.pop();
    if (R.length >= s.points.length) return hint("El trazo ya es lo bastante simple.");
    pushUndo();
    const n = R.length;
    s.points = R.map((p, i) => {
      const a = R[i - 1] || (s.closed ? R[n - 1] : p);
      const b = R[i + 1] || (s.closed ? R[0] : p);
      const ox = (b.x - a.x) / 6;
      const oy = (b.y - a.y) / 6;
      return { x: p.x, y: p.y, ox, oy, ix: -ox, iy: -oy };
    });
    setNodes([]);
    dirty();
    all();
    hint("Trazo simplificado a " + n + " nodos.");
  }

  /* ---------- cortar ---------- */
  /** Parte un trazo Bézier por los nodos `idxs`. Devuelve los trozos nuevos o null si no había nada que cortar. */
  function splitStroke(s, idxs) {
    const fs = F().strokes;
    const at = fs.indexOf(s);
    let P = s.points.map((a) => ({ ...a }));
    let cuts = [...new Set(idxs)].sort((a, b) => a - b);
    if (s.closed) {
      const k = cuts[0];
      P = [...P.slice(k), ...P.slice(0, k)];
      cuts = cuts.map((i) => (i - k + P.length) % P.length);
      P.push({ ...P[0] });
    }
    const inner = [...new Set(cuts)].filter((i) => i > 0 && i < P.length - 1).sort((a, b) => a - b);
    if (!s.closed && !inner.length) return null;
    const bounds = [0, ...inner, P.length - 1];
    const pieces = [];
    for (let k = 0; k < bounds.length - 1; k++) {
      const Q = P.slice(bounds[k], bounds[k + 1] + 1).map((a) => ({ ...a }));
      if (Q.length < 2) continue;
      Q[0].ix = Q[0].iy = 0;
      Q.at(-1).ox = Q.at(-1).oy = 0;
      pieces.push({ ...clone({ ...s, points: [] }), points: Q, closed: false });
    }
    if (!pieces.length) return null;
    fs.splice(at, 1, ...pieces);
    return pieces;
  }
  function cut() {
    const s = ready();
    if (!s) return;
    const N = nodes();
    if (!N.length) return hint("Selecciona el nodo donde cortar (o usa la herramienta Tijeras, C).");
    pushUndo();
    const pcs = splitStroke(s, N);
    if (!pcs) {
      S.undo.pop();
      return hint("Ahí no hay nada que cortar: es un extremo del trazo.");
    }
    S.sel = pcs[0];
    S.ms = pcs;
    setNodes([]);
    dirty();
    all();
    hint("Trazo cortado en " + pcs.length + " trozos.");
  }
  /** Corta un trazo de mano alzada (path) por el punto más cercano, conservando pincel y presión. */
  function cutPath(s, p) {
    const P = s.points;
    let best = null;
    for (let j = 0; j < P.length - 1; j++) {
      const a = P[j];
      const b = P[j + 1];
      const dx = b.x - a.x;
      const dy = b.y - a.y;
      const l = dx * dx + dy * dy;
      const t = l ? Math.max(0, Math.min(1, ((p.x - a.x) * dx + (p.y - a.y) * dy) / l)) : 0;
      const d = Math.hypot(a.x + dx * t - p.x, a.y + dy * t - p.y);
      if (!best || d < best.d) best = { d, j, t };
    }
    if (!best) return null;
    const a = P[best.j];
    const b = P[best.j + 1];
    const lerp = (u, v) => (u === undefined ? undefined : u + (v - u) * best.t);
    const m = { x: lerp(a.x, b.x), y: lerp(a.y, b.y), w: lerp(a.w, b.w), tl: lerp(a.tl, b.tl) };
    const A = [...P.slice(0, best.j + 1), m];
    const B = [m, ...P.slice(best.j + 1)];
    if (A.length < 2 || B.length < 2) return null;
    const mk = (pp) => ({ ...s, points: pp.map((q) => ({ ...q })) });
    const pieces = [mk(A), mk(B)];
    F().strokes.splice(F().strokes.indexOf(s), 1, ...pieces);
    return pieces;
  }
  /** Herramienta Tijeras: corta el trazo bajo el cursor en el punto donde se hace clic. */
  function scissors(p) {
    const s = hit(p);
    if (!s || s.kind === "fill") return hint("Tijeras: haz clic sobre una línea para cortarla.");
    pushUndo();
    let pieces = null;
    if (s.kind === "path") pieces = cutPath(s, p);
    else {
      if (s.kind !== "bezier") toBezier(s);
      const g = nearestSeg(s, p, Infinity);
      if (g) pieces = splitStroke(s, [insertNode(s, g.i, g.t)]);
    }
    if (!pieces) {
      S.undo.pop();
      return hint("No se pudo cortar ahí.");
    }
    S.sel = null;
    S.ms = [];
    setNodes([]);
    dirty();
    all();
    hint("Trazo cortado. Los trozos son trazos independientes.");
  }

  /* ---------- dibujo de nodos y tiradores ---------- */
  function drawOverlay(c) {
    const s = bz();
    if (!s || S.tool !== "node") return;
    const z = S.zoom;
    const r = 4.5 / z;
    const P = s.points;
    const N = nodes();
    c.save();
    // contorno fino del trazo (se ve el vector aunque el pincel sea grueso)
    c.strokeStyle = ACCENT + "aa";
    c.lineWidth = 1 / z;
    const m = s.closed ? P.length : P.length - 1;
    c.beginPath();
    for (let i = 0; i < m; i++) {
      const a = P[i];
      const b = P[(i + 1) % P.length];
      if (!i) c.moveTo(a.x, a.y);
      c.bezierCurveTo(a.x + a.ox, a.y + a.oy, b.x + b.ix, b.y + b.iy, b.x, b.y);
    }
    c.stroke();
    c.lineWidth = 1.2 / z;
    P.forEach((a, i) => {
      if (!visibleHandle(s, i)) return;
      for (const k of ["o", "i"]) {
        if (!hasH(a, k)) continue;
        const hx = a.x + a[k + "x"];
        const hy = a.y + a[k + "y"];
        c.strokeStyle = "#6b7785";
        c.beginPath();
        c.moveTo(a.x, a.y);
        c.lineTo(hx, hy);
        c.stroke();
        c.fillStyle = "#fff";
        c.strokeStyle = ACCENT;
        c.beginPath();
        c.arc(hx, hy, r * 0.8, 0, 7);
        c.fill();
        c.stroke();
      }
    });
    P.forEach((a, i) => {
      c.fillStyle = N.includes(i) ? ACCENT : "#fff";
      c.strokeStyle = ACCENT;
      c.beginPath();
      if (!i && !s.closed) c.rect(a.x - r * 1.15, a.y - r * 1.15, 2.3 * r, 2.3 * r);
      else c.rect(a.x - r, a.y - r, 2 * r, 2 * r);
      c.fill();
      c.stroke();
    });
    c.restore();
  }

  return {
    down,
    move,
    up,
    dbl,
    cursor,
    corner,
    smooth: smoothNodes,
    remove,
    nudge,
    toggleClosed,
    reverse,
    simplify,
    cut,
    scissors,
    drawOverlay,
    nodes,
    insertNode,
  };
})();
