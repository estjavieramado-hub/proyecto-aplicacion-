/**
 * Serialización del proyecto (proj), autoguardado diferido y deshacer/rehacer.
 */
"use strict";
const proj = () => ({
  format: "2DAnimatorProject",
  version: 4,
  app: "2DAnimator",
  savedAt: new Date().toISOString(),
  name: S.name,
  width: S.width,
  height: S.height,
  fps: S.fps,
  keyCol: S.keyCol,
  inbCol: S.inbCol,
  groups: S.groups,
  layers: S.layers,
  frames: S.frames,
  ref: S.ref ? { src: S.ref.src, op: S.ref.op } : undefined,
  curve: S.curve,
  rig: S.rig || undefined,
});
let asT = 0;
function autosave() {
  clearTimeout(asT);
  asT = 0;
  try {
    localStorage.setItem("2dAnimatorAutosave", JSON.stringify(proj()));
    S.asFail = false;
    $("saveStatus").textContent = "Borrador guardado " + new Date().toLocaleTimeString();
  } catch (err) {
    S.asFail = true;
    $("saveStatus").textContent =
      "⚠ Autoguardado falló (" +
      (err.name === "QuotaExceededError" ? "almacenamiento lleno" : err.message) +
      "): usa Archivo › Guardar";
  }
}
function dirty() {
  S.dirty = true;
  $("saveStatus").textContent = "Cambios sin guardar";
  clearTimeout(asT);
  asT = setTimeout(autosave, 900);
}
addEventListener("beforeunload", (e) => {
  if (asT) autosave();
  if (S.asFail && S.dirty) {
    e.preventDefault();
    e.returnValue = "";
  }
});
document.addEventListener("visibilitychange", () => {
  if (document.hidden && asT) autosave();
});
["pointerup", "change"].forEach((n) =>
  document.addEventListener(n, () => {
    S.propU = false;
  })
);
const snap = () => JSON.stringify({ frames: S.frames, layers: S.layers, groups: S.groups, rig: S.rig });
const UNDO_MAX = 60,
  UNDO_BYTES = 48e6;
function trimUndo() {
  let t = 0;
  for (const u of S.undo) t += u.length;
  while (S.undo.length > UNDO_MAX || (S.undo.length > 3 && t > UNDO_BYTES)) t -= S.undo.shift().length;
}
function pushUndo() {
  S.rng = null;
  S.undo.push(snap());
  S.redo = [];
  trimUndo();
}
function restore(j) {
  const d = JSON.parse(j);
  S.frames = d.frames;
  S.layers = d.layers;
  S.groups = d.groups || S.groups;
  S.rig = d.rig || null;
  S.rng = null;
  S.f = Math.min(S.f, S.frames.length - 1);
  S.l = Math.min(S.l, S.layers.length - 1);
  S.sel = null;
  S.ms = [];
  S.nodes = [];
  S.nodeSel = -1;
  dirty();
  all();
}
const undo = () => {
    if (S.undo.length) {
      S.redo.push(snap());
      restore(S.undo.pop());
    }
  },
  redo = () => {
    if (S.redo.length) {
      S.undo.push(snap());
      restore(S.redo.pop());
    }
  };
