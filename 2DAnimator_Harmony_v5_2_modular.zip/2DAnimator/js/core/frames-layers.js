/**
 * Operaciones sobre fotogramas y capas (añadir, duplicar, mover, grupos anime, recorte, máscara).
 */
"use strict";
const moveF = (d) => {
  const j = S.f + d;
  if (j < 0 || j >= S.frames.length) return;
  pushUndo();
  [S.frames[S.f], S.frames[j]] = [S.frames[j], S.frames[S.f]];
  S.f = j;
  dirty();
  all();
};
$("moveFL").onclick = () => moveF(-1);
$("moveFR").onclick = () => moveF(1);
function addF(copy) {
  pushUndo();
  S.frames.splice(S.f + 1, 0, { id: uid(), strokes: copy ? clone(F().strokes) : [] });
  S.f++;
  S.sel = null;
  dirty();
  all();
}
function delF() {
  if (S.frames.length === 1) return hint("Debe existir al menos un fotograma.");
  pushUndo();
  S.frames.splice(S.f, 1);
  S.f = Math.max(0, S.f - 1);
  S.sel = null;
  dirty();
  all();
}
function go(i) {
  if (S.playing) stop();
  S.f = Math.max(0, Math.min(S.frames.length - 1, i));
  S.sel = null;
  all();
}
document
  .querySelectorAll("[data-go]")
  .forEach(
    (b) =>
      (b.onclick = () =>
        go({ first: 0, prev: S.f - 1, next: S.f + 1, last: S.frames.length - 1 }[b.dataset.go]))
  );
const animeLayers = () => {
  const g = uid();
  S.groups = [{ id: g, name: "Personaje 1", open: true }];
  return [
    ["Color", "#f2c94c", 1],
    ["Sombra", "#4d5fa3", 0.55],
    ["Línea", "#24272d", 1],
  ].map(([n, c, o]) => ({ id: uid(), name: n, visible: true, locked: false, g, color: c, op: o }));
};
$("addLayerBtn").onclick = () => {
  pushUndo();
  S.layers.splice(S.l + 1, 0, {
    id: uid(),
    name: "Capa " + (S.layers.length + 1),
    visible: true,
    locked: false,
    g: L().g,
  });
  S.l++;
  dirty();
  all();
};
$("addAnimeBtn").onclick = () => {
  pushUndo();
  const g = uid();
  S.groups.push({ id: g, name: "Personaje " + (S.groups.length + 1), open: true });
  [
    ["Color", "#f2c94c", 1],
    ["Sombra", "#4d5fa3", 0.55],
    ["Línea", "#24272d", 1],
  ].forEach(([n, c, o]) =>
    S.layers.push({ id: uid(), name: n, visible: true, locked: false, g, color: c, op: o })
  );
  S.l = -1;
  selLayer(S.layers.length - 1);
  dirty();
  all();
};
$("deleteLayerBtn").onclick = () => {
  if (S.layers.length < 2) return hint("Debe existir al menos una capa.");
  pushUndo();
  const lay = L();
  S.frames.forEach((f) => (f.strokes = f.strokes.filter((s) => owner(s) !== lay)));
  S.layers.splice(S.l, 1);
  S.groups = S.groups.filter((g) => S.layers.some((l) => l.g === g.id));
  S.l = Math.max(0, S.l - 1);
  S.sel = null;
  dirty();
  all();
};
const moveLayer = (d) => {
  const j = S.l + d;
  if (j < 0 || j >= S.layers.length) return;
  if (S.layers[j].g !== S.layers[S.l].g) return hint("Las capas solo se reordenan dentro de su grupo.");
  pushUndo();
  [S.layers[S.l], S.layers[j]] = [S.layers[j], S.layers[S.l]];
  S.l = j;
  dirty();
  all();
};
const setMode = (m) => {
  if (S.l === 0) return hint("Necesitas una capa inferior que sirva de base.");
  pushUndo();
  const l = L();
  l.mode = l.mode === m ? undefined : m;
  dirty();
  all();
  hint(
    l.mode === "clip"
      ? "Recorte: esta capa solo se ve dentro de lo dibujado en la capa inferior."
      : l.mode === "mask"
        ? "Máscara: lo que dibujes aquí (naranja) define la zona visible de la capa inferior. Sin trazos no oculta nada."
        : "Capa normal."
  );
};
$("clipBtn").onclick = () => setMode("clip");
$("maskBtn").onclick = () => setMode("mask");
$("layerUpBtn").onclick = () => moveLayer(1);
$("layerDownBtn").onclick = () => moveLayer(-1);
