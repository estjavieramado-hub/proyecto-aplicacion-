/**
 * Geometría vectorial: puntos de un trazo, Bézier, aplanado, RDP, remuestreo, hit-test y conversión a Bézier.
 */
"use strict";
/* ---------- geometría ---------- */
const pts = (s) => {
  if (s.kind === "bezier") return flat(s);
  const a = s.points[0],
    b = s.points.at(-1);
  if (s.kind === "rect") return [a, { x: b.x, y: a.y }, b, { x: a.x, y: b.y }, a];
  if (s.kind === "ellipse")
    return Array.from({ length: 49 }, (_, i) => {
      const t = (i / 48) * Math.PI * 2;
      return {
        x: (a.x + b.x) / 2 + (Math.cos(t) * (b.x - a.x)) / 2,
        y: (a.y + b.y) / 2 + (Math.sin(t) * (b.y - a.y)) / 2,
      };
    });
  if (s.kind === "line") return [a, b];
  return s.points;
};
const bez = (a, b, t) => {
  const u = 1 - t;
  return {
    x: u * u * u * a.x + 3 * u * u * t * (a.x + a.ox) + 3 * u * t * t * (b.x + b.ix) + t * t * t * b.x,
    y: u * u * u * a.y + 3 * u * u * t * (a.y + a.oy) + 3 * u * t * t * (b.y + b.iy) + t * t * t * b.y,
  };
};
function flat(s) {
  const P = s.points;
  if (P.length < 2) return P.slice();
  const o = [],
    m = s.closed ? P.length : P.length - 1;
  for (let i = 0; i < m; i++)
    for (let j = i ? 1 : 0; j <= 16; j++) o.push(bez(P[i], P[(i + 1) % P.length], j / 16));
  return o;
}
const rdp = (p, e) => {
  if (p.length < 3) return p;
  let m = 0,
    k = 0;
  const a = p[0],
    b = p.at(-1);
  for (let i = 1; i < p.length - 1; i++) {
    const d = dseg(p[i], a, b);
    if (d > m) {
      m = d;
      k = i;
    }
  }
  return m > e ? [...rdp(p.slice(0, k + 1), e).slice(0, -1), ...rdp(p.slice(k), e)] : [a, b];
};
function toBezier(s) {
  if (s.kind === "bezier" || s.kind === "fill") return;
  const n = (x, y, ox = 0, oy = 0) => ({ x, y, ox, oy, ix: -ox, iy: -oy });
  let P;
  if (s.kind === "ellipse") {
    const a = s.points[0],
      b = s.points.at(-1),
      cx = (a.x + b.x) / 2,
      cy = (a.y + b.y) / 2,
      rx = (b.x - a.x) / 2,
      ry = (b.y - a.y) / 2,
      k = 0.5523;
    P = [
      n(cx, cy - ry, k * rx, 0),
      n(cx + rx, cy, 0, k * ry),
      n(cx, cy + ry, -k * rx, 0),
      n(cx - rx, cy, 0, -k * ry),
    ];
    s.closed = true;
  } else if (s.kind === "rect") {
    P = pts(s)
      .slice(0, 4)
      .map((p) => n(p.x, p.y));
    s.closed = true;
  } else if (s.kind === "line") P = [s.points[0], s.points.at(-1)].map((p) => n(p.x, p.y));
  else {
    const r = rdp(s.points, 2.5);
    P = r.map((p, i) => {
      const a = r[i - 1] || p,
        b = r[i + 1] || p;
      return n(p.x, p.y, (b.x - a.x) / 6, (b.y - a.y) / 6);
    });
  }
  s.kind = "bezier";
  s.points = P;
}
function addNode(s, p) {
  let best = [1e9, 0, 0];
  const P = s.points,
    m = s.closed ? P.length : P.length - 1;
  for (let i = 0; i < m; i++)
    for (let j = 1; j < 16; j++) {
      const q = bez(P[i], P[(i + 1) % P.length], j / 16),
        d = Math.hypot(q.x - p.x, q.y - p.y);
      if (d < best[0]) best = [d, i, j / 16];
    }
  if (best[0] > 14 / S.zoom) return false;
  const [, i, t] = best,
    a = P[i],
    b = P[(i + 1) % P.length],
    p0 = { x: a.x, y: a.y },
    p1 = { x: a.x + a.ox, y: a.y + a.oy },
    p2 = { x: b.x + b.ix, y: b.y + b.iy },
    p3 = { x: b.x, y: b.y },
    Lp = (u, v) => ({ x: u.x + (v.x - u.x) * t, y: u.y + (v.y - u.y) * t }),
    q0 = Lp(p0, p1),
    q1 = Lp(p1, p2),
    q2 = Lp(p2, p3),
    r0 = Lp(q0, q1),
    r1 = Lp(q1, q2),
    m1 = Lp(r0, r1);
  a.ox = q0.x - a.x;
  a.oy = q0.y - a.y;
  b.ix = q2.x - b.x;
  b.iy = q2.y - b.y;
  P.splice(i + 1, 0, {
    x: m1.x,
    y: m1.y,
    ix: r0.x - m1.x,
    iy: r0.y - m1.y,
    ox: r1.x - m1.x,
    oy: r1.y - m1.y,
  });
  return true;
}
function bezSvg(s, el) {
  if (s.kind !== "bezier" || s.points.length < 2) return false;
  const P = s.points,
    m = s.closed ? P.length : P.length - 1,
    f = (v) => v.toFixed(1);
  let d = `M${f(P[0].x)} ${f(P[0].y)}`;
  for (let i = 0; i < m; i++) {
    const a = P[i],
      b = P[(i + 1) % P.length];
    d += `C${f(a.x + a.ox)} ${f(a.y + a.oy)} ${f(b.x + b.ix)} ${f(b.y + b.iy)} ${f(b.x)} ${f(b.y)}`;
  }
  el.push(
    `<path d="${d}${s.closed ? "Z" : ""}" fill="none" stroke="${s.color}" stroke-width="${s.size}" stroke-linecap="round" stroke-linejoin="round" opacity="${s.opacity}"/>`
  );
  return true;
}
const smooth = (p) =>
  p.length < 3
    ? p
    : p.map((q, i) =>
        i === 0 || i === p.length - 1
          ? q
          : {
              ...q,
              x: (p[i - 1].x + 2 * q.x + p[i + 1].x) / 4,
              y: (p[i - 1].y + 2 * q.y + p[i + 1].y) / 4,
              w: q.w === undefined ? undefined : (p[i - 1].w + 2 * q.w + p[i + 1].w) / 4,
            }
      );
function resample(p, n) {
  if (!p.length) return [];
  const len = [0];
  for (let i = 1; i < p.length; i++)
    len.push(len[i - 1] + Math.hypot(p[i].x - p[i - 1].x, p[i].y - p[i - 1].y));
  const T = len.at(-1);
  if (!T) return Array.from({ length: n }, () => ({ ...p[0] }));
  return Array.from({ length: n }, (_, k) => {
    const t = (T * k) / (n - 1);
    let i = 1;
    while (i < len.length - 1 && len[i] < t) i++;
    const d = len[i] - len[i - 1],
      u = d ? (t - len[i - 1]) / d : 0;
    return {
      w: p[i].w === undefined ? undefined : p[i - 1].w + (p[i].w - p[i - 1].w) * u,
      x: p[i - 1].x + (p[i].x - p[i - 1].x) * u,
      y: p[i - 1].y + (p[i].y - p[i - 1].y) * u,
    };
  });
}
const dseg = (p, a, b) => {
  const dx = b.x - a.x,
    dy = b.y - a.y,
    l = dx * dx + dy * dy;
  let t = l ? ((p.x - a.x) * dx + (p.y - a.y) * dy) / l : 0;
  t = Math.max(0, Math.min(1, t));
  return Math.hypot(p.x - a.x - t * dx, p.y - a.y - t * dy);
};
function hit(p) {
  const fs = F().strokes;
  for (let i = fs.length - 1; i >= 0; i--) {
    const s = fs[i],
      o = owner(s);
    if (!o.visible || o.locked) continue;
    const q = pts(s),
      tol = s.size / 2 + 8 / S.zoom;
    if (s.kind === "fill" && q.length > 2 && inPoly(p, q)) return s; // clic dentro de un relleno
    if (
      q.length === 1
        ? Math.hypot(p.x - q[0].x, p.y - q[0].y) < tol
        : q.slice(1).some((b, j) => dseg(p, q[j], b) < tol)
    )
      return s;
  }
  return null;
}
