/**
 * Acciones de edición: borrar selección, suavizar y limpiar capa.
 */
"use strict";
function delSel() {
  if (!S.sel) return hint("No hay selección.");
  if (S.tool === "node" && Node.remove()) return; // quita los nodos seleccionados
  pushUndo();
  {
    const m = msel();
    F().strokes = F().strokes.filter((s) => !m.includes(s));
  }
  S.sel = null;
  S.ms = [];
  dirty();
  all();
}
function smoothAct() {
  const t = S.sel
    ? [S.sel]
    : F().strokes.filter((s) => {
        const o = owner(s);
        return s.kind === "path" && o.visible && !o.locked;
      });
  if (!t.length) return hint("No hay trazos para suavizar.");
  pushUndo();
  t.forEach((s) => {
    if (s.kind === "path") for (let i = 0; i < 2; i++) s.points = smooth(s.points);
  });
  dirty();
  render();
}
function clearLayer() {
  const lay = L();
  if (lay.locked) return hint("La capa está bloqueada.");
  pushUndo();
  F().strokes = F().strokes.filter((s) => owner(s) !== lay);
  S.sel = null;
  dirty();
  all();
}
