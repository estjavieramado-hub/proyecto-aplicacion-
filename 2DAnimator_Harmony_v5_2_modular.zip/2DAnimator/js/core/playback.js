/**
 * Reproducción de la animación (tiempos, exposición, bucle, FPS).
 */
"use strict";
const expOf = (i) => S.frames[i]?.exp || 1,
  ticksTotal = () => S.frames.reduce((a, f) => a + (f.exp || 1), 0),
  tickEnd = (i) => {
    let t = 0;
    for (let k = 0; k <= i && k < S.frames.length; k++) t += expOf(k);
    return t;
  };
const frameAtTick = (t) => {
  let a = 0;
  for (let i = 0; i < S.frames.length; i++) {
    a += expOf(i);
    if (t < a) return i;
  }
  return S.frames.length - 1;
};
function mark() {
  const b = $("tlBody");
  b.querySelectorAll(".c.cur,.c.on").forEach((c) => c.classList.remove("cur", "on"));
  b.querySelectorAll(`.c[data-f="${S.f}"]`).forEach((c) => c.classList.add("cur"));
  const n = S.frames.length;
  $("frameCounter").textContent =
    `Fotograma ${S.f + 1}/${n} · ${(tickEnd(S.f) / S.fps).toFixed(2)} s de ${(ticksTotal() / S.fps).toFixed(2)} s`;
  const c = b.querySelector(".hd .c.cur");
  if (c) {
    const r = c.getBoundingClientRect(),
      br = b.getBoundingClientRect();
    if (r.left < br.left + 200) b.scrollLeft -= br.left + 210 - r.left;
    else if (r.right > br.right) b.scrollLeft += r.right - br.right + 20;
  }
}
function play() {
  if (S.playing) return stop();
  if (S.frames.length < 2) return hint("Crea al menos dos fotogramas.");
  S.playing = true;
  S.sel = null;
  $("playBtn").innerHTML = ic("pause");
  const t0 = performance.now(),
    f0 = S.f,
    T0 = tickEnd(f0) - expOf(f0),
    tt = ticksTotal(),
    step = (now) => {
      if (!S.playing) return;
      const k = Math.floor(((now - t0) * S.fps) / 1000) + T0;
      if (!$("loop").checked && k >= tt) {
        S.f = S.frames.length - 1;
        return stop();
      }
      const j = frameAtTick(k % tt);
      if (j !== S.f) {
        S.f = j;
        render();
        mark();
      }
      S.raf = requestAnimationFrame(step);
    };
  S.raf = requestAnimationFrame(step);
}
function stop() {
  S.playing = false;
  cancelAnimationFrame(S.raf);
  $("playBtn").innerHTML = ic("play");
  all();
}
$("playBtn").onclick = play;
$("fpsInput").onchange = (e) => {
  S.fps = Math.max(1, Math.min(60, +e.target.value || 24));
  e.target.value = S.fps;
  if (S.playing) {
    stop();
    play();
  }
  dirty();
};
