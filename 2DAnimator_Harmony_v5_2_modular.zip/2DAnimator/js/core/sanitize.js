/**
 * Constantes y limpieza de trazos al abrir/importar (validación de tipos y rangos).
 */
"use strict";
const HEX = /^#[0-9a-f]{3,8}$/i,
  KINDS = ["path", "line", "rect", "ellipse", "bezier", "fill"],
  num = (v, d, a, b) => {
    v = +v;
    return Number.isFinite(v) ? Math.max(a, Math.min(b, v)) : d;
  };
const clean = (a, ids = S.layers.map((l) => l.id), fb = L().id) =>
  (Array.isArray(a) ? a : [])
    .filter((s) => s && KINDS.includes(s.kind) && Array.isArray(s.points))
    .map((s) => ({
      kind: s.kind,
      closed: !!s.closed,
      inb: !!s.inb,
      mt: s.mt === undefined ? undefined : Math.round(num(s.mt, 1, 1, 99)),
      brush: BR[s.brush] ? s.brush : undefined,
      color: HEX.test(s.color) ? s.color : "#24272d",
      size: num(s.size, 4, 0.5, 500),
      opacity: num(s.opacity, 1, 0.01, 1),
      layerId: ids.includes(s.layerId) ? s.layerId : fb,
      points: s.points
        .filter((p) => p && typeof p === "object")
        .map((p) =>
          s.kind === "bezier"
            ? {
                x: num(p.x, 0, -1e5, 1e5),
                y: num(p.y, 0, -1e5, 1e5),
                ix: num(p.ix, 0, -1e5, 1e5),
                iy: num(p.iy, 0, -1e5, 1e5),
                ox: num(p.ox, 0, -1e5, 1e5),
                oy: num(p.oy, 0, -1e5, 1e5),
              }
            : {
                x: num(p.x, 0, -1e5, 1e5),
                y: num(p.y, 0, -1e5, 1e5),
                w: p.w === undefined ? undefined : num(p.w, 1, 0, 1),
                tl: p.tl === undefined ? undefined : num(p.tl, 0, 0, 1),
              }
        ),
    }))
    .filter((s) => s.points.length);
