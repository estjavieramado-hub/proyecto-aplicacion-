/**
 * Estado global `S`, referencias al DOM y utilidades básicas ($, uid, clone, esc, F, L, owner...).
 */
"use strict";
const $ = (id) => document.getElementById(id);
const cv = $("artCanvas"),
  ctx = cv.getContext("2d"),
  ov = $("overlayCanvas"),
  octx = ov.getContext("2d");
const uid = () => Math.random().toString(36).slice(2, 10),
  clone = (v) => JSON.parse(JSON.stringify(v));
const esc = (s) =>
  String(s).replace(
    /[&<>"']/g,
    (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]
  );
const G0 = uid(),
  LAY = (n, c, o) => ({ id: uid(), name: n, visible: true, locked: false, g: G0, color: c, op: o });
const S = {
  name: "Sin título",
  width: 1280,
  height: 720,
  fps: 24,
  tool: "select",
  color: "#24272d",
  size: 4,
  opacity: 1,
  stab: 0,
  onion: false,
  nb: 2,
  na: 2,
  cw: 22,
  skip: 0,
  skipF: -1,
  pen: null,
  penDrag: false,
  hover: null,
  nd: null,
  nodeSel: -1,
  scrub: false,
  rng: null,
  cd: null,
  cdMoved: false,
  keyCol: "#f5a623",
  inbCol: "#4fc3a1",
  brush: "tinta",
  press: true,
  lz: null,
  pr: 0.6,
  f: 0,
  l: 2,
  zoom: 1,
  px: 0,
  py: 0,
  playing: false,
  timer: null,
  cur: null,
  start: null,
  rev: false,
  sel: null,
  drag: null,
  pan: null,
  space: false,
  erasing: false,
  erased: false,
  undo: [],
  redo: [],
  layers: [LAY("Color", "#f2c94c", 1), LAY("Sombra", "#4d5fa3", 0.55), LAY("Línea", "#24272d", 1)],
  groups: [{ id: G0, name: "Personaje 1", open: true }],
  frames: [{ id: uid(), strokes: [] }],
};
S.ms = [];
S.lasso = null;
S.ref = null;
S.tiltOn = true;
S.curve = [0.42, 0, 0.58, 1];
S.final = false;
S.path = true;
const msel = () => (S.sel && S.ms.includes(S.sel) ? S.ms : S.sel ? [S.sel] : []);
const F = () => S.frames[S.f],
  L = () => S.layers[S.l],
  hint = (t) => {
    $("hintBox").textContent = t;
  };
const owner = (s) => S.layers.find((l) => l.id === s.layerId) || S.layers[0];
/* ---- v5.1: estado de las herramientas nuevas ---- */
S.nodes = []; // índices de nodos seleccionados en el trazo Bézier seleccionado
S.snap = false; // imán (cuadrícula visible + puntos de otros trazos + guías)
S.snapInfo = null; // último acierto del imán (para dibujar la guía)
S.clip = []; // portapapeles interno (Copiar / Cortar / Pegar)
S.fillColor = "#f2c94c"; // color de relleno (herramienta Relleno y «Rellenar al dibujar»)
S.fillOn = false; // crear relleno al terminar una forma cerrada
S.mouse = null; // última posición del puntero sobre el lienzo
S.marquee = null; // rectángulo de selección / zoom en curso
S.xf = null; // arrastre de asas de la selección (escalar / rotar)
S.nd = null; // arrastre de la herramienta de nodos
S.sides = 5; // lados del polígono / puntas de la estrella
S.starRatio = 50; // radio interior de la estrella (%)
S.corner = 0; // radio de esquina del rectángulo
S.eMode = "part"; // borrador: part (parte del trazo) | whole (trazo completo)
S.eSize = 18; // diámetro del borrador
