/**
 * Dibujo de trazos por capas (recorte/máscara) y render() del lienzo principal.
 */
"use strict";
let tmpC = null,
  mskC = null;
function drawStrokes(c, st, tint, alpha = 1) {
  const LY = S.layers,
    of = (l) => st.filter((s) => owner(s) === l),
    fi0 = S.frames.findIndex((f) => f.strokes === st),
    fi = fi0 < 0 ? S.f : fi0,
    fin = c !== ctx || S.playing || S.final || S.tool === "xform" || S.tool === "pose";
  const put = (g, l, list, tn, al) => {
    if (!list.length) return;
    if (fin && hasXf(l)) {
      g.save();
      rigApply(g, l, fi);
      const o = hasTr(l) ? trApply(g, l, fi) : 1;
      list.forEach((s) => drawStroke(g, s, tn, al * o));
      g.restore();
    } else list.forEach((s) => drawStroke(g, s, tn, al));
  };
  if (!LY.some((l) => l.mode)) {
    LY.forEach((l) => {
      if (l.visible) put(c, l, of(l), tint, alpha);
    });
    return;
  }
  const W = c.canvas.width,
    H = c.canvas.height;
  tmpC = tmpC || document.createElement("canvas");
  mskC = mskC || document.createElement("canvas");
  [tmpC, mskC].forEach((k) => {
    if (k.width !== W || k.height !== H) {
      k.width = W;
      k.height = H;
    }
  });
  const T = tmpC.getContext("2d"),
    M = mskC.getContext("2d");
  for (let i = 0; i < LY.length; i++) {
    const l = LY[i];
    if (l.mode || !l.visible) continue;
    const ext = [];
    for (let j = i + 1; j < LY.length && LY[j].mode; j++) ext.push(LY[j]);
    if (!ext.length) {
      put(c, l, of(l), tint, alpha);
      continue;
    }
    T.globalCompositeOperation = "source-over";
    T.clearRect(0, 0, W, H);
    put(T, l, of(l), tint, alpha);
    ext.forEach((e) => {
      const es = of(e);
      if (!e.visible || !es.length) return;
      if (e.mode === "clip") {
        T.globalCompositeOperation = "source-atop";
        put(T, e, es, tint, alpha);
      } else {
        M.clearRect(0, 0, W, H);
        put(M, e, es, "#000", 1);
        T.globalCompositeOperation = "destination-in";
        T.drawImage(mskC, 0, 0);
      }
    });
    T.globalCompositeOperation = "source-over";
    c.drawImage(tmpC, 0, 0);
  }
}
function render() {
  ctx.fillStyle = "#fff";
  ctx.fillRect(0, 0, cv.width, cv.height);
  if (S.ref) {
    const im = S.ref.img,
      k = Math.min(S.width / im.width, S.height / im.height);
    ctx.save();
    ctx.globalAlpha = S.ref.op;
    ctx.drawImage(
      im,
      (S.width - im.width * k) / 2,
      (S.height - im.height * k) / 2,
      im.width * k,
      im.height * k
    );
    ctx.restore();
  }
  if ($("showGrid").checked) {
    ctx.save();
    ctx.strokeStyle = "#e6e6e6";
    ctx.lineWidth = 1;
    ctx.beginPath();
    for (let x = 0; x <= cv.width; x += 40) {
      ctx.moveTo(x, 0);
      ctx.lineTo(x, cv.height);
    }
    for (let y = 0; y <= cv.height; y += 40) {
      ctx.moveTo(0, y);
      ctx.lineTo(cv.width, y);
    }
    ctx.stroke();
    ctx.restore();
  }
  if (S.onion && !S.playing)
    for (let k = Math.max(S.nb, S.na); k >= 1; k--) {
      const a = 0.42 / k,
        p = S.frames[S.f - k],
        n = S.frames[S.f + k];
      if (p && k <= S.nb) drawStrokes(ctx, p.strokes, "#e0556b", a);
      if (n && k <= S.na) drawStrokes(ctx, n.strokes, "#3d9be9", a);
    }
  drawStrokes(ctx, F().strokes);
  if (S.cur) {
    drawStroke(ctx, S.cur);
    mirrors(S.cur).forEach((m) => drawStroke(ctx, m));
  }
  Pen.drawPreview(ctx);
  overlay();
}
