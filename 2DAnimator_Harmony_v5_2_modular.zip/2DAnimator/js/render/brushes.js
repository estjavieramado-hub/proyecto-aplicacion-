/**
 * Pinceles vectoriales (cinta con presión), grano y dibujo de un trazo (drawStroke).
 */
"use strict";
/* ---------- dibujo ---------- */
const BR = {
  tinta: { n: "Tinta", ps: 0.7, tp: 0.7 },
  lapiz: { n: "Lápiz", ps: 0.35, tp: 0.25, al: 0.9, tilt: 0.7 },
  pincel: { n: "Pincel", ps: 1, tp: 0.95 },
  marcador: { n: "Marcador", ps: 0, tp: 0, al: 0.55 },
  caligrafia: { n: "Caligráfico", nib: 1 },
  tecnico: { n: "Técnico", ps: 0, tp: 0 },
  acuarela: { n: "Acuarela", ps: 0.5, tp: 0.9, al: 0.4, soft: 1 },
  grafito: { n: "Grafito", ps: 0.6, tp: 0.6, al: 0.9, grain: 0.5, tilt: 1.1 },
  carboncillo: { n: "Carboncillo", ps: 0.8, tp: 0.4, al: 0.95, grain: 0.3, tilt: 1.6 },
};
function ribbon(p, s) {
  const B = BR[s.brush],
    n = p.length,
    Ls = [0];
  for (let i = 1; i < n; i++) Ls.push(Ls[i - 1] + Math.hypot(p[i].x - p[i - 1].x, p[i].y - p[i - 1].y));
  const T = Ls[n - 1],
    tl = Math.min(T / 2, s.size * 3.5) || 1,
    Lf = [],
    Rt = [],
    W = [];
  for (let i = 0; i < n; i++) {
    const a = p[Math.max(0, i - 1)],
      b = p[Math.min(n - 1, i + 1)],
      tx = b.x - a.x,
      ty = b.y - a.y,
      ln = Math.hypot(tx, ty) || 1;
    let w;
    if (B.nib) w = s.size * (0.15 + 0.85 * Math.abs(Math.sin(Math.atan2(ty, tx) - 0.8)));
    else {
      w = s.size * (1 - B.ps + B.ps * (p[i].w ?? 1)) * (1 + (B.tilt || 0) * (p[i].tl || 0));
      const f = Math.min(1, Ls[i] / tl, (T - Ls[i]) / tl);
      w *= 1 - B.tp * (1 - Math.sqrt(Math.max(0, f)));
    }
    w = Math.max(w, 0.5);
    W.push(w);
    Lf.push({ x: p[i].x - ((ty / ln) * w) / 2, y: p[i].y + ((tx / ln) * w) / 2 });
    Rt.push({ x: p[i].x + ((ty / ln) * w) / 2, y: p[i].y - ((tx / ln) * w) / 2 });
  }
  return {
    poly: [...Lf, ...Rt.reverse()],
    caps: [
      [p[0].x, p[0].y, W[0] / 2],
      [p[n - 1].x, p[n - 1].y, W[n - 1] / 2],
    ],
  };
}
const isRib = (s, p) => s.kind === "path" && p.length > 1 && BR[s.brush] && s.brush !== "tecnico";
const grainC = {};
function grainFill(c, col, d) {
  const k = col + d;
  if (!grainC[k]) {
    const t = document.createElement("canvas");
    t.width = t.height = 48;
    const x = t.getContext("2d");
    let r = 7;
    const rnd = () => (r = (r * 16807) % 2147483647) / 2147483647;
    for (let i = 0; i < 48; i++)
      for (let j = 0; j < 48; j++) {
        x.fillStyle = `rgba(0,0,0,${rnd() < d ? 0.55 + rnd() * 0.45 : 0.04 + rnd() * 0.12})`;
        x.fillRect(i, j, 1, 1);
      }
    x.globalCompositeOperation = "source-in";
    x.fillStyle = col;
    x.fillRect(0, 0, 48, 48);
    grainC[k] = t;
  }
  return c.createPattern(grainC[k], "repeat") || col;
}
function drawStroke(c, s, tint, alpha = 1) {
  const p = pts(s);
  if (!p.length) return;
  c.save();
  c.globalAlpha = alpha * s.opacity * (BR[s.brush]?.al ?? 1);
  c.strokeStyle = c.fillStyle = tint || s.color;
  if (s.kind === "fill") {
    if (p.length > 2) {
      c.beginPath();
      c.moveTo(p[0].x, p[0].y);
      p.slice(1).forEach((q) => c.lineTo(q.x, q.y));
      c.closePath();
      c.fill();
    }
  } else if (isRib(s, p)) {
    const r = ribbon(p, s);
    if (BR[s.brush].soft) {
      c.shadowColor = c.fillStyle;
      c.shadowBlur = s.size * 0.9;
    }
    if (BR[s.brush].grain) c.fillStyle = grainFill(c, tint || s.color, BR[s.brush].grain);
    c.beginPath();
    r.poly.forEach((q, i) => (i ? c.lineTo(q.x, q.y) : c.moveTo(q.x, q.y)));
    c.closePath();
    c.fill();
    r.caps.forEach(([x, y, rr]) => {
      c.beginPath();
      c.arc(x, y, rr, 0, 7);
      c.fill();
    });
  } else {
    c.lineWidth = s.size;
    c.lineCap = c.lineJoin = "round";
    c.beginPath();
    c.moveTo(p[0].x, p[0].y);
    if (p.length === 1) {
      c.arc(p[0].x, p[0].y, s.size / 2, 0, 7);
      c.fill();
    } else {
      p.slice(1).forEach((q) => c.lineTo(q.x, q.y));
      c.stroke();
    }
  }
  c.restore();
}
