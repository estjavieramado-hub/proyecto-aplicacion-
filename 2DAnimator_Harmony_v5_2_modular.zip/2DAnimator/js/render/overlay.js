/**
 * Capa de superposición: nodos Bézier, guías de simetría, asistente de calco, selección y lazo.
 */
"use strict";
function overlay() {
  octx.clearRect(0, 0, ov.width, ov.height);
  window.A2D && A2D.ext.onOverlay && A2D.ext.onOverlay(octx);
  {
    const sy = $("symmetry").value;
    if (sy !== "none") {
      octx.save();
      octx.strokeStyle = "#ff8a0099";
      octx.setLineDash([8, 6]);
      octx.lineWidth = 1 / S.zoom;
      octx.beginPath();
      if (sy === "r") {
        const n = Math.round(num($("symN").value, 6, 2, 16)),
          cx = S.width / 2,
          cy = S.height / 2,
          R = Math.hypot(cx, cy);
        for (let i = 0; i < n; i++) {
          const a = (Math.PI * 2 * i) / n;
          octx.moveTo(cx, cy);
          octx.lineTo(cx + R * Math.cos(a), cy + R * Math.sin(a));
        }
      } else {
        if (sy !== "h") {
          octx.moveTo(S.width / 2, 0);
          octx.lineTo(S.width / 2, S.height);
        }
        if (sy !== "v") {
          octx.moveTo(0, S.height / 2);
          octx.lineTo(S.width, S.height / 2);
        }
      }
      octx.stroke();
      octx.restore();
    }
  }
  if (L().mode === "mask")
    F().strokes.forEach((t) => {
      if (owner(t) === L()) drawStroke(octx, t, "#ff5a36", 0.4);
    });
  F().strokes.forEach((t) => {
    if (t.mt) {
      const q = pts(t)[0];
      if (q) {
        octx.save();
        octx.fillStyle = "#8e5bd6";
        octx.beginPath();
        octx.arc(q.x, q.y - 12, 9, 0, 7);
        octx.fill();
        octx.fillStyle = "#fff";
        octx.font = "bold 11px Segoe UI";
        octx.textAlign = "center";
        octx.textBaseline = "middle";
        octx.fillText(t.mt, q.x, q.y - 11.5);
        octx.restore();
      }
    }
  });
  if (S.skipF !== S.f) {
    S.skip = 0;
    S.skipF = S.f;
  }
  const m = $("lineReference").value,
    refs = [],
    ga = (+$("guideOpacity").value || 35) / 100;
  if ($("lineAssistant").checked && !S.playing && !(window.A2D && A2D.ext.smartOn && A2D.ext.smartOn())) {
    if (m !== "next" && S.frames[S.f - 1]) refs.push([S.frames[S.f - 1], "#168bc2"]);
    if (m !== "previous" && S.frames[S.f + 1]) refs.push([S.frames[S.f + 1], "#2fa66a"]);
  }
  const main = refs[0]?.[0],
    total = main?.strokes.length || 0,
    ti = Math.max(0, Math.min(F().strokes.length + S.skip, total - 1));
  refs.forEach(([ref, col]) => {
    octx.save();
    ref.strokes.forEach((s, i) => {
      let p = pts(s);
      if (!p.length) return;
      if (S.rev) p = [...p].reverse();
      const t = ref === main && i === ti;
      octx.globalAlpha = t ? 1 : ga;
      octx.strokeStyle = octx.fillStyle = t ? "#ff8a00" : col;
      octx.lineWidth = t ? 4 : 2;
      octx.setLineDash(t ? [] : [9, 6]);
      octx.beginPath();
      octx.moveTo(p[0].x, p[0].y);
      p.slice(1).forEach((q) => octx.lineTo(q.x, q.y));
      octx.stroke();
      octx.setLineDash([]);
      const a = p[0],
        b = p[Math.min(p.length - 1, Math.max(1, Math.floor(p.length * 0.22)))],
        g = Math.atan2(b.y - a.y, b.x - a.x),
        n = t ? 18 : 13;
      octx.beginPath();
      octx.moveTo(b.x, b.y);
      octx.lineTo(b.x - n * Math.cos(g - 0.5), b.y - n * Math.sin(g - 0.5));
      octx.lineTo(b.x - n * Math.cos(g + 0.5), b.y - n * Math.sin(g + 0.5));
      octx.closePath();
      octx.fill();
      octx.beginPath();
      octx.arc(a.x, a.y, t ? 10 : 7, 0, 7);
      octx.fill();
      octx.fillStyle = "#fff";
      octx.font = `bold ${t ? 13 : 10}px Segoe UI`;
      octx.textAlign = "center";
      octx.textBaseline = "middle";
      octx.fillText(i + 1, a.x, a.y + 0.5);
    });
    octx.restore();
  });
  $("nextStrokeLabel").textContent = total ? `Trazo ${ti + 1} de ${total}` : "Sin guía";
  $("guideBar").style.width = total ? Math.min(100, (F().strokes.length / total) * 100) + "%" : "0";
  $("directionLabel").textContent = S.rev ? "Final → inicio" : "Inicio → final";
  window.A2D && A2D.ext.onAssist && A2D.ext.onAssist(octx);
  if (S.sel && S.tool !== "node" && S.tool !== "bezier") {
    const m = msel();
    octx.save();
    octx.lineWidth = 1.5 / S.zoom;
    octx.setLineDash([6, 4]);
    m.forEach((t) => {
      const b = bbox([t]);
      octx.strokeStyle = m.length > 1 ? "#8ab4e8" : "#3d9be9";
      octx.strokeRect(b.x, b.y, b.w, b.h);
    });
    if (m.length > 1) {
      const b = bbox(m);
      octx.strokeStyle = "#3d9be9";
      octx.setLineDash([]);
      octx.strokeRect(b.x - 4, b.y - 4, b.w + 8, b.h + 8);
    }
    octx.restore();
  }
  if (S.lasso && S.lasso.pts.length > 1) {
    octx.save();
    octx.strokeStyle = "#ff8a00";
    octx.fillStyle = "#ff8a0022";
    octx.lineWidth = 1.5 / S.zoom;
    octx.setLineDash([5, 4]);
    octx.beginPath();
    S.lasso.pts.forEach((q, i) => (i ? octx.lineTo(q.x, q.y) : octx.moveTo(q.x, q.y)));
    octx.fill();
    octx.stroke();
    octx.restore();
  }
  if (S.tool === "select" && S.sel) SelXf.draw(octx);
  Node.drawOverlay(octx);
  Pen.drawOverlay(octx);
  Snap.draw(octx);
  if (S.marquee) {
    const M = S.marquee;
    octx.save();
    octx.lineWidth = 1 / S.zoom;
    octx.setLineDash([5 / S.zoom, 4 / S.zoom]);
    octx.fillStyle = M.mode === "zoom" ? "#ff8a0022" : "#4a9dff22";
    octx.strokeStyle = M.mode === "zoom" ? "#ff8a00" : "#4a9dff";
    octx.fillRect(M.x0, M.y0, M.x1 - M.x0, M.y1 - M.y0);
    octx.strokeRect(M.x0, M.y0, M.x1 - M.x0, M.y1 - M.y0);
    octx.restore();
  }
  if (S.tool === "eraser" && S.mouse && !S.playing) {
    octx.save();
    octx.lineWidth = 1.2 / S.zoom;
    octx.strokeStyle = "#000";
    octx.beginPath();
    octx.arc(S.mouse.x, S.mouse.y, S.eSize / 2, 0, 7);
    octx.stroke();
    octx.strokeStyle = "#fff";
    octx.setLineDash([3 / S.zoom, 3 / S.zoom]);
    octx.stroke();
    octx.restore();
  }
}
