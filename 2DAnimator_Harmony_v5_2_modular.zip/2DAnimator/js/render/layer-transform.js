/**
 * Curvas Bézier de aceleración, pistas de transformación de capa y huesos aplicados al dibujar/exportar.
 */
"use strict";
const bezE = (c, x) => {
  if (!c) return x;
  if (x <= 0) return 0;
  if (x >= 1) return 1;
  const z = (t, a, b) => 3 * (1 - t) * (1 - t) * t * a + 3 * (1 - t) * t * t * b + t * t * t;
  let lo = 0,
    hi = 1,
    t = x;
  for (let i = 0; i < 22; i++) {
    t = (lo + hi) / 2;
    z(t, c[0], c[2]) < x ? (lo = t) : (hi = t);
  }
  return z(t, c[1], c[3]);
};
const TR0 = { x: 0, y: 0, r: 0, s: 100, o: 100 },
  hasTr = (l) => l.tr && l.tr.length,
  pivotOf = (l) => l.pv || [S.width / 2, S.height / 2];
function trAt(l, f) {
  const K = l.tr;
  if (!K || !K.length) return TR0;
  if (f <= K[0].f) return K[0];
  const z = K[K.length - 1];
  if (f >= z.f) return z;
  let i = 0;
  while (K[i + 1].f <= f) i++;
  const a = K[i],
    b = K[i + 1],
    t = (f - a.f) / (b.f - a.f),
    o = {};
  for (const q of ["x", "y", "r", "s", "o"]) o[q] = a[q] + (b[q] - a[q]) * bezE(a.c && a.c[q], t);
  return o;
}
function trApply(g, l, fi) {
  const k = trAt(l, fi),
    v = pivotOf(l);
  g.translate(v[0] + k.x, v[1] + k.y);
  g.rotate((k.r * Math.PI) / 180);
  g.scale(k.s / 100, k.s / 100);
  g.translate(-v[0], -v[1]);
  return k.o / 100;
}
const rigAt = (b, f) => {
  const K = b.rk;
  if (!K || !K.length) return 0;
  if (f <= K[0].f) return K[0].r;
  const z = K[K.length - 1];
  if (f >= z.f) return z.r;
  let i = 0;
  while (K[i + 1].f <= f) i++;
  const a = K[i],
    c = K[i + 1];
  return a.r + (c.r - a.r) * bezE(a.c, (f - a.f) / (c.f - a.f));
};
const rigChain = (l) => {
  const R = S.rig;
  if (!R || !l.bone) return [];
  const by = new Map(R.bones.map((b) => [b.id, b])),
    ch = [];
  let b = by.get(l.bone),
    g = 0;
  while (b && g++ < 64) {
    ch.unshift(b);
    b = by.get(b.parent);
  }
  return ch;
};
const rigged = (l) => !!(S.rig && l.bone && S.rig.bones.some((b) => b.id === l.bone)),
  hasXf = (l) => hasTr(l) || rigged(l);
function rigApply(g, l, fi) {
  for (const b of rigChain(l)) {
    const t = rigAt(b, fi);
    g.translate(b.x, b.y);
    g.rotate((t * Math.PI) / 180);
    g.translate(-b.x, -b.y);
  }
}
function svgGroup(l, fi, g) {
  const rg = rigChain(l)
      .map((b) => `translate(${b.x} ${b.y}) rotate(${rigAt(b, fi)}) translate(${-b.x} ${-b.y})`)
      .join(" "),
    tr = hasTr(l);
  if (!tr && !rg) return g.join("");
  const k = trAt(l, fi),
    v = pivotOf(l);
  return `<g transform="${[rg, tr ? `translate(${v[0] + k.x} ${v[1] + k.y}) rotate(${k.r}) scale(${k.s / 100}) translate(${-v[0]} ${-v[1]})` : ""].filter(Boolean).join(" ")}" opacity="${k.o / 100}">${g.join("")}</g>`;
}
