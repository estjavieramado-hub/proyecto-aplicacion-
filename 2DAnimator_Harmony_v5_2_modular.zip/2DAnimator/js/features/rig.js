/* 2D Animator — Rigging 2D (Fase 6A). Script clásico (funciona sin servidor). Usa window.A2D de app.js.
   Rig de recortes: huesos con jerarquía y rotación animable por claves; las CAPAS se vinculan a huesos,
   de modo que el dibujo cuadro a cuadro de cada parte sigue al esqueleto. */
(() => {
  "use strict";
  const A = window.A2D;
  if (!A || !A.ext || !A.rigAt) return;
  const { S, L, uid, num, hint, pushUndo, dirty, all, render } = A,
    $ = (id) => document.getElementById(id);
  const esc = (s) =>
    String(s).replace(
      /[&<>"']/g,
      (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]
    );
  let sel = null;
  const bones = () => (S.rig ? S.rig.bones : []),
    SB = () => bones().find((b) => b.id === sel) || null;
  const chainOf = (b) => {
    const m = new Map(bones().map((x) => [x.id, x])),
      c = [];
    let x = b,
      g = 0;
    while (x && g++ < 64) {
      c.unshift(x);
      x = m.get(x.parent);
    }
    return c;
  };
  const tailRest = (b) => ({
    x: b.x + b.len * Math.cos((b.ang * Math.PI) / 180),
    y: b.y + b.len * Math.sin((b.ang * Math.PI) / 180),
  });
  /* cinemática directa: aplica primero la rotación del propio hueso y luego la de sus ancestros (f=null → pose de reposo) */
  const xf = (ch, p, f) => {
    let q = { x: p.x, y: p.y };
    for (let i = ch.length - 1; i >= 0; i--) {
      const b = ch[i],
        t = ((f === null ? 0 : A.rigAt(b, f)) * Math.PI) / 180,
        c = Math.cos(t),
        s = Math.sin(t),
        dx = q.x - b.x,
        dy = q.y - b.y;
      q = { x: b.x + dx * c - dy * s, y: b.y + dx * s + dy * c };
    }
    return q;
  };
  const posed = (b, f) => {
    const ch = chainOf(b);
    return { h: xf(ch, { x: b.x, y: b.y }, f), t: xf(ch, tailRest(b), f), ch };
  };
  A.ext.rigPose = (f) =>
    new Map(
      bones().map((b) => {
        const p = posed(b, f);
        return [b.id, { head: p.h, tail: p.t }];
      })
    );
  const segDist = (p, a, b) => {
    const dx = b.x - a.x,
      dy = b.y - a.y,
      l2 = dx * dx + dy * dy || 1,
      t = Math.max(0, Math.min(1, ((p.x - a.x) * dx + (p.y - a.y) * dy) / l2));
    return Math.hypot(p.x - a.x - t * dx, p.y - a.y - t * dy);
  };
  function ensureRk(b, f) {
    let k = (b.rk || (b.rk = [])).find((k) => k.f === f);
    if (!k) {
      k = { f, r: A.rigAt(b, f) };
      b.rk.push(k);
      b.rk.sort((x, y) => x.f - y.f);
    }
    return k;
  }
  const setRot = (b, v) => {
    ensureRk(b, S.f).r = Math.max(b.mn, Math.min(b.mx, v));
  };
  const subtree = (id) => {
    const o = [id];
    for (let i = 0; i < o.length; i++)
      bones().forEach((b) => {
        if (b.parent === o[i] && !o.includes(b.id)) o.push(b.id);
      });
    return o;
  };

  /* ---------- panel ---------- */
  const P = document.createElement("details");
  P.open = true;
  P.innerHTML =
    '<summary>Esqueleto (rig 2D)</summary><div class="pb">' +
    '<label class="ck"><input type="checkbox" id="rgShow" checked> Mostrar esqueleto</label><label class="ck"><input type="checkbox" id="rgSnap" checked> Conectar al extremo de otro hueso</label>' +
    '<div class="rgl" id="rgList"></div>' +
    '<label>Nombre <input id="rgName" type="text" maxlength="40"></label>' +
    '<div class="row2"><label>Largo <input id="rgLen" type="number" min="1"></label><label>Ángulo reposo ° <input id="rgAng" type="number"></label></div>' +
    '<label>Hueso padre <select id="rgPar"></select></label>' +
    '<div class="row2"><label>Mín ° <input id="rgMn" type="number"></label><label>Máx ° <input id="rgMx" type="number"></label></div>' +
    '<label>Rotación en este fotograma ° <input id="rgRot" type="number"></label>' +
    '<div class="row2"><button id="rgKey">◆ Clave rotación</button><button id="rgKDel">✕ Quitar clave</button></div><button id="rgDel">Eliminar hueso (y sus hijos)</button>' +
    '<label>Capa activa vinculada a <select id="rgBind"></select></label>' +
    '<div class="row2"><input id="rgPoseName" type="text" placeholder="Nombre de pose" maxlength="40"><button id="rgPoseSave">Guardar pose</button></div>' +
    '<select id="rgPoses"></select><div class="row2"><button id="rgPoseApply">Aplicar aquí</button><button id="rgPoseDel">Borrar pose</button></div>' +
    '<div class="row2"><button id="rgExport">Exportar esqueleto</button><button id="rgImport">Importar esqueleto</button></div><input type="file" id="rgImportIn" accept=".json" hidden>' +
    '<p class="muted">J = crear huesos (arrastra; cerca de un extremo se conecta). M = posar (arrastra un hueso). Vincula cada capa a un hueso: se mueve con él y sigue dibujándose cuadro a cuadro. Se ve la pose en «Vista final», al reproducir y al exportar.</p></div>';
  $("hintBox").before(P);
  const optG = document.createElement("option");
  optG.value = "bone";
  optG.textContent = "Hueso · rotación";
  $("geTgt").append(optG);
  A.ext.boneCurve = (a) => {
    const b = SB(),
      k = b && (b.rk || []).find((k) => k.f === S.f);
    if (!k) return null;
    if (a) {
      k.c = a;
      return a;
    }
    return k.c || [0, 0, 1, 1];
  };

  function ui() {
    const order = [],
      walk = (p, d) =>
        bones()
          .filter((b) => (b.parent || null) === p)
          .forEach((b) => {
            order.push([b, d]);
            walk(b.id, d + 1);
          });
    walk(null, 0);
    $("rgList").innerHTML = order.length
      ? order
          .map(
            ([b, d]) =>
              `<div data-id="${b.id}" class="${b.id === sel ? "on" : ""}" style="padding-left:${6 + d * 14}px">${d ? "↳ " : ""}${esc(b.name)}${S.layers.some((l) => l.bone === b.id) ? " ◧" : ""}</div>`
          )
          .join("")
      : "<i>Sin huesos. Elige la herramienta Hueso (J) y arrastra sobre el lienzo.</i>";
    const b = SB(),
      dis = !b,
      foc = (id) => document.activeElement === $(id);
    ["rgName", "rgLen", "rgAng", "rgMn", "rgMx", "rgRot", "rgPar", "rgKey", "rgKDel", "rgDel"].forEach(
      (id) => {
        $(id).disabled = dis;
      }
    );
    if (b) {
      if (!foc("rgName")) $("rgName").value = b.name;
      if (!foc("rgLen")) $("rgLen").value = Math.round(b.len * 10) / 10;
      if (!foc("rgAng")) $("rgAng").value = Math.round(b.ang * 10) / 10;
      if (!foc("rgMn")) $("rgMn").value = b.mn;
      if (!foc("rgMx")) $("rgMx").value = b.mx;
      if (!foc("rgRot")) $("rgRot").value = Math.round(A.rigAt(b, S.f) * 10) / 10;
      const ban = new Set(subtree(b.id));
      $("rgPar").innerHTML =
        '<option value="">— ninguno (raíz) —</option>' +
        bones()
          .filter((x) => !ban.has(x.id))
          .map((x) => `<option value="${x.id}">${esc(x.name)}</option>`)
          .join("");
      $("rgPar").value = b.parent || "";
    }
    $("rgBind").innerHTML =
      '<option value="">— sin hueso —</option>' +
      bones()
        .map((x) => `<option value="${x.id}">${esc(x.name)}</option>`)
        .join("");
    $("rgBind").value = L().bone || "";
    $("rgPoses").innerHTML =
      (S.rig ? S.rig.poses : []).map((q, i) => `<option value="${i}">${esc(q.name)}</option>`).join("") ||
      '<option value="">(sin poses)</option>';
  }
  $("rgList").addEventListener("click", (e) => {
    const d = e.target.closest("[data-id]");
    if (d) {
      sel = d.dataset.id;
      ui();
      render();
    }
  });
  const edit = (fn) => {
    const b = SB();
    if (!b) return;
    pushUndo();
    fn(b);
    dirty();
    all();
  };
  $("rgName").addEventListener("change", (e) =>
    edit((b) => {
      b.name = e.target.value.trim().slice(0, 40) || b.name;
    })
  );
  $("rgLen").addEventListener("change", (e) =>
    edit((b) => {
      b.len = num(e.target.value, b.len, 1, 1e5);
    })
  );
  $("rgAng").addEventListener("change", (e) =>
    edit((b) => {
      b.ang = num(e.target.value, b.ang, -360, 360);
    })
  );
  $("rgMn").addEventListener("change", (e) =>
    edit((b) => {
      b.mn = Math.min(num(e.target.value, b.mn, -360, 360), b.mx);
    })
  );
  $("rgMx").addEventListener("change", (e) =>
    edit((b) => {
      b.mx = Math.max(num(e.target.value, b.mx, -360, 360), b.mn);
    })
  );
  $("rgPar").addEventListener("change", (e) =>
    edit((b) => {
      b.parent = e.target.value || undefined;
    })
  );
  $("rgRot").addEventListener("change", (e) => edit((b) => setRot(b, num(e.target.value, 0, -3600, 3600))));
  $("rgKey").onclick = () =>
    edit((b) => {
      ensureRk(b, S.f);
    });
  $("rgKDel").onclick = () => {
    const b = SB();
    if (!b || !(b.rk || []).some((k) => k.f === S.f))
      return hint("No hay clave de rotación en este fotograma.");
    edit((x) => {
      x.rk = x.rk.filter((k) => k.f !== S.f);
      if (!x.rk.length) delete x.rk;
    });
  };
  $("rgDel").onclick = () => {
    const b = SB();
    if (!b) return;
    pushUndo();
    const del = new Set(subtree(b.id));
    S.rig.bones = S.rig.bones.filter((x) => !del.has(x.id));
    S.layers.forEach((l) => {
      if (del.has(l.bone)) delete l.bone;
    });
    S.rig.poses.forEach((q) => del.forEach((id) => delete q.a[id]));
    sel = b.parent && !del.has(b.parent) ? b.parent : null;
    if (!S.rig.bones.length) S.rig = null;
    dirty();
    all();
  };
  $("rgBind").addEventListener("change", (e) => {
    pushUndo();
    const l = L();
    if (e.target.value) l.bone = e.target.value;
    else delete l.bone;
    dirty();
    all();
  });
  $("rgPoseSave").onclick = () => {
    if (!S.rig) return hint("Crea primero el esqueleto.");
    pushUndo();
    const n = ($("rgPoseName").value || "").trim() || "Pose " + (S.rig.poses.length + 1),
      a = {};
    bones().forEach((b) => {
      a[b.id] = Math.round(A.rigAt(b, S.f) * 100) / 100;
    });
    S.rig.poses.push({ name: n.slice(0, 40), a });
    $("rgPoseName").value = "";
    dirty();
    all();
    hint("Pose «" + n + "» guardada.");
  };
  $("rgPoseApply").onclick = () => {
    const q = S.rig && S.rig.poses[+$("rgPoses").value];
    if (!q) return hint("Elige una pose.");
    pushUndo();
    bones().forEach((b) => {
      if (q.a[b.id] !== undefined) ensureRk(b, S.f).r = Math.max(b.mn, Math.min(b.mx, q.a[b.id]));
    });
    dirty();
    all();
    hint("Pose «" + q.name + "» aplicada como claves en el fotograma " + (S.f + 1) + ".");
  };
  $("rgPoseDel").onclick = () => {
    const i = +$("rgPoses").value;
    if (!S.rig || !S.rig.poses[i]) return;
    pushUndo();
    S.rig.poses.splice(i, 1);
    dirty();
    all();
  };

  /* ---------- guardar / cargar configuraciones de esqueleto ---------- */
  $("rgExport").onclick = () => {
    if (!S.rig) return hint("No hay esqueleto que exportar.");
    const bind = {};
    S.layers.forEach((l) => {
      if (l.bone) bind[l.name] = l.bone;
    });
    const j = {
        format: "2DAnimatorRig",
        version: 1,
        bones: S.rig.bones.map(({ rk, ...b }) => b),
        poses: S.rig.poses,
        bind,
      },
      a = document.createElement("a");
    a.href = URL.createObjectURL(new Blob([JSON.stringify(j, null, 1)], { type: "application/json" }));
    a.download = "esqueleto.rig.json";
    a.click();
    setTimeout(() => URL.revokeObjectURL(a.href), 1000);
    hint("Esqueleto exportado (huesos, poses y vínculos por nombre de capa).");
  };
  A.ext.rigImport = (j) => {
    if (!j || j.format !== "2DAnimatorRig") throw Error("El archivo no es un esqueleto de 2D Animator.");
    const r = A.cleanRig(j);
    if (!r) throw Error("El esqueleto no contiene huesos.");
    pushUndo();
    S.rig = r;
    S.layers.forEach((l) => {
      const id = j.bind && j.bind[l.name];
      if (r.bones.some((b) => b.id === id)) l.bone = id;
      else delete l.bone;
    });
    sel = r.bones[0].id;
    dirty();
    all();
  };
  $("rgImport").onclick = () => $("rgImportIn").click();
  $("rgImportIn").onchange = async (e) => {
    const f = e.target.files[0];
    e.target.value = "";
    if (!f) return;
    try {
      if (f.size > 5e6) throw Error("archivo demasiado grande");
      if (S.rig && !confirm("Se reemplazará el esqueleto actual (se puede deshacer). ¿Continuar?")) return;
      A.ext.rigImport(JSON.parse(await f.text()));
      hint("Esqueleto importado.");
    } catch (err) {
      hint("No se pudo importar: " + err.message);
    }
  };

  /* ---------- herramientas Hueso y Pose ---------- */
  const cvE = $("artCanvas");
  let bd = null,
    pd = null;
  cvE.addEventListener(
    "pointerdown",
    (e) => {
      const t = S.tool;
      if ((t !== "bone" && t !== "pose") || e.button !== 0 || S.space) return;
      e.stopImmediatePropagation();
      if (S.playing) return;
      const p = A.pt(e);
      if (t === "bone") {
        let par = null,
          h = { x: p.x, y: p.y };
        if ($("rgSnap").checked) {
          let m = 22;
          bones().forEach((b) => {
            const q = tailRest(b),
              d = Math.hypot(q.x - p.x, q.y - p.y);
            if (d < m) {
              m = d;
              par = b;
              h = q;
            }
          });
        }
        bd = { h, par: par && par.id, t: { ...h } };
        cvE.setPointerCapture(e.pointerId);
        render();
        return;
      }
      if (!S.rig) return hint("Crea primero un esqueleto con la herramienta Hueso (J).");
      let best = null,
        m = 18;
      bones().forEach((b) => {
        const q = posed(b, S.f),
          d = segDist(p, q.h, q.t);
        if (d < m) {
          m = d;
          best = b;
        }
      });
      if (!best) return hint("Pincha sobre un hueso para posarlo.");
      sel = best.id;
      pd = { b: best };
      pushUndo();
      cvE.setPointerCapture(e.pointerId);
      ui();
      render();
    },
    true
  );
  cvE.addEventListener(
    "pointermove",
    (e) => {
      if (!bd && !pd) return;
      e.stopImmediatePropagation();
      const p = A.pt(e);
      if (bd) {
        bd.t = { x: p.x, y: p.y };
        render();
        return;
      }
      const b = pd.b,
        anc = chainOf(b)
          .slice(0, -1)
          .reduce((s, x) => s + A.rigAt(x, S.f), 0),
        ph = posed(b, S.f).h;
      let th = (Math.atan2(p.y - ph.y, p.x - ph.x) * 180) / Math.PI - b.ang - anc;
      th = (((th % 360) + 540) % 360) - 180;
      setRot(b, th);
      render();
      ui();
    },
    true
  );
  const rend = (e) => {
    if (!bd && !pd) return;
    e.stopImmediatePropagation();
    if (bd) {
      const d = bd;
      bd = null;
      const len = Math.hypot(d.t.x - d.h.x, d.t.y - d.h.y);
      if (len < 8) {
        render();
        return;
      }
      pushUndo();
      if (!S.rig) S.rig = { bones: [], poses: [] };
      const b = {
        id: uid(),
        name: "Hueso " + (S.rig.bones.length + 1),
        parent: d.par || undefined,
        x: d.h.x,
        y: d.h.y,
        len,
        ang: (Math.atan2(d.t.y - d.h.y, d.t.x - d.h.x) * 180) / Math.PI,
        mn: -180,
        mx: 180,
      };
      S.rig.bones.push(b);
      sel = b.id;
      dirty();
      all();
      return;
    }
    pd = null;
    dirty();
    all();
  };
  cvE.addEventListener("pointerup", rend, true);
  cvE.addEventListener("pointercancel", rend, true);

  /* ---------- dibujo del esqueleto (superposición) ---------- */
  const kite = (o, a, b, on, z) => {
    const L = Math.hypot(b.x - a.x, b.y - a.y) || 1,
      w = Math.min(8, L * 0.16),
      nx = (-(b.y - a.y) / L) * w,
      ny = ((b.x - a.x) / L) * w,
      mx = a.x + (b.x - a.x) * 0.2,
      my = a.y + (b.y - a.y) * 0.2;
    o.globalAlpha = 0.85;
    o.fillStyle = on ? "#ff8a0088" : "#2fa6a888";
    o.strokeStyle = on ? "#ff8a00" : "#1b7f7f";
    o.lineWidth = 1.5 * z;
    o.beginPath();
    o.moveTo(a.x, a.y);
    o.lineTo(mx + nx, my + ny);
    o.lineTo(b.x, b.y);
    o.lineTo(mx - nx, my - ny);
    o.closePath();
    o.fill();
    o.stroke();
    o.fillStyle = "#fff";
    o.beginPath();
    o.arc(a.x, a.y, 5 * z, 0, 7);
    o.fill();
    o.stroke();
  };
  const prevOv = A.ext.onOverlay;
  A.ext.onOverlay = (o) => {
    if (prevOv) prevOv(o);
    if (!$("rgShow").checked) return;
    const f = S.final || S.tool === "pose" || S.playing ? S.f : null,
      z = 1 / S.zoom;
    o.save();
    bones().forEach((b) => {
      const q = posed(b, f);
      kite(o, q.h, q.t, b.id === sel, z);
    });
    if (bd) kite(o, bd.h, bd.t, true, z);
    o.restore();
  };
  $("rgShow").addEventListener("change", render);
  const o1 = A.ext.onTl,
    o2 = A.ext.onLoad;
  A.ext.onTl = () => {
    if (o1) o1();
    ui();
  };
  A.ext.onLoad = () => {
    if (o2) o2();
    if (!SB()) sel = null;
    ui();
  };
  ui();
})();
