/* 2D Animator — Asistente vectorial avanzado (Fase 4). Script clásico (funciona sin servidor).
   Solo dibuja guías en la capa de superposición: NUNCA modifica el dibujo. Usa window.A2D de app.js. */
(() => {
  "use strict";
  const A = window.A2D;
  if (!A || !A.ext) return;
  const { S, F, owner, pts, num, render } = A,
    $ = (id) => document.getElementById(id);
  const DEF = { prev: "#168bc2", next: "#2fa66a", tgt: "#ff8a00" },
    CFG = { ...DEF };
  try {
    const j = JSON.parse(localStorage.getItem("2dAnimatorAssist") || "{}");
    Object.keys(DEF).forEach((k) => {
      if (/^#[0-9a-f]{6}$/i.test(j[k])) CFG[k] = j[k];
    });
  } catch (_) {}
  const save = () => {
    try {
      localStorage.setItem("2dAnimatorAssist", JSON.stringify(CFG));
    } catch (_) {}
  };

  /* ---------- panel ---------- */
  const P = document.createElement("details");
  P.open = true;
  P.innerHTML =
    '<summary>Asistente vectorial avanzado</summary><div class="pb">' +
    '<label class="ck"><input type="checkbox" id="smartOn" checked> Activar (reemplaza la guía simple; usa sus opciones de arriba)</label>' +
    '<label class="ck"><input type="checkbox" id="smLayer" checked> Solo la capa activa</label>' +
    '<label class="ck"><input type="checkbox" id="smPred" checked> Predicción de movimiento</label>' +
    '<label class="ck"><input type="checkbox" id="smProp" checked> Guías de posición y proporción</label>' +
    '<label class="ck"><input type="checkbox" id="smMiss" checked> Resaltar trazos que faltan</label>' +
    '<label>Tolerancia de correspondencia <b id="smTolV">90 px</b></label><input type="range" id="smTol" min="20" max="250" value="90">' +
    '<div class="row2"><label>Anterior <input type="color" id="smCP"></label><label>Siguiente <input type="color" id="smCN"></label></div>' +
    '<div class="row2"><label>Objetivo <input type="color" id="smCT"></label><button id="smReset">Restablecer</button></div>' +
    '<b id="smStatus">—</b><ul id="smSug" class="muted"></ul>' +
    '<p class="muted">Solo dibuja guías: nunca modifica tu dibujo. Teclas [ y ] = trazo anterior / siguiente. Empareja con asignación global: etiquetas manuales primero y después posición, forma, extremos y tipo de trazo. La predicción usa la mediana del movimiento para evitar saltos.</p></div>';
  $("lineAssistant").closest("details").after(P);
  const COL = { smCP: "prev", smCN: "next", smCT: "tgt" };
  const syncCol = () =>
    Object.entries(COL).forEach(([id, k]) => {
      $(id).value = CFG[k];
    });
  syncCol();
  Object.entries(COL).forEach(([id, k]) =>
    $(id).addEventListener("input", (e) => {
      CFG[k] = e.target.value;
      save();
      render();
    })
  );
  ["smartOn", "smLayer", "smPred", "smProp", "smMiss"].forEach((id) =>
    $(id).addEventListener("change", render)
  );
  $("smTol").addEventListener("input", (e) => {
    $("smTolV").textContent = e.target.value + " px";
    render();
  });
  $("smReset").onclick = () => {
    Object.assign(CFG, DEF);
    save();
    syncCol();
    $("smTol").value = 90;
    $("smTolV").textContent = "90 px";
    S.skip = 0;
    render();
  };
  document.addEventListener("keydown", (e) => {
    if (/INPUT|SELECT|TEXTAREA/.test(e.target.tagName) || e.ctrlKey || e.metaKey || e.altKey) return;
    if (e.key === "[") {
      S.skip--;
      render();
    } else if (e.key === "]") {
      S.skip++;
      render();
    }
  });

  /* ---------- geometría ---------- */
  const D = (s) => {
    const q = pts(s);
    let L = 0,
      x0 = 1e9,
      y0 = 1e9,
      x1 = -1e9,
      y1 = -1e9,
      cx = 0,
      cy = 0;
    q.forEach((p, i) => {
      if (i) L += Math.hypot(p.x - q[i - 1].x, p.y - q[i - 1].y);
      x0 = Math.min(x0, p.x);
      y0 = Math.min(y0, p.y);
      x1 = Math.max(x1, p.x);
      y1 = Math.max(y1, p.y);
      cx += p.x;
      cy += p.y;
    });
    const n = q.length || 1;
    return { s, q, cx: cx / n, cy: cy / n, L, w: x1 - x0, h: y1 - y0, x0, y0, x1, y1 };
  };
  // Puntuación geométrica normalizada: evita que el tamaño del dibujo domine
  // la correspondencia. Los extremos ayudan a distinguir trazos cercanos.
  const cost = (a, b) => {
    const diag = Math.max(80, Math.hypot(a.w, a.h, b.w, b.h));
    const center = Math.hypot(a.cx - b.cx, a.cy - b.cy);
    const shape = Math.abs(Math.log((a.L + 8) / (b.L + 8))) * diag * 0.22;
    const box = (Math.abs(a.w - b.w) + Math.abs(a.h - b.h)) * 0.18;
    const ends =
      Math.min(
        Math.hypot(a.q[0].x - b.q[0].x, a.q[0].y - b.q[0].y) +
          Math.hypot(a.q.at(-1).x - b.q.at(-1).x, a.q.at(-1).y - b.q.at(-1).y),
        Math.hypot(a.q[0].x - b.q.at(-1).x, a.q[0].y - b.q.at(-1).y) +
          Math.hypot(a.q.at(-1).x - b.q[0].x, a.q.at(-1).y - b.q[0].y)
      ) * 0.12;
    const kind = a.s.kind === b.s.kind ? 0 : diag * 0.3;
    return center * 0.52 + shape + box + ends + kind;
  };
  // Asignación global de coste mínimo (Hungarian), en lugar de emparejar
  // simplemente el primer candidato más cercano.
  function assign(costs) {
    const n = costs.length,
      m = n ? costs[0].length : 0;
    if (!n || !m) return [];
    const trans = n > m,
      a = trans
        ? Array.from({ length: m }, (_, j) => Array.from({ length: n }, (_, i) => costs[i][j]))
        : costs;
    const N = a.length,
      M = a[0].length,
      u = Array(N + 1).fill(0),
      v = Array(M + 1).fill(0),
      p = Array(M + 1).fill(0),
      way = Array(M + 1).fill(0);
    for (let i = 1; i <= N; i++) {
      p[0] = i;
      let j0 = 0,
        minv = Array(M + 1).fill(Infinity),
        used = Array(M + 1).fill(false);
      do {
        used[j0] = true;
        const i0 = p[j0];
        let delta = Infinity,
          j1 = 0;
        for (let j = 1; j <= M; j++)
          if (!used[j]) {
            const cur = a[i0 - 1][j - 1] - u[i0] - v[j];
            if (cur < minv[j]) {
              minv[j] = cur;
              way[j] = j0;
            }
            if (minv[j] < delta) {
              delta = minv[j];
              j1 = j;
            }
          }
        for (let j = 0; j <= M; j++)
          if (used[j]) {
            u[p[j]] += delta;
            v[j] -= delta;
          } else minv[j] -= delta;
        j0 = j1;
      } while (p[j0] !== 0);
      do {
        const j1 = way[j0];
        p[j0] = p[j1];
        j0 = j1;
      } while (j0);
    }
    const out = [];
    for (let j = 1; j <= M; j++) if (p[j]) out.push(trans ? [j - 1, p[j] - 1] : [p[j] - 1, j - 1]);
    return out;
  }
  function match(R, C, tol) {
    const m = new Map(),
      used = new Set();
    // Las etiquetas manuales son la referencia más fiable, pero solo se
    // aceptan una vez y cuando el trazo no está vacío.
    R.forEach((r, i) => {
      if (r.s.mt == null) return;
      const j = C.findIndex((c, k) => !used.has(k) && c.s.mt === r.s.mt);
      if (j >= 0) {
        m.set(i, j);
        used.add(j);
      }
    });
    const ri = R.map((_, i) => i).filter((i) => !m.has(i)),
      cj = C.map((_, j) => j).filter((j) => !used.has(j));
    if (ri.length && cj.length) {
      const raw = ri.map((i) => cj.map((j) => cost(R[i], C[j])));
      const matrix = raw.map((row) => row.concat(Array(ri.length).fill(tol + 1)));
      assign(matrix).forEach(([x, y]) => {
        if (y < cj.length && raw[x][y] <= tol) {
          const i = ri[x],
            j = cj[y];
          m.set(i, j);
          used.add(j);
        }
      });
    }
    return m;
  }
  const bb = (L) =>
    L.length
      ? {
          x0: Math.min(...L.map((d) => d.x0)),
          y0: Math.min(...L.map((d) => d.y0)),
          x1: Math.max(...L.map((d) => d.x1)),
          y1: Math.max(...L.map((d) => d.y1)),
        }
      : null;
  const mean = (a) =>
    a.length
      ? { x: a.reduce((s, v) => s + v.x, 0) / a.length, y: a.reduce((s, v) => s + v.y, 0) / a.length }
      : null;
  const median = (a) => {
    if (!a.length) return null;
    const m = (k) => {
      const v = a.map((q) => q[k]).sort((x, y) => x - y),
        h = v.length >> 1;
      return v.length % 2 ? v[h] : (v[h - 1] + v[h]) / 2;
    };
    return { x: m("x"), y: m("y") };
  };
  const okf = () => {
    const lay = A.L(),
      own = $("smLayer").checked;
    return (s) => {
      const o = owner(s);
      return !!o && o.visible && (!own || o === lay) && pts(s).length > 0;
    };
  };

  /* ---------- análisis: qué está hecho, qué sigue, qué falta ---------- */
  function analyze() {
    const ok = okf(),
      mode = $("lineReference").value,
      rf = [];
    if (mode !== "next" && S.frames[S.f - 1]) rf.push({ fr: S.f - 1, col: CFG.prev, dir: -1 });
    if (mode !== "previous" && S.frames[S.f + 1]) rf.push({ fr: S.f + 1, col: CFG.next, dir: 1 });
    if (!rf.length) return null;
    const tol = num($("smTol").value, 90, 20, 300),
      cur = F().strokes.filter(ok).map(D),
      mn = rf[0],
      R = S.frames[mn.fr].strokes.filter(ok).map(D),
      n = R.length;
    if (!n)
      return {
        rf,
        mn,
        R,
        n: 0,
        cur,
        pend: [],
        done: [],
        ti: 0,
        pred: { x: 0, y: 0, src: "sin trazos en la referencia" },
        link: {},
        jerk: [],
        mp: new Map(),
        prop: null,
        sug: ["La referencia no tiene trazos en esta capa."],
      };
    const mp = match(R, cur, tol),
      done = R.map((_, i) => mp.has(i)),
      pend = R.map((_, i) => i).filter((i) => !done[i]);
    const ti = Math.max(0, Math.min(n - 1, (pend.length ? pend[0] : n - 1) + S.skip));
    const f2 = S.frames[mn.fr + mn.dir],
      R2 = f2 ? f2.strokes.filter(ok).map(D) : [],
      m2 = R2.length ? match(R, R2, tol * 1.5) : new Map();
    const vel = (i) => (m2.has(i) ? { x: R[i].cx - R2[m2.get(i)].cx, y: R[i].cy - R2[m2.get(i)].cy } : null);
    const obs = [];
    done.forEach((d, i) => {
      if (d) {
        const c = cur[mp.get(i)];
        obs.push({ i, x: c.cx - R[i].cx, y: c.cy - R[i].cy });
      }
    });
    const hv = vel(ti) || mean(R.map((_, i) => vel(i)).filter(Boolean));
    let pred = { x: 0, y: 0, src: "sin datos de movimiento: se usa la posición de la referencia" };
    if (obs.length)
      pred = { ...median(obs), src: "mediana del movimiento observado (reduce saltos atípicos)" };
    else if (hv) pred = { ...hv, src: "tendencia de los fotogramas vecinos" };
    const T = R[ti],
      tq = S.rev ? [...T.q].reverse() : T.q,
      link = {};
    [
      ["start", tq[0]],
      ["end", tq[tq.length - 1]],
    ].forEach(([k, pt]) =>
      R.forEach((Q, j) => {
        if (j === ti || !done[j] || link[k]) return;
        const c = cur[mp.get(j)];
        [
          [Q.q[0], c.q[0]],
          [Q.q[Q.q.length - 1], c.q[c.q.length - 1]],
        ].forEach(([qr, qc]) => {
          if (!link[k] && Math.hypot(qr.x - pt.x, qr.y - pt.y) < 14)
            link[k] = { x: qc.x, y: qc.y, tx: pt.x + pred.x, ty: pt.y + pred.y };
        });
      })
    );
    const dR = R.filter((_, i) => done[i]),
      dC = R.map((_, i) => (done[i] ? cur[mp.get(i)] : null)).filter(Boolean),
      bR = bb(dR),
      bC = bb(dC);
    const prop =
      dR.length >= 2 && bR.x1 - bR.x0 > 20 && bR.y1 - bR.y0 > 20
        ? { w: (bC.x1 - bC.x0) / (bR.x1 - bR.x0), h: (bC.y1 - bC.y0) / (bR.y1 - bR.y0) }
        : null;
    const jerk = [];
    obs.forEach((o) => {
      const v = vel(o.i);
      if (v) {
        const j = Math.hypot(o.x - v.x, o.y - v.y);
        if (j > 35) jerk.push({ i: o.i, px: Math.round(j) });
      }
    });
    const used = new Set(mp.values()),
      extra = cur.filter((_, j) => !used.has(j)).length,
      sug = [];
    if (!obs.length && !cur.length) sug.push(`Empieza por el trazo ${ti + 1} del fotograma ${mn.fr + 1}.`);
    else if (pend.length)
      sug.push(
        `Faltan ${pend.length} de ${n} trazos del fotograma ${mn.fr + 1}: ${pend.map((i) => i + 1).join(", ")}.`
      );
    else sug.push("✔ Todos los trazos de la referencia tienen equivalente en este fotograma.");
    if (extra && obs.length)
      sug.push(`${extra} trazo(s) nuevo(s) sin equivalente en la referencia (¿intencionado?).`);
    if (prop) {
      const d = (v, a, b) =>
          Math.abs(v - 1) > 0.08 ? Math.round(Math.abs(v - 1) * 100) + "% " + (v > 1 ? a : b) : null,
        dh = d(prop.h, "más alto", "más bajo"),
        dw = d(prop.w, "más ancho", "más estrecho");
      if (dh || dw)
        sug.push("Proporción: el dibujo es " + [dh, dw].filter(Boolean).join(" y ") + " que la referencia.");
    }
    jerk
      .slice(0, 3)
      .forEach((j) =>
        sug.push(`Trazo ${j.i + 1}: salto de ${j.px} px respecto a la tendencia del movimiento.`)
      );
    return { rf, mn, R, n, cur, pend, done, ti, pred, link, jerk, mp, prop, sug, extra };
  }

  /* ---------- dibujo de guías (solo superposición) ---------- */
  const poly = (o, q) => {
    o.beginPath();
    q.forEach((p, i) => (i ? o.lineTo(p.x, p.y) : o.moveTo(p.x, p.y)));
    o.stroke();
  };
  const tri = (o, a, b, n) => {
    const g = Math.atan2(b.y - a.y, b.x - a.x);
    o.beginPath();
    o.moveTo(b.x, b.y);
    o.lineTo(b.x - n * Math.cos(g - 0.5), b.y - n * Math.sin(g - 0.5));
    o.lineTo(b.x - n * Math.cos(g + 0.5), b.y - n * Math.sin(g + 0.5));
    o.closePath();
    o.fill();
  };
  const dot = (o, p, r, col, t) => {
    o.fillStyle = col;
    o.beginPath();
    o.arc(p.x, p.y, r, 0, 7);
    o.fill();
    if (t) {
      o.fillStyle = "#fff";
      o.font = `bold ${Math.round(r * 1.15)}px Segoe UI`;
      o.textAlign = "center";
      o.textBaseline = "middle";
      o.fillText(t, p.x, p.y + 0.5);
    }
  };
  let lastSug = "";
  const setSug = (a) => {
    const h = a.map((t) => "<li>" + t + "</li>").join("");
    if (h !== lastSug) {
      $("smSug").innerHTML = h;
      lastSug = h;
    }
  };
  A.ext.smartOn = () => $("smartOn").checked;
  A.ext.assist = analyze;
  A.ext.onAssist = (o) => {
    if (!$("smartOn").checked) return;
    if (!$("lineAssistant").checked || S.playing) {
      $("smStatus").textContent = "Guía desactivada";
      setSug([]);
      return;
    }
    const an = analyze();
    if (!an) {
      $("nextStrokeLabel").textContent = "Sin guía";
      $("guideBar").style.width = "0";
      $("smStatus").textContent = "Sin fotograma de referencia";
      setSug([]);
      return;
    }
    const ga = (+$("guideOpacity").value || 35) / 100,
      { R, n, mn, done, pend, ti, pred, link } = an,
      ok = okf();
    o.save();
    an.rf.forEach((r) => {
      const main = r === mn;
      (main ? R : S.frames[r.fr].strokes.filter(ok).map(D)).forEach((d, i) => {
        const dn = main && done[i];
        o.globalAlpha = dn ? ga * 0.35 : ga;
        o.strokeStyle = r.col;
        o.lineWidth = 2;
        o.setLineDash([9, 6]);
        poly(o, d.q);
        if (main && !dn) {
          o.setLineDash([]);
          o.globalAlpha = Math.min(1, ga + 0.25);
          dot(o, d.q[0], 7, r.col, i + 1);
        }
      });
    });
    if (n) {
      if ($("smMiss").checked && done.some(Boolean))
        pend.forEach((i) => {
          if (i === ti) return;
          o.globalAlpha = 0.9;
          o.strokeStyle = "#e0344b";
          o.lineWidth = 2.5;
          o.setLineDash([3, 4]);
          poly(o, R[i].q);
          o.setLineDash([]);
          dot(o, R[i].q[0], 9, "#e0344b", "!");
        });
      const T = R[ti],
        tq = S.rev ? [...T.q].reverse() : T.q,
        moved = Math.hypot(pred.x, pred.y) > 2;
      o.globalAlpha = 1;
      o.setLineDash([]);
      o.strokeStyle = o.fillStyle = CFG.tgt;
      o.lineWidth = 4;
      poly(o, tq);
      [0.25, 0.5, 0.75].forEach((f) => {
        const k = Math.max(1, Math.round((tq.length - 1) * f));
        if (tq.length > 1) tri(o, tq[k - 1], tq[k], 14);
      });
      dot(o, tq[0], 11, "#2fa66a", "▶");
      dot(o, tq[tq.length - 1], 9, "#e0344b", "■");
      o.font = "bold 11px Segoe UI";
      o.textAlign = "left";
      o.fillStyle = "#2fa66a";
      o.fillText("INICIO", tq[0].x + 14, tq[0].y - 10);
      o.fillStyle = "#e0344b";
      o.fillText("FIN", tq[tq.length - 1].x + 12, tq[tq.length - 1].y - 8);
      if ($("smPred").checked && moved) {
        const g = tq.map((p) => ({ x: p.x + pred.x, y: p.y + pred.y }));
        o.strokeStyle = o.fillStyle = CFG.tgt;
        o.globalAlpha = 0.9;
        o.lineWidth = 2.5;
        o.setLineDash([2, 5]);
        poly(o, g);
        o.setLineDash([]);
        o.lineWidth = 1.5;
        o.beginPath();
        o.moveTo(tq[0].x, tq[0].y);
        o.lineTo(g[0].x, g[0].y);
        o.stroke();
        tri(o, tq[0], g[0], 10);
        o.beginPath();
        o.arc(g[0].x, g[0].y, 13, 0, 7);
        o.stroke();
      }
      [
        ["start", link.start],
        ["end", link.end],
      ].forEach(([k, l]) => {
        if (!l) return;
        o.globalAlpha = 1;
        o.strokeStyle = o.fillStyle = "#f2c200";
        o.lineWidth = 2;
        o.setLineDash([4, 3]);
        o.beginPath();
        o.moveTo(l.x, l.y);
        o.lineTo(l.tx, l.ty);
        o.stroke();
        o.setLineDash([]);
        o.beginPath();
        o.arc(l.x, l.y, 9, 0, 7);
        o.stroke();
        o.font = "bold 11px Segoe UI";
        o.textAlign = "left";
        o.fillText(k === "start" ? "empalma aquí" : "cierra aquí", l.x + 12, l.y + 14);
      });
      if ($("smProp").checked) {
        const bR = bb(R);
        o.globalAlpha = 0.6;
        o.lineWidth = 1;
        o.strokeStyle = "#888";
        o.setLineDash([2, 4]);
        o.strokeRect(bR.x0 + pred.x, bR.y0 + pred.y, bR.x1 - bR.x0, bR.y1 - bR.y0);
        const bC = bb(an.cur);
        if (bC) {
          o.setLineDash([]);
          o.strokeStyle = "#aaa";
          o.strokeRect(bC.x0, bC.y0, bC.x1 - bC.x0, bC.y1 - bC.y0);
        }
        o.setLineDash([]);
      }
      o.globalAlpha = 1;
      an.jerk.forEach((j) => dot(o, an.cur[an.mp.get(j.i)].q[0], 10, "#d98200", "!"));
    }
    o.restore();
    $("nextStrokeLabel").textContent = n ? `Trazo ${ti + 1} de ${n}` : "Sin guía";
    $("guideBar").style.width = n ? Math.round((100 * (n - pend.length)) / n) + "%" : "0";
    $("smStatus").textContent = n
      ? `Objetivo: trazo ${ti + 1}/${n} · hechos ${n - pend.length} · faltan ${pend.length}`
      : "—";
    setSug(an.sug.concat(n ? ["Predicción: " + pred.src + "."] : []));
  };
})();
