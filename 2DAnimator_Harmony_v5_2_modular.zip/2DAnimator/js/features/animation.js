/* 2D Animator — módulo de animación (Fase 3). Script clásico: funciona abriendo index.html sin servidor. Depende de window.A2D (app.js). */
(() => {
  "use strict";
  const A = window.A2D;
  if (!A) return;
  const {
      S,
      F,
      uid,
      clone,
      num,
      hint,
      pts,
      resample,
      closedPoly,
      pushUndo,
      dirty,
      all,
      render,
      go,
      msel,
      EASE,
    } = A,
    $ = (id) => document.getElementById(id);
  const esc = (s) =>
    String(s).replace(
      /[&<>"']/g,
      (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c]
    );

  /* ---------- 1. Curvas Bézier + Graph Editor (global y por propiedad de pista) ---------- */
  const bz = (t, a, b) => 3 * (1 - t) * (1 - t) * t * a + 3 * (1 - t) * t * t * b + t * t * t;
  EASE.bez = (x) => A.bezE(S.curve, x);
  ["easing", "tweenEase"].forEach((id) => {
    const o = document.createElement("option");
    o.value = "bez";
    o.textContent = "Curva Bézier (Graph Editor)";
    $(id).append(o);
  });
  const gd = document.createElement("details");
  gd.open = true;
  gd.innerHTML =
    '<summary>Graph Editor · curvas de aceleración</summary><div class="pb"><select id="geTgt"><option value="g">Global (intermedios y barra)</option><option value="x">Pista · X</option><option value="y">Pista · Y</option><option value="r">Pista · Rotación</option><option value="s">Pista · Escala</option><option value="o">Pista · Opacidad</option></select><canvas id="geCv" width="220" height="220"></canvas><div class="row2" id="gePre"></div><p class="muted" id="geInfo"></p></div>';
  $("hintBox").before(gd);
  const PRE = {
    Lineal: [0, 0, 1, 1],
    Entrada: [0.42, 0, 1, 1],
    Salida: [0, 0, 0.58, 1],
    "Entrada-salida": [0.42, 0, 0.58, 1],
    Rebote: [0.34, 1.56, 0.64, 1],
  };
  const kAt = () => (A.L().tr || []).find((k) => k.f === S.f),
    isG = () => $("geTgt").value === "g";
  const tg = () => {
    if (isG()) return S.curve;
    if ($("geTgt").value === "bone") return A.ext.boneCurve ? A.ext.boneCurve() : null;
    const k = kAt();
    return k ? (k.c && k.c[$("geTgt").value]) || [0, 0, 1, 1] : null;
  };
  const setTg = (a) => {
    if (isG()) S.curve = a;
    else if ($("geTgt").value === "bone") {
      A.ext.boneCurve && A.ext.boneCurve(a);
    } else {
      const k = kAt();
      if (k) {
        k.c = k.c || {};
        k.c[$("geTgt").value] = a;
      }
    }
  };
  Object.entries(PRE).forEach(([n, v]) => {
    const b = document.createElement("button");
    b.textContent = n;
    b.onclick = () => {
      if (!tg()) return hint("Sitúate en un fotograma con clave en la capa activa.");
      if (!isG()) pushUndo();
      setTg([...v]);
      dirty();
      ge();
      render();
    };
    $("gePre").append(b);
  });
  const X = (u) => 20 + u * 180,
    Y = (v) => 150 - v * 100;
  function ge() {
    const c = $("geCv"),
      x = c.getContext("2d"),
      cu = tg();
    x.clearRect(0, 0, 220, 220);
    if (!cu) {
      $("geInfo").textContent =
        "Sitúate en un fotograma con clave de la capa activa para editar la curva de esa propiedad (el tramo que parte de esa clave).";
      return;
    }
    const [a, b, c2, d] = cu;
    x.strokeStyle = "#8886";
    x.lineWidth = 1;
    x.strokeRect(X(0), Y(1), 180, 100);
    x.setLineDash([3, 3]);
    x.beginPath();
    x.moveTo(X(0), Y(0));
    x.lineTo(X(a), Y(b));
    x.moveTo(X(1), Y(1));
    x.lineTo(X(c2), Y(d));
    x.stroke();
    x.setLineDash([]);
    x.strokeStyle = "#f5a623";
    x.lineWidth = 2.5;
    x.beginPath();
    for (let i = 0; i <= 40; i++) {
      const t = i / 40;
      i ? x.lineTo(X(bz(t, a, c2)), Y(bz(t, b, d))) : x.moveTo(X(0), Y(0));
    }
    x.stroke();
    x.fillStyle = "#fff";
    x.strokeStyle = "#168bc2";
    [
      [a, b],
      [c2, d],
    ].forEach(([u, v]) => {
      x.beginPath();
      x.arc(X(u), Y(v), 6, 0, 7);
      x.fill();
      x.stroke();
    });
    const n = Math.max(1, Math.round(num($("betweenCount").value, 1, 1, 12)));
    if (isG()) {
      x.fillStyle = "#4fc3a1";
      for (let k = 1; k <= n; k++) {
        const u = k / (n + 1);
        x.beginPath();
        x.arc(X(u), Y(EASE.bez(u)), 3, 0, 7);
        x.fill();
      }
    }
    $("geInfo").textContent =
      `Curva [${cu.map((v) => v.toFixed(2)).join(", ")}]. ` +
      (isG()
        ? `Puntos verdes: reparto de ${n} intermedio(s). Se usa al elegir «Curva Bézier» en la aceleración.`
        : "Controla el tramo desde esta clave hasta la siguiente.");
  }
  let gk = -1;
  const gp = (e) => {
    const r = $("geCv").getBoundingClientRect();
    return [((e.clientX - r.left) * 220) / r.width, ((e.clientY - r.top) * 220) / r.height];
  };
  $("geCv").addEventListener("pointerdown", (e) => {
    const cu = tg();
    if (!cu) return;
    const [px, py] = gp(e),
      h = [0, 2].map((i) => Math.hypot(X(cu[i]) - px, Y(cu[i + 1]) - py));
    gk = h[0] < 14 && h[0] <= h[1] ? 0 : h[1] < 14 ? 1 : -1;
    if (gk >= 0) {
      if (!isG()) pushUndo();
      $("geCv").setPointerCapture(e.pointerId);
    }
  });
  $("geCv").addEventListener("pointermove", (e) => {
    if (gk < 0) return;
    const cu = [...tg()],
      [px, py] = gp(e);
    cu[gk * 2] = Math.max(0, Math.min(1, (px - 20) / 180));
    cu[gk * 2 + 1] = Math.max(-0.5, Math.min(1.5, (150 - py) / 100));
    setTg(cu);
    ge();
    if (!isG()) render();
  });
  $("geCv").addEventListener("pointerup", () => {
    if (gk >= 0) dirty();
    gk = -1;
  });
  $("geTgt").addEventListener("change", ge);
  $("betweenCount").addEventListener("input", ge);

  /* ---------- 2. Correspondencia geométrica entre dibujos ---------- */
  const kd = (s) => (s.kind === "bezier" ? "path" : s.kind);
  function desc(s) {
    const q = pts(s);
    let L = 0,
      x0 = 1e9,
      y0 = 1e9,
      x1 = -1e9,
      y1 = -1e9,
      cx = 0,
      cy = 0;
    q.forEach((p, i) => {
      if (i) L += Math.hypot(p.x - q[i - 1].x, p.y - q[i - 1].y);
      x0 = Math.min(x0, p.x);
      y0 = Math.min(y0, p.y);
      x1 = Math.max(x1, p.x);
      y1 = Math.max(y1, p.y);
      cx += p.x;
      cy += p.y;
    });
    return { cx: cx / q.length, cy: cy / q.length, L, w: x1 - x0, h: y1 - y0, cl: !!closedPoly(s) };
  }
  const cost = (a, b, u, v) =>
    Math.hypot(u.cx - v.cx, u.cy - v.cy) +
    0.5 * Math.abs(u.L - v.L) +
    0.3 * (Math.abs(u.w - v.w) + Math.abs(u.h - v.h)) +
    (kd(a) !== kd(b) ? 40 : 0) +
    (u.cl !== v.cl ? 40 : 0) +
    (a.layerId !== b.layerId ? 60 : 0) +
    (a.mt && a.mt === b.mt ? -1e6 : 0);
  function plan(Aa, Bb) {
    const da = Aa.map(desc),
      db = Bb.map(desc),
      C = [],
      thr = S.width * 0.45;
    Aa.forEach((a, i) => Bb.forEach((b, j) => C.push([cost(a, b, da[i], db[j]), i, j])));
    C.sort((p, q) => p[0] - q[0]);
    const ua = new Set(),
      ub = new Set(),
      geo = [];
    let cg = 0;
    C.forEach(([c, i, j]) => {
      if (c > thr || ua.has(i) || ub.has(j)) return;
      ua.add(i);
      ub.add(j);
      geo.push([i, j]);
      cg += Math.max(0, c);
    });
    cg += 100 * (Aa.length - ua.size + Bb.length - ub.size);
    const same =
      Aa.length === Bb.length &&
      Aa.every(
        (a, i) =>
          kd(a) === kd(Bb[i]) &&
          a.layerId === Bb[i].layerId &&
          !a.mt &&
          !Bb[i].mt &&
          a.points.length &&
          Bb[i].points.length
      );
    if ($("matchMode").value === "auto" && same) {
      let ci = 0;
      Aa.forEach((a, i) => {
        ci += cost(a, Bb[i], da[i], db[i]);
      });
      if (ci <= cg * 1.25 + 10) return Aa.map((a, i) => [a, Bb[i]]);
    }
    const pr = geo.map(([i, j]) => [i, Aa[i], Bb[j]]);
    Aa.forEach((a, i) => {
      if (!ua.has(i)) pr.push([i, a, null]);
    });
    Bb.forEach((b, j) => {
      if (!ub.has(j)) pr.push([Aa.length + j, null, b]);
    });
    return pr.sort((p, q) => p[0] - q[0]).map((p) => [p[1], p[2]]);
  }
  const dd = (u, v) => Math.hypot(u.x - v.x, u.y - v.y);
  function rigid(pa, pb, t) {
    const n = pa.length,
      cen = (P) => P.reduce((q, p) => [q[0] + p.x / n, q[1] + p.y / n], [0, 0]),
      ca = cen(pa),
      cb = cen(pb);
    let dt = 0,
      cr = 0,
      na = 0,
      nb = 0;
    pa.forEach((p, i) => {
      const ax = p.x - ca[0],
        ay = p.y - ca[1],
        bx = pb[i].x - cb[0],
        by = pb[i].y - cb[1];
      dt += ax * bx + ay * by;
      cr += ax * by - ay * bx;
      na += ax * ax + ay * ay;
      nb += bx * bx + by * by;
    });
    const th = Math.atan2(cr, dt),
      sc = na > 1e-6 ? Math.sqrt(nb / na) : 1,
      R = (k, ax, ay) => {
        const g = th * k,
          z = Math.pow(sc, k),
          co = Math.cos(g) * z,
          si = Math.sin(g) * z;
        return [ax * co - ay * si, ax * si + ay * co];
      };
    return pa.map((p, i) => {
      const ax = p.x - ca[0],
        ay = p.y - ca[1],
        r = R(t, ax, ay),
        e = R(1, ax, ay);
      return {
        x: ca[0] + (cb[0] - ca[0]) * t + r[0] + t * (pb[i].x - cb[0] - e[0]),
        y: ca[1] + (cb[1] - ca[1]) * t + r[1] + t * (pb[i].y - cb[1] - e[1]),
      };
    });
  }
  function mix(a, b, t) {
    const ka = kd(a),
      L = (p, q) => p + (q - p) * t,
      base = {
        ...clone(a),
        closed: false,
        color: t < 0.5 ? a.color : b.color,
        size: L(a.size, b.size),
        opacity: L(a.opacity, b.opacity),
      };
    if (ka === kd(b) && (ka === "rect" || ka === "ellipse" || ka === "line")) {
      const pa = [a.points[0], a.points.at(-1)];
      let pb = [b.points[0], b.points.at(-1)];
      if (ka === "line" && dd(pa[0], pb[0]) + dd(pa[1], pb[1]) > dd(pa[0], pb[1]) + dd(pa[1], pb[0]))
        pb = [pb[1], pb[0]];
      const R = ka === "line" && $("rigid").checked ? rigid(pa, pb, t) : null;
      return {
        ...base,
        kind: ka,
        points: pa.map((p, j) => ({
          x: R ? R[j].x : L(p.x, pb[j].x),
          y: R ? R[j].y : L(p.y, pb[j].y),
          w: 1,
        })),
      };
    }
    const pa = resample(pts(a), 80),
      B0 = resample(pts(b), 80),
      cands = [B0, [...B0].reverse()],
      sc = (Q) => Q.reduce((m, q, i) => m + dd(q, pa[i]), 0);
    let pb;
    if (closedPoly(a) && closedPoly(b)) {
      const all = [];
      cands.forEach((Q) => {
        for (let k = 0; k < 80; k += 4) all.push(Q.map((_, i) => Q[(i + k) % 80]));
      });
      pb = all.reduce((m, Q) => (sc(Q) < sc(m) ? Q : m), all[0]);
    } else
      pb =
        dd(pa[0], cands[0][0]) + dd(pa[79], cands[0][79]) <= dd(pa[0], cands[1][0]) + dd(pa[79], cands[1][79])
          ? cands[0]
          : cands[1];
    return {
      ...base,
      kind: ka === "fill" && kd(b) === "fill" ? "fill" : "path",
      brush: a.brush || b.brush,
      points: ((R) =>
        pa.map((p, j) => ({
          x: R ? R[j].x : L(p.x, pb[j].x),
          y: R ? R[j].y : L(p.y, pb[j].y),
          w: L(p.w ?? 1, pb[j].w ?? 1),
        })))($("rigid").checked ? rigid(pa, pb, t) : null),
    };
  }
  A.ext.interp = (Aa, Bb, t) =>
    plan(Aa, Bb)
      .map(([a, b]) =>
        a && b
          ? mix(a, b, t)
          : a
            ? { ...clone(a), opacity: a.opacity * (1 - t) }
            : { ...clone(b), opacity: b.opacity * t }
      )
      .filter((s) => s.opacity > 0.005);
  $("generateBetweenBtn").parentNode.insertAdjacentHTML(
    "beforeend",
    '<label>Correspondencia de trazos</label><select id="matchMode"><option value="auto">Automática (por orden si encaja; si no, geométrica)</option><option value="geo">Siempre geométrica</option></select><div class="row2"><label>Etiqueta <input id="mtNum" type="number" min="1" max="99" value="1"></label><button id="mtSet" title="Asigna la etiqueta a los trazos seleccionados">Etiquetar sel.</button></div><label class="ck"><input type="checkbox" id="rigid" checked> Interpolación rígida (los giros no encogen el trazo)</label><button id="mtClr">Quitar etiquetas (sel.)</button><p class="muted">Dos trazos con la misma etiqueta en fotogramas distintos se emparejan primero (corrección manual). Los trazos sin pareja aparecen o desaparecen con fundido.</p>'
  );
  $("mtSet").onclick = () => {
    const m = msel();
    if (!m.length) return hint("Selecciona trazos para etiquetarlos.");
    pushUndo();
    const n = Math.round(num($("mtNum").value, 1, 1, 99));
    m.forEach((s) => {
      s.mt = n;
    });
    dirty();
    render();
    hint(m.length + " trazo(s) con etiqueta " + n + ".");
  };
  $("mtClr").onclick = () => {
    const m = msel();
    if (!m.length) return hint("Selecciona trazos.");
    pushUndo();
    m.forEach((s) => {
      delete s.mt;
    });
    dirty();
    render();
  };

  /* ---------- 3. Exposición, marcadores y X-Sheet ---------- */
  $("moveFR").parentNode.insertAdjacentHTML(
    "beforeend",
    '<label class="ck" title="Cuántos pasos de tiempo dura este dibujo">Expos. <input type="number" id="expInput" min="1" max="99" value="1"></label><button id="mkBtn" title="Marcador de evento en este fotograma">⚑</button><button id="xsBtn" title="Hoja de exposición">X-Sheet</button>'
  );
  $("expInput").addEventListener("change", (e) => {
    pushUndo();
    F().exp = Math.round(num(e.target.value, 1, 1, 99));
    dirty();
    all();
  });
  $("mkBtn").onclick = () => {
    const v = prompt("Marcador de evento (vacío = quitar)", F().mk || "");
    if (v === null) return;
    pushUndo();
    F().mk = v.trim().slice(0, 40) || undefined;
    dirty();
    all();
  };
  const xs = document.createElement("div");
  xs.id = "xsheet";
  xs.hidden = true;
  xs.innerHTML =
    '<div class="xsb"><div class="xsh"><b>Hoja de exposición (X-Sheet)</b><span class="sp"></span><button id="xsX">✕</button></div><div class="xst" id="xsT"></div><div class="xsf">Rango <input id="xsA" type="number" min="1" value="1"> a <input id="xsB" type="number" min="1" value="1"> <button id="xsCp">Copiar</button><button id="xsPs">Pegar tras el actual</button> · Repetir ×<input id="xsN" type="number" min="1" max="50" value="2"><label class="ck"><input type="checkbox" id="xsPP"> Ida y vuelta</label><button id="xsRp" class="primary">Repetir rango</button></div></div>';
  document.body.append(xs);
  function xsDraw() {
    let t = 0,
      h =
        "<table><tr><th>Nº</th><th>Inicio</th><th>Trazos</th><th>Tipo</th><th>Expos.</th><th>Marcador</th></tr>";
    S.frames.forEach((f, i) => {
      const e = f.exp || 1,
        ib = f.strokes.length && f.strokes.every((s) => s.inb);
      h += `<tr data-i="${i}" class="${i === S.f ? "cur" : ""}"><td>${i + 1}</td><td>${(t / S.fps).toFixed(2)} s</td><td>${f.strokes.length}</td><td>${f.strokes.length ? (ib ? "interm." : "clave") : "vacío"}</td><td><input data-e="${i}" type="number" min="1" max="99" value="${e}"></td><td><input data-m="${i}" value="${esc(f.mk || "")}" maxlength="40"></td></tr>`;
      t += e;
    });
    $("xsT").innerHTML = h + "</table>";
  }
  $("xsBtn").onclick = () => {
    xs.hidden = false;
    $("xsA").value = $("xsB").value = S.f + 1;
    xsDraw();
  };
  $("xsX").onclick = () => {
    xs.hidden = true;
  };
  $("xsT").addEventListener("click", (e) => {
    const tr = e.target.closest("tr[data-i]");
    if (tr && e.target.tagName !== "INPUT") go(+tr.dataset.i);
  });
  $("xsT").addEventListener("change", (e) => {
    const d = e.target.dataset,
      i = +(d.e ?? d.m);
    if (!(i >= 0)) return;
    pushUndo();
    if (d.e !== undefined) S.frames[i].exp = Math.round(num(e.target.value, 1, 1, 99));
    else S.frames[i].mk = e.target.value.trim().slice(0, 40) || undefined;
    dirty();
    all();
  });
  A.ext.onTl = () => {
    $("expInput").value = F().exp || 1;
    if (!xs.hidden) xsDraw();
  };
  A.ext.onLoad = ge;

  /* ---------- 4. Copiar, pegar y repetir secuencias (ciclos) ---------- */
  const rg = () => {
    const a = Math.round(num($("xsA").value, 1, 1, S.frames.length)) - 1,
      b = Math.round(num($("xsB").value, 1, 1, S.frames.length)) - 1;
    return a > b ? [b, a] : [a, b];
  };
  const cf = (f) => ({ id: uid(), strokes: clone(f.strokes), exp: f.exp || 1 });
  $("xsCp").onclick = () => {
    const [a, b] = rg();
    A.clip = S.frames.slice(a, b + 1).map(cf);
    hint(A.clip.length + " fotograma(s) copiado(s).");
  };
  $("xsPs").onclick = () => {
    if (!A.clip || !A.clip.length) return hint("Copia primero un rango.");
    if (S.frames.length + A.clip.length > 5000) return hint("Se superaría el máximo de 5000 fotogramas.");
    pushUndo();
    S.frames.splice(S.f + 1, 0, ...A.clip.map(cf));
    S.f++;
    dirty();
    all();
  };
  $("xsRp").onclick = () => {
    const [a, b] = rg(),
      n = Math.round(num($("xsN").value, 2, 1, 50)),
      pp = $("xsPP").checked,
      seg = S.frames.slice(a, b + 1),
      add = [];
    for (let i = 0; i < n; i++) {
      let q = pp && i % 2 === 0 ? [...seg].reverse() : seg;
      if (pp) q = q.slice(1);
      add.push(...q.map(cf));
    }
    if (!add.length) return hint("El rango es demasiado corto para ida y vuelta.");
    if (S.frames.length + add.length > 5000) return hint("Se superaría el máximo de 5000 fotogramas.");
    pushUndo();
    S.frames.splice(b + 1, 0, ...add);
    dirty();
    all();
    hint(add.length + " fotograma(s) añadido(s).");
  };
  /* ---------- 5. Pistas de transformación por capa ---------- */
  const tp = document.createElement("details");
  tp.open = true;
  tp.innerHTML =
    '<summary>Transformación de capa (pistas)</summary><div class="pb"><p class="muted" id="trLayer"></p><div class="row2"><label>X <input id="trX" type="number"></label><label>Y <input id="trY" type="number"></label></div><div class="row2"><label>Rot ° <input id="trR" type="number"></label><label>Esc % <input id="trS" type="number"></label></div><label>Opacidad % <input id="trO" type="number" min="0" max="100"></label><div class="row2"><button id="trKey">◆ Clave aquí</button><button id="trDel">✕ Quitar clave</button></div><div class="row2"><button id="trPv" title="Pivote en el centro de la selección (o del lienzo si no hay)">Pivote aquí</button><button id="trClr">Borrar pista</button></div><label class="ck"><input type="checkbox" id="trFinal"> Vista final (con transformaciones)</label><label class="ck"><input type="checkbox" id="trPath" checked> Mostrar trayectoria</label><p class="muted" id="trKeys"></p></div>';
  $("hintBox").before(tp);
  const PR = ["x", "y", "r", "s", "o"],
    IN = { x: "trX", y: "trY", r: "trR", s: "trS", o: "trO" };
  function ensure(l, f) {
    let k = (l.tr || []).find((k) => k.f === f);
    if (!k) {
      const v = A.trAt(l, f);
      k = { f, x: v.x, y: v.y, r: v.r, s: v.s, o: v.o };
      (l.tr = l.tr || []).push(k);
      l.tr.sort((a, b) => a.f - b.f);
    }
    return k;
  }
  function trUI() {
    const l = A.L(),
      v = A.trAt(l, S.f),
      k = (l.tr || []).find((k) => k.f === S.f);
    PR.forEach((q) => {
      if (document.activeElement !== $(IN[q])) $(IN[q]).value = Math.round(v[q] * 100) / 100;
    });
    $("trLayer").textContent =
      "Capa: " + l.name + (k ? " · clave en este fotograma" : " · sin clave aquí (valor interpolado)");
    $("trKeys").textContent =
      "Claves: " +
      ((l.tr || []).map((k) => k.f + 1).join(", ") || "ninguna") +
      ". Se aplican en «Vista final», al reproducir y al exportar.";
  }
  PR.forEach((q) =>
    $(IN[q]).addEventListener("change", (e) => {
      const l = A.L();
      if (l.locked) return hint("Capa bloqueada.");
      pushUndo();
      const k = ensure(l, S.f);
      k[q] = num(
        e.target.value,
        k[q],
        q === "s" ? 1 : q === "o" ? 0 : -1e5,
        q === "s" ? 1e4 : q === "o" ? 100 : q === "r" ? 3600 : 1e5
      );
      dirty();
      render();
      trUI();
    })
  );
  $("trKey").onclick = () => {
    pushUndo();
    ensure(A.L(), S.f);
    dirty();
    all();
  };
  $("trDel").onclick = () => {
    const l = A.L();
    if (!(l.tr || []).some((k) => k.f === S.f)) return hint("No hay clave en este fotograma.");
    pushUndo();
    l.tr = l.tr.filter((k) => k.f !== S.f);
    if (!l.tr.length) delete l.tr;
    dirty();
    all();
  };
  $("trClr").onclick = () => {
    const l = A.L();
    if (!l.tr) return;
    pushUndo();
    delete l.tr;
    dirty();
    all();
  };
  $("trPv").onclick = () => {
    const l = A.L(),
      m = msel();
    pushUndo();
    if (m.length) {
      let x = 0,
        y = 0,
        n = 0;
      m.forEach((s) =>
        pts(s).forEach((q) => {
          x += q.x;
          y += q.y;
          n++;
        })
      );
      l.pv = [x / n, y / n];
    } else delete l.pv;
    dirty();
    render();
    hint("Pivote de la capa «" + l.name + "» actualizado.");
  };
  $("trFinal").onchange = (e) => {
    S.final = e.target.checked;
    render();
  };
  $("trPath").onchange = (e) => {
    S.path = e.target.checked;
    render();
  };
  let xd = null;
  const cvE = $("artCanvas");
  cvE.addEventListener(
    "pointerdown",
    (e) => {
      if (S.tool !== "xform" || e.button !== 0 || S.space) return;
      e.stopImmediatePropagation();
      if (S.playing) return;
      const l = A.L();
      if (l.locked || !l.visible) return hint("La capa activa está bloqueada u oculta.");
      const p = A.pt(e);
      pushUndo();
      const k = ensure(l, S.f);
      xd = { p, k, k0: { ...k }, pv: A.pivotOf(l), mode: e.shiftKey ? "r" : e.altKey ? "s" : "m" };
      cvE.setPointerCapture(e.pointerId);
    },
    true
  );
  cvE.addEventListener(
    "pointermove",
    (e) => {
      if (!xd) return;
      e.stopImmediatePropagation();
      const p = A.pt(e),
        { k, k0, pv } = xd,
        cx = pv[0] + k0.x,
        cy = pv[1] + k0.y;
      if (xd.mode === "m") {
        k.x = k0.x + p.x - xd.p.x;
        k.y = k0.y + p.y - xd.p.y;
      } else if (xd.mode === "r")
        k.r =
          k0.r + ((Math.atan2(p.y - cy, p.x - cx) - Math.atan2(xd.p.y - cy, xd.p.x - cx)) * 180) / Math.PI;
      else {
        const d0 = Math.hypot(xd.p.x - cx, xd.p.y - cy);
        if (d0 > 4) k.s = Math.max(1, (k0.s * Math.hypot(p.x - cx, p.y - cy)) / d0);
      }
      render();
      trUI();
    },
    true
  );
  const xend = (e) => {
    if (!xd) return;
    e.stopImmediatePropagation();
    xd = null;
    dirty();
    all();
  };
  cvE.addEventListener("pointerup", xend, true);
  cvE.addEventListener("pointercancel", xend, true);
  A.ext.onOverlay = (o) => {
    const l = A.L();
    if (!S.path || !l.tr || !l.tr.length) return;
    const pv = A.pivotOf(l),
      K = l.tr,
      z = 1 / S.zoom;
    o.save();
    o.lineWidth = 1.5 * z;
    o.strokeStyle = "#3d9be9";
    o.setLineDash([5 * z, 4 * z]);
    o.beginPath();
    for (let f = K[0].f; f <= K[K.length - 1].f; f++) {
      const v = A.trAt(l, f);
      f === K[0].f ? o.moveTo(pv[0] + v.x, pv[1] + v.y) : o.lineTo(pv[0] + v.x, pv[1] + v.y);
    }
    o.stroke();
    o.setLineDash([]);
    K.forEach((k) => {
      const x = pv[0] + k.x,
        y = pv[1] + k.y;
      o.fillStyle = k.f === S.f ? "#f5a623" : "#fff";
      o.beginPath();
      o.moveTo(x, y - 6 * z);
      o.lineTo(x + 6 * z, y);
      o.lineTo(x, y + 6 * z);
      o.lineTo(x - 6 * z, y);
      o.closePath();
      o.fill();
      o.stroke();
      o.fillStyle = "#3d9be9";
      o.font = 11 * z + "px Segoe UI";
      o.fillText(k.f + 1, x + 8 * z, y - 8 * z);
    });
    const v = A.trAt(l, S.f);
    o.strokeStyle = "#f5a623";
    o.beginPath();
    o.arc(pv[0] + v.x, pv[1] + v.y, 9 * z, 0, 7);
    o.stroke();
    o.restore();
  };
  const oTl = A.ext.onTl,
    oLd = A.ext.onLoad;
  A.ext.onTl = () => {
    oTl();
    trUI();
    if (!isG()) ge();
  };
  A.ext.onLoad = () => {
    oLd();
    trUI();
  };
  ge();
  trUI();
})();
