/**
 * Intermedios (tweening): emparejado de trazos, interpolación y generación de fotogramas.
 */
"use strict";
const EASE = {
  linear: (t) => t,
  in: (t) => t * t,
  out: (t) => 1 - (1 - t) ** 2,
  inout: (t) => (t < 0.5 ? 2 * t * t : 1 - (-2 * t + 2) ** 2 / 2),
};
const kd = (s) => (s.kind === "bezier" ? "path" : s.kind);
const ends = (s) =>
  kd(s) === "path" || s.kind === "fill" ? resample(pts(s), 80) : [s.points[0], s.points.at(-1)];
function interp(A, B, t) {
  if (window.A2D && A2D.ext.interp) return A2D.ext.interp(A, B, t);
  if (A.length !== B.length) return null;
  const o = [];
  for (let i = 0; i < A.length; i++) {
    const a = A[i],
      b = B[i];
    if (kd(a) !== kd(b) || !a.points.length || !b.points.length) return null;
    const pa = ends(a),
      pb = ends(b);
    o.push({
      ...clone(a),
      kind: kd(a),
      closed: false,
      color: t < 0.5 ? a.color : b.color,
      size: a.size + (b.size - a.size) * t,
      opacity: a.opacity + (b.opacity - a.opacity) * t,
      points: pa.map((p, j) => ({
        x: p.x + (pb[j].x - p.x) * t,
        y: p.y + (pb[j].y - p.y) * t,
        w: (p.w ?? 1) + ((pb[j].w ?? 1) - (p.w ?? 1)) * t,
      })),
    });
  }
  return o;
}
$("generateBetweenBtn").onclick = () => {
  let a = +$("fromFrame").value,
    b = +$("toFrame").value;
  if (a === b) return hint("Selecciona dos fotogramas distintos.");
  if (a > b) [a, b] = [b, a];
  const n = Math.max(1, Math.min(12, +$("betweenCount").value || 1)),
    fn = EASE[$("easing").value],
    out = [];
  for (let k = 1; k <= n; k++) {
    const g = interp(S.frames[a].strokes, S.frames[b].strokes, fn(k / (n + 1)));
    if (!g)
      return hint(
        "No se pudo emparejar: ambos fotogramas necesitan el mismo número y tipo de trazos, en el mismo orden."
      );
    g.forEach((s) => (s.inb = true));
    out.push({ id: uid(), strokes: g });
  }
  pushUndo();
  S.frames.splice(a + 1, 0, ...out);
  S.f = a + 1;
  dirty();
  all();
  hint(n + " intermedio(s) generado(s).");
};
