/**
 * Asistente IA opcional / modo local (desplazamiento de geometría).
 */
"use strict";
$("generateAiBtn").onclick = async () => {
  const prompt = $("aiPrompt").value.trim(),
    ep = $("aiEndpoint").value.trim(),
    dx = +$("moveX").value || 0,
    dy = +$("moveY").value || 0,
    st = $("aiStatus");
  if (!prompt && !ep) return alert("Escribe una descripción o configura un servidor IA.");
  $("generateAiBtn").disabled = true;
  st.textContent = "Preparando fotograma...";
  try {
    let strokes;
    if (ep) {
      const r = await fetch(ep, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          task: "generate_animation_frame",
          prompt,
          project: proj(),
          referenceFrameIndex: S.f,
          targetFrameIndex: S.f + 1,
          movement: { dx, dy },
          responseFormat: "{ strokes: [...] }",
        }),
      });
      if (!r.ok) throw Error("El servidor respondió " + r.status);
      const d = await r.json();
      strokes = d.strokes || d.frame?.strokes;
      if (!Array.isArray(strokes)) throw Error("La respuesta debe contener un arreglo strokes.");
      st.textContent = "Fotograma recibido del servicio IA.";
    } else {
      if (!F().strokes.length) throw Error("Dibuja primero un fotograma de referencia.");
      strokes = clone(F().strokes).map((s) => ({
        ...s,
        points: s.points.map((p) => ({ x: p.x + dx, y: p.y + dy })),
      }));
      st.textContent = "Sugerencia local por desplazamiento geométrico. No es IA generativa.";
    }
    strokes = clean(strokes).map((s) => ({
      ...s,
      points: s.points.map((p) => ({
        ...p,
        x: Math.max(0, Math.min(S.width, p.x)),
        y: Math.max(0, Math.min(S.height, p.y)),
      })),
    }));
    pushUndo();
    S.frames.splice(S.f + 1, 0, { id: uid(), strokes });
    S.f++;
    dirty();
    all();
  } catch (err) {
    st.textContent = "No se pudo generar: " + err.message;
  } finally {
    $("generateAiBtn").disabled = false;
  }
};
