/**
 * Imagen de referencia bajo el dibujo.
 */
"use strict";
function setRef(src, op, mark) {
  const im = new Image();
  im.onload = () => {
    S.ref = { src, img: im, op: op ?? 0.4 };
    $("refOp").value = Math.round(S.ref.op * 100);
    $("refOpV").textContent = $("refOp").value + "%";
    if (mark) dirty();
    render();
  };
  im.onerror = () => hint("No se pudo leer la imagen de referencia.");
  im.src = src;
}
$("refInput").onchange = (e) => {
  const f = e.target.files[0];
  e.target.value = "";
  if (!f) return;
  if (!/^image\/(png|jpe?g|webp|gif)$/.test(f.type))
    return hint("Formato no admitido: usa PNG, JPG, WebP o GIF.");
  const u = URL.createObjectURL(f),
    im = new Image();
  im.onerror = () => {
    URL.revokeObjectURL(u);
    hint("No se pudo leer la imagen.");
  };
  im.onload = () => {
    const k = Math.min(1, 1400 / Math.max(im.width, im.height)),
      c = document.createElement("canvas");
    c.width = Math.max(1, Math.round(im.width * k));
    c.height = Math.max(1, Math.round(im.height * k));
    const x = c.getContext("2d");
    x.fillStyle = "#fff";
    x.fillRect(0, 0, c.width, c.height);
    x.drawImage(im, 0, 0, c.width, c.height);
    URL.revokeObjectURL(u);
    const src = c.toDataURL("image/jpeg", 0.82);
    if (src.length > 3e6) return hint("La imagen es demasiado grande para guardarla en el proyecto.");
    setRef(src, 0.4, true);
    hint("Referencia importada (no se exporta). Ajusta su opacidad en Vista.");
  };
  im.src = u;
};
$("refOp").oninput = (e) => {
  $("refOpV").textContent = e.target.value + "%";
  if (S.ref) {
    S.ref.op = e.target.value / 100;
    dirty();
    render();
  }
};
$("refDel").onclick = () => {
  S.ref = null;
  dirty();
  render();
};
