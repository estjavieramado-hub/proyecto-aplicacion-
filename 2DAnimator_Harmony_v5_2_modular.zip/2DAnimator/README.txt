ACTUALIZACIÓN DEL ASISTENTE VECTORIAL
- Emparejamiento global de trazos: compara el conjunto completo y evita depender del orden en que se dibujaron.
- Las etiquetas manuales de correspondencia siguen teniendo prioridad.
- Comparación geométrica mejorada: centro, longitud, proporción, extremos y tipo de trazo.
- Predicción de movimiento mediante mediana para reducir la influencia de trazos atípicos.
- Los trazos sin pareja se dejan como pendientes en vez de forzar una correspondencia dudosa.
- El asistente continúa trabajando en una capa de superposición: no altera los dibujos originales.

2D ANIMATOR — VERSION 4 (interfaz estilo Harmony)
Abre index.html en Chrome o Edge. No requiere servidor.

INTERFAZ
- Barra de menús (Archivo, Edición, Vista, Animación), barra de herramientas vertical,
  panel de propiedades a la derecha y timeline tipo xsheet (capas × fotogramas) abajo.

NOVEDADES
- Selección real: clic en un trazo, arrastrar para moverlo, cambiar color/grosor/opacidad, Supr para borrar.
- Deshacer / Rehacer global (Ctrl+Z, Ctrl+Y): fotogramas y capas.
- Timeline con una fila por capa; ◉ visibilidad, ▣ bloqueo, doble clic para renombrar, subir/bajar capa.
- Zoom con rueda, mano (H o mantener Espacio), ajustar a ventana.
- Onion skin de ±2 fotogramas con degradado.
- Pluma suavizada y estabilizador de trazo.
- Intermedios: varios a la vez y con aceleración (lineal, entrada, salida, entrada y salida).
- Reproducción con bucle y botones de primer/anterior/siguiente/último fotograma.
- Exportación SVG respetando capas y PNG. Las respuestas del servidor IA se validan antes de usarse.

ATAJOS
V selección · P lápiz · B pluma · E borrador · L línea · R rectángulo · O elipse · H mano
Enter reproducir · ← → fotograma · Ctrl+S guardar · Supr borrar selección

LIMITES CONOCIDOS
- No hay curvas Bézier editables ni edición de nodos, ni rotación/escala de selección.
- Los intermedios requieren el mismo número y orden de trazos en ambos fotogramas.
- El modo local no es IA generativa; la IA real requiere tu propio servidor (formato descrito en la versión anterior).


NOVEDADES V3
- Pluma Bézier (B): clic = nodo recto; clic y arrastrar = nodo curvo; cerrar pulsando el primer nodo; Enter o doble clic termina; Esc cancela.
- Editar nodos (A): mueve nodos y tiradores (Shift: tirador independiente; Alt+arrastrar desde un nodo: sacar tiradores), doble clic en el trazo añade un nodo, Supr quita el nodo.
  Convierte automáticamente lápiz, línea, rectángulo y elipse a vector editable. El SVG exporta curvas Bézier reales.
- Papel cebolla: icono sobre el lienzo (Q), con cantidad de fotogramas anteriores (rojo) y siguientes (azul), de 0 a 8.
- Timeline: arrastrar sobre la regla para recorrer, botón ＋ al final, mover fotogramas, zoom de celdas, marca por segundo y tiempo en segundos.
- Asistente de calco: el trazo que sigue se resalta en naranja, barra de progreso, saltar trazos, modo anterior + siguiente.
- Temas: Oscuro, Gris medio, Claro y Medianoche (se recuerda la elección).


NOVEDADES V4
- Pinceles vectoriales: Tinta, Lápiz, Pincel, Marcador, Caligráfico y Técnico. Con tableta usan la presión; con ratón se simula con la velocidad.
  Puntas afinadas, y "Suavidad del trazo" (0-10) que estabiliza en vivo y suaviza al soltar. Se exportan a SVG como formas rellenas.
- Capas estilo anime: cada proyecto empieza con un grupo "Personaje 1" con Línea, Sombra y Color. El grupo se muestra como una sola fila (expandir/contraer,
  ocultar y bloquear en conjunto). "＋ Grupo anime" crea más. Al elegir una capa se aplica su color y opacidad.
- Herramienta Relleno (G): clic dentro de una forma cerrada y se rellena en la capa activa (usa la capa Color).
- Fotogramas clave vs intermedios con colores configurables (Clave / Interm.). K alterna el tipo de la celda activa. Los generados por interpolación son intermedios.
- Timeline libre: haz clic en cualquier columna (incluso lejos del final) y dibuja ahí. Arrastra una celda con dibujo para moverla; Alt+arrastrar la copia.
- Interpolación: clic en un fotograma clave, Shift+clic en otro de la misma capa o grupo, y aparece el botón "Interpolar" (con aceleración).
  Solo se rellenan los fotogramas vacíos entre ambos.

LIMITES
- Para interpolar, ambos extremos deben tener el mismo número y tipo de trazos por capa, en el mismo orden.
- Al editar nodos de un trazo a mano alzada se convierte a Bézier y pierde la variación de grosor.
- El relleno usa formas cerradas (pluma, rectángulo, elipse o trazos cuyo inicio y final se tocan); no hay relleno por pixeles con huecos.


=====================================================================
FASE 1 — NÚCLEO FORTALECIDO (v4.1)
=====================================================================
No se eliminó ni sustituyó ninguna herramienta. Los proyectos de V1–V4 siguen abriéndose.

CORREGIDO
- Guardado: el proyecto se guarda con versión 4. El autoguardado ahora es diferido (0,9 s tras el último cambio, ya no en cada trazo),
  se vuelca al cambiar de pestaña/cerrar, y si falla (almacenamiento lleno) se avisa en la barra superior y se pide confirmación al cerrar.
- Apertura de archivos: validación completa (formato, tamaño máx. 200 MB, máx. 5000 fotogramas, colores, números, puntos NaN, trazos nulos,
  ids duplicados, capas ligadas a grupos inexistentes, FPS y tamaño fuera de rango). Si el archivo es inválido, el proyecto actual NO se toca.
- El lienzo respeta el tamaño del proyecto (antes quedaba fijo en 1280×720).
- Deshacer: presupuesto de memoria (máx. 60 pasos y ~48 MB). Cambiar color/grosor/opacidad de un trazo seleccionado ahora también se deshace.
- Reproducción: temporizador por fotograma de pantalla (sin deriva) y cabezal ligero; ya no reconstruye el timeline en cada fotograma.
- Líneas, rectángulos y elipses con un simple clic ya no dejan trazos vacíos.

PRUEBAS REALIZADAS (jsdom): arranque con proyecto corrupto, tamaño de lienzo, límites de FPS, reparación de capas, dibujo + autoguardado,
deshacer/rehacer, trazos degenerados, reproducción con 121 fotogramas y pausa. Sin errores de ejecución.
NO PROBADO AÚN: render real de píxeles, tabletas con presión y rendimiento en navegador con proyectos grandes (probar en Chrome/Edge).

ESTADO DE FASES
 1 Núcleo ............ HECHA (esta entrega)
 2 Dibujo/selección .. PENDIENTE (lazo, selección múltiple, transformación, máscaras, simetría, pinceles nuevos)
 3 Animación/Graph ... PENDIENTE (X-Sheet, curvas Bézier, correspondencia geométrica en interpolación)
 4 Asistente trazos .. PENDIENTE   5 IA real ... PENDIENTE (hoy el modo local solo desplaza geometría y NO es IA)
 6 Rigging ........... PENDIENTE   7 Cámara/audio/vídeo ... PENDIENTE   8 Optimización final ... PENDIENTE
 La arquitectura modular (ES modules) se aborda al inicio de la Fase 2 para no mezclar refactor y correcciones.


=====================================================================
FASE 2 (parte A) — DIBUJO Y SELECCIÓN (v4.2)
=====================================================================
NUEVO
- Lazo (S): dibuja un lazo y selecciona los trazos que encierra (≥50 % de sus puntos). Shift suma. También: arrastrar en vacío con Selección, Ctrl+A.
- Selección múltiple: Shift+clic añade/quita. Mover, borrar (Supr) y cambiar color/grosor/opacidad actúan sobre todos. Todo con deshacer.
- Transformar selección (panel derecho): rotar ±ángulo, escalar %, espejo H/V, respecto al centro de la selección.
  Rotar convierte rectángulos y elipses a vector editable; los tiradores Bézier se transforman con el trazo.
- Simetría: vertical, horizontal o ambas, con eje visible y vista previa del espejo mientras dibujas (pincel, formas y pluma Bézier).
- Capas de Recorte (⤵) y de Máscara (◐): el botón actúa sobre la capa activa y necesita una capa inferior.
  Recorte = la capa solo se ve donde la capa inferior tiene dibujo. Máscara = lo que dibujes (se muestra en naranja al editar) define la zona visible
  de la capa inferior; la opacidad del trazo da máscaras suaves; sin trazos no oculta nada. Se guardan en el proyecto y se respetan en reproducción y PNG.
- Pincel Acuarela: bordes suaves y transparencia, con presión.

LIMITES CONOCIDOS
- SVG: las máscaras no se exportan y los recortes salen sin recortar (se avisa al exportar). Acuarela sale sin desenfoque. Usa PNG para el resultado exacto.
- Recorte/máscara y Acuarela están probados a nivel de datos y sin errores de ejecución, pero NO verificados en píxeles: revísalos en Chrome/Edge.

PENDIENTE EN FASE 2 (parte B)
- Pinceles de lápiz tradicional con grano y de textura; control de inclinación (tilt); importación de imágenes de referencia;
  deformación libre (perspectiva/malla); simetría radial; reorganización del JS en varios archivos (scripts clásicos, no módulos ES, para seguir
  funcionando abriendo index.html sin servidor).


=====================================================================
FASE 2 (parte B) — PINCELES, REFERENCIA, SIMETRÍA RADIAL, DEFORMACIÓN (v4.3)
=====================================================================
NUEVO
- Pinceles Grafito (lápiz tradicional) y Carboncillo (textura): el grano es un patrón fijo de papel, de modo que trazos superpuestos
  comparten textura y se ve igual con cualquier zoom. Funcionan con presión y también con recortes/máscaras.
- Inclinación del lápiz (tilt): con tableta compatible, inclinar el lápiz ensancha el trazo en Lápiz, Grafito y Carboncillo. Casilla en «Pincel vectorial».
- Imagen de referencia: Archivo › Importar imagen de referencia. Se reduce a 1400 px y se guarda dentro del proyecto. Opacidad y «Quitar» en Vista.
  Se ve debajo del dibujo (también al reproducir) y NO se exporta a PNG/SVG.
- Simetría radial: Simetría › Radial, con 2–16 segmentos alrededor del centro del lienzo, con vista previa de los radios.
- Deformación de la selección: Inclinar H, Inclinar V (usan el campo Ángulo) y Perspectiva arriba/abajo (borde lejano al X %).
  Rectángulos y elipses pasan a vector al deformarse. Todo con deshacer.

LIMITES CONOCIDOS
- Grano y Acuarela no se exportan a SVG (salen como color plano translúcido; se avisa al exportar). Para el resultado exacto usa PNG.
- Perspectiva e Inclinar mueven los nodos y sus tiradores; un trazo Bézier con pocos nodos se deforma de forma aproximada (añade nodos si necesitas más fidelidad).
- Inclinación (tilt) probada solo con eventos simulados: no hay tableta real en las pruebas. Grano, Acuarela, recortes y máscaras NO verificados en píxeles.

ESTADO DE LA FASE 2: CERRADA CON ESTAS PENDIENTES EXPLÍCITAS
- Deformación libre arrastrando las 4 esquinas / malla: se hará junto con las mallas del rigging (Fase 6).
- Reorganización del JS en varios archivos: NO realizada. Es una refactorización pura de código que comparte estado en un único bloque;
  hacerla ahora arriesga regresiones sin aportar funciones. Plan: los módulos nuevos de la Fase 3 (animación, timeline, Graph Editor) nacen como
  archivos separados con scripts clásicos (compatibles con abrir index.html sin servidor) y el código antiguo se migra al terminar cada fase.


=====================================================================
FASE 3 (parte A) — ANIMACIÓN PROFESIONAL (v4.4)
=====================================================================
Código nuevo en js/animation.js (script clásico; se carga tras app.js y usa la API window.A2D que expone app.js).
Si animation.js no se cargase, app.js sigue funcionando con la interpolación anterior.

NUEVO
- Interpolación con correspondencia geométrica: ya no exige el mismo número ni tipo de trazos. Empareja trazos por posición, longitud, tamaño,
  tipo, capa y si son cerrados. Ajusta sentido de dibujo y punto de inicio (formas cerradas) para que no se retuerzan. Los trazos sin pareja
  aparecen o desaparecen con fundido. Modo «Automática» (conserva el emparejamiento por orden si es geométricamente razonable) o «Siempre geométrica».
- Corrección manual: «Etiquetar sel.» asigna una etiqueta (1–99) a los trazos seleccionados; dos trazos con la misma etiqueta en fotogramas distintos
  se emparejan primero. Las etiquetas se ven como círculos morados y se guardan en el proyecto.
- Curva Bézier de aceleración + Graph Editor: arrastra los dos tiradores (admite rebote/anticipación), con preajustes y vista del reparto de los intermedios.
  Se usa al elegir «Curva Bézier (Graph Editor)» en la aceleración de Intermedios y de la barra de interpolación. Se guarda en el proyecto.
- Exposición (retención): campo «Expos.» (1–99 pasos) por fotograma. La reproducción y los contadores de duración la respetan. Se ve como «×N» en la regla.
- Marcadores de evento (⚑): etiqueta de texto por fotograma, visible en la regla del timeline.
- X-Sheet: tabla con inicio, nº de trazos, tipo (clave/interm./vacío), exposición y marcador editables; clic en una fila navega al fotograma.
- Copiar/pegar rangos de fotogramas, repetir rango ×N y ciclos «ida y vuelta» (sin duplicar los extremos). Todo con deshacer.
- Validación: exp, mk, mt y curva se sanean al abrir (proyectos anteriores se abren sin cambios).

LIMITES CONOCIDOS
- La exposición aún NO se aplica a la exportación (PNG/GIF/vídeo): se hará en la Fase 7 junto con el resto de la exportación.
- La exposición es por fotograma completo (todas las capas a la vez); no hay retención independiente por capa como en una X-Sheet de Harmony.
- Emparejamiento voraz (no óptimo global) con umbral de distancia: en dibujos muy distintos puede dejar trazos como fundido en vez de morph. Corrígelo con etiquetas.
- La interpolación sigue siendo lineal punto a punto: en giros grandes el trazo puede encogerse durante el movimiento (falta interpolación rígida).
- Probado con pruebas automáticas (emparejamiento, fundido, curva, exposición, X-Sheet, ciclos, marcadores, copiar/pegar, reproducción con retención).
  NO verificado visualmente en navegador: revisa los intermedios en Chrome/Edge.

PENDIENTE EN FASE 3 (parte B)
- Pistas de transformación por capa con fotogramas clave (posición, rotación, escala, opacidad) y curvas por propiedad en el Graph Editor.
- Trayectorias de movimiento visibles y editables. Interpolación rígida (rotación/escala) para evitar el encogimiento.


=====================================================================
FASE 3 (parte B) — PISTAS DE TRANSFORMACIÓN, CURVAS POR PROPIEDAD, TRAYECTORIAS (v4.5)
=====================================================================
NUEVO
- Pistas de transformación por capa: claves con posición (X, Y), rotación, escala (%) y opacidad (%), alrededor de un pivote por capa.
  Entre claves se interpola por propiedad; antes de la primera y después de la última clave se mantiene el valor. Se guardan en el proyecto
  (capa.tr, capa.pv) y se validan al abrir.
- Herramienta Transformar capa (T): arrastrar = mover, Shift+arrastrar = rotar, Alt+arrastrar = escalar. Crea la clave en el fotograma actual.
  El resto de valores se escriben en el panel «Transformación de capa»: ◆ Clave aquí, ✕ Quitar clave, Pivote aquí (centro de la selección), Borrar pista.
- Graph Editor por propiedad: el selector del panel elige «Global» o «Pista · X/Y/Rotación/Escala/Opacidad». En una pista edita la curva Bézier del tramo
  que parte de la clave del fotograma actual (cada propiedad tiene su propia curva). Todo con deshacer.
- Trayectoria de movimiento: línea discontinua con rombos numerados en cada clave y un anillo en la posición actual (casilla «Mostrar trayectoria»).
- Las transformaciones se aplican al reproducir, en «Vista final», en PNG (fotograma actual) y en SVG (grupo <g transform> por capa).
  Funcionan junto con recortes, máscaras y papel cebolla (cada fotograma de cebolla usa su propio valor).
- Interpolación rígida (casilla en Intermedios, activa por defecto): descompone el movimiento en rotación + escala + traslación para que un giro
  no encoja el trazo (giro de 90°: longitud 200 en vez de 141); el resto de la deformación se mezcla linealmente. En t=1 coincide con el dibujo final.

REGLAS DE USO
- Al editar (sin «Vista final») las capas se ven sin transformar para dibujar en su espacio local. Con «Vista final» activa y alguna capa transformada,
  las herramientas de dibujo/edición se bloquean con un aviso (evita dibujar en un espacio desplazado). La herramienta Transformar siempre muestra el resultado.
- Las claves se anclan al NÚMERO de fotograma: si insertas o repites fotogramas antes de una clave (p. ej. con la X-Sheet), la clave no se desplaza.

LIMITES CONOCIDOS
- La exportación de secuencias, GIF y vídeo (Fase 7) aplicará estas pistas y la exposición; hoy solo están en PNG/SVG del fotograma actual.
- El pivote es fijo por capa (no animado) y no hay manipulador visual de pivote: se fija con «Pivote aquí».
- No hay pistas para grupos de capas (solo por capa) ni «pegging» jerárquico: llegará con el rigging (Fase 6).
- Probado con pruebas automáticas (evaluación, panel, herramienta, bloqueo, rígida, Graph Editor, validación, SVG). NO verificado visualmente
  en navegador: revisa en Chrome/Edge el aspecto de recortes/máscaras con capas transformadas.

ESTADO DE LA FASE 3: CERRADA.


=====================================================================
FASE 4 — ASISTENTE INTELIGENTE DE TRAZOS (v4.6)
=====================================================================
Código nuevo en js/assistant.js (script clásico). El asistente de calco original NO se ha eliminado: queda intacto y vuelve a funcionar
desactivando «Activar» en el panel nuevo. El asistente inteligente reutiliza sus controles (Anterior/Siguiente/Ambos, opacidad, ◀▶ Trazo, invertir).
Importante: solo dibuja guías en la capa de superposición; NUNCA modifica el dibujo (comprobado en las pruebas).

NUEVO
- El «trazo siguiente» ya no se cuenta por orden: cada trazo de la referencia se empareja geométricamente (posición, longitud, tamaño; las etiquetas
  de Intermedios tienen prioridad) con lo que ya has dibujado. Los cubiertos se atenúan y el objetivo es el primero pendiente. Si dibujas el 3.º antes
  que el 2.º, el asistente sigue indicando el 2.º.
- Objetivo muy visible: trazo grueso, flechas de dirección (25/50/75 %), punto de INICIO (verde) y de FIN (rojo) con etiquetas.
- Predicción de movimiento: línea de puntos con la posición esperada del trazo y flecha desde la referencia. Usa el desplazamiento medio de los trazos
  ya dibujados en este fotograma; si aún no hay ninguno, extrapola la tendencia de los dos fotogramas anteriores (o siguientes).
- Continuidad/empalmes: si en la referencia el objetivo toca a otro trazo ya dibujado, se marca el punto exacto donde debe empezar o cerrar («empalma aquí»).
- Trazos que faltan: resaltados en rojo con «!» (casilla) y listados en las sugerencias («Faltan 1 de 3 trazos…: 2»). Avisa de trazos nuevos sin equivalente.
- Guías de posición y proporción: caja de la referencia (desplazada por la predicción) y caja de tu dibujo; avisa si es más alto/ancho/bajo/estrecho >8 %.
- Sugerencias de continuidad del movimiento: marca con «!» naranja los trazos que se desvían >35 px de la tendencia (posible salto).
- Control manual: botones ◀ ▶ Trazo del panel y teclas [ y ] para retroceder/avanzar/saltar (límites respetados); invertir dirección.
- Configuración: color de referencia anterior, siguiente y objetivo (se guardan como preferencia del navegador), opacidad de guía y tolerancia (20–250 px).

LIMITES CONOCIDOS
- Emparejamiento voraz por posición/tamaño: si el movimiento entre fotogramas supera la tolerancia, el trazo se considerará nuevo (sube la tolerancia).
- La predicción es solo traslación (no rota ni escala); se basa en el centroide de cada trazo.
- No lee la intención del dibujo (no es IA generativa): es análisis geométrico. La IA real llega en la Fase 5.
- Probado con pruebas automáticas (orden de dibujo, predicción, tendencia, empalmes, faltantes, proporción, saltos, control manual, no-modificación, vuelta al modo simple).
  NO verificado visualmente en navegador: revisa tamaños y legibilidad de las marcas en Chrome/Edge.


=====================================================================
FASE 5 — IA GENERATIVA: APLAZADA (a petición del usuario)
=====================================================================
No se ha implementado. El panel de IA actual sigue siendo el modo local que solo desplaza geometría y NO es IA generativa (así se indica en el propio
panel). Cuando se retome: servidor externo con endpoints definidos, validación de respuestas, errores claros y varios proveedores; sin conexión,
mostrar «función no disponible» en lugar de simulaciones.

=====================================================================
FASE 6 (parte A) — RIGGING 2D POR HUESOS (v4.7)
=====================================================================
Código nuevo en js/rig.js; el núcleo (render, SVG, guardado, deshacer, validación) está en app.js. Es un rig de RECORTES: huesos con jerarquía y las
CAPAS vinculadas a huesos. Cada parte sigue dibujándose cuadro a cuadro y el esqueleto la mueve encima (se combina con las pistas de transformación).

NUEVO
- Herramienta Hueso (J): arrastra para crear un hueso; si empiezas cerca del extremo de otro, se conecta como hijo (articulación). Jerarquía en árbol.
- Panel «Esqueleto»: nombre, largo, ángulo de reposo, hueso padre (sin ciclos), límites de rotación (mín/máx), rotación en el fotograma actual,
  clave de rotación / quitar clave, eliminar hueso (con sus hijos; desvincula capas).
- Herramienta Pose (M): arrastra un hueso para rotarlo (cinemática directa): calcula la rotación local descontando la de los ancestros y respeta los límites.
- Animación: la rotación de cada hueso se interpola entre claves, con curva Bézier propia por tramo (Graph Editor → «Hueso · rotación»).
- Vincular capas: «Capa activa vinculada a…». La capa sigue la cadena de huesos (rotaciones sobre cada articulación) y, además, su propia pista de transformación.
  Visible en «Vista final», al reproducir, con la herramienta Pose, en PNG y en SVG (la cadena de huesos va como transform).
- Poses reutilizables: guardar la pose actual (ángulos de todos los huesos), aplicarla en cualquier fotograma (crea claves) y borrarla.
- Guardar configuraciones: Exportar/Importar esqueleto (.rig.json) con huesos, poses y vínculos por nombre de capa (sin las claves de animación).
- El esqueleto, las claves, las poses y los vínculos se guardan en el proyecto, entran en deshacer/rehacer y se validan al abrir
  (ciclos, ids duplicados, padres inexistentes, rangos, poses con huesos inexistentes).

LIMITES CONOCIDOS (pendiente en la parte B de la Fase 6)
- No hay mallas ni deformación de trazos (solo transformación rígida por capa): la deformación por malla queda pendiente.
- Cada capa se vincula a UN hueso (no hay pesos entre varios huesos).
- No hay cinemática inversa ni controladores personalizados (sliders que muevan varios huesos); los límites de rotación sí existen.
- Las expresiones faciales se resuelven hoy dibujando cuadro a cuadro o con poses; no hay un sistema específico de expresiones.
- Las claves de rotación se anclan al número de fotograma (igual que las pistas de capa).
- Probado con pruebas automáticas (creación/conexión, FK, Pose, límites, interpolación, Graph Editor, vínculo, composición, poses, SVG, export/import,
  deshacer, guardado, validación). NO verificado visualmente en navegador: revisa el aspecto del esqueleto y la pose en Chrome/Edge.


=====================================================================
V4.9 — REDISEÑO DE INTERFAZ (estilo Blender / Adobe / Clip Studio)
=====================================================================
- Iconos SVG propios (vectoriales, se adaptan al tema) en herramientas, transporte, capas y timeline. Se acabaron los símbolos de texto.
- Barra de herramientas agrupada (selección · dibujo · formas · transformación · mano) con muestra de color actual abajo.
- Panel derecho con PESTAÑAS: Herramienta · Animar · Asistentes · Rig. La pestaña Rig se abre sola al elegir Hueso/Pose.
- Secciones plegables con flecha, deslizadores y campos con estilo unificado, scrollbars finas.
- Separadores arrastrables: ancho del panel derecho y alto del timeline (se recuerdan).
- Timeline: cabezal azul resaltado, filas de capas con ojo/candado en SVG, grupos con carpeta, claves con borde.
- Menús con atajos alineados a la derecha. Lienzo sobre fondo punteado tipo visor.
- Corregidas variables CSS rotas del X-Sheet. Todos los IDs y funciones anteriores se conservan; los proyectos guardados abren igual.
- Archivos tocados: index.html, css/styles.css, js/app.js (solo iconos), js/ui.js (nuevo).


=====================================================================
V5.0 — CÓDIGO MODULAR + PLUMA ESTILO ILLUSTRATOR
=====================================================================
- app.js (460 líneas en bloques densos) se dividió en ~35 archivos por responsabilidad: core/ render/ tools/ ui/ features/ io/.
  El CSS se dividió en 8 archivos. Todo el código está formateado (Prettier) y cada archivo lleva un comentario de cabecera.
  Guía completa: docs/ARQUITECTURA.md. No cambia el modo de uso: se abre index.html directamente.
- Nueva herramienta Pluma (js/tools/pen.js): esquina/suave, Shift 45°, Alt para romper tirador, Espacio para mover el punto,
  Ctrl para mover puntos, cerrar arrastrando, continuar y unir trazos, añadir/quitar punto, convertir esquina/suave,
  Retroceso borra el último punto, cursores que indican la acción, vista previa elástica con simetría.
- Los iconos viven en js/ui/icons.js (un solo lugar para añadir o cambiar iconos).
