# Arquitectura de 2D Animator (v5.1 modular)

Abre `index.html` con doble clic (Chrome/Edge). **No necesita servidor ni compilar nada.**

## Estructura

```
index.html            Diseño de la interfaz (menús, herramientas, paneles, timeline) y orden de carga
css/
  base.css            Variables (rampa de grises para los temas, acento), reset, scrollbars
  layout.css          Rejilla principal y separadores
  menubar.css         Barra de menús
  toolbar.css         Barra de herramientas vertical
  canvas.css          Zona de dibujo (pestañas superiores, escenario, papel)
  panels.css          Panel derecho: pestañas, secciones, formularios, botones
  timeline.css        Línea de tiempo
  dialogs.css         X-Sheet, Graph Editor y lista de huesos
  start.css           Pantalla de inicio (resoluciones), barra de estado, tooltips y controles
js/
  main.js             Arranque + API pública window.A2D
  core/               Estado, historial (deshacer), geometría, reproducción, acciones de edición
  render/             Pinceles, dibujo por capas, lienzo y superposición (nodos, guías)
  tools/              Una herramienta por archivo + entrada de puntero
  ui/                 Iconos, timeline, paneles, temas, zoom, atajos, separadores
  features/           Intermedios, IA local, referencia, animación (pistas), asistente vectorial, rig
  io/                 Exportar (SVG/PNG/JSON), validar y abrir proyectos
docs/                 Esta guía
```

## Cómo se conectan los archivos

Son **scripts clásicos** cargados en orden (los módulos ES `import/export` no funcionan al abrir
archivos con `file://`). Los archivos de `core/`, `render/`, `tools/`, `ui/`, `io/` y `main.js`
comparten el mismo ámbito global (`S`, `F()`, `L()`, `render()`, `all()`, `dirty()`…), igual que
cuando estaban en un solo archivo. Cada archivo empieza con un comentario que explica **qué hace**
y **de qué depende**. El orden de carga está en `index.html`, agrupado por comentarios.

Los módulos de `features/animation.js`, `vector-assistant.js` y `rig.js` son independientes: solo
usan la API pública `window.A2D` (definida en `main.js`) y añaden sus propios paneles.

## Pantalla de inicio y resoluciones (v5.2)

`js/ui/start-dialog.js` muestra al arrancar (y en Archivo › Nuevo proyecto) un menú con resoluciones
predefinidas (`RES_PRESETS`), tamaño personalizado (8192 px máx.), FPS y nombre. También ofrece continuar
el borrador automático o abrir un archivo. Recuerda la última resolución en `localStorage` (`2dLastRes`).
`js/ui/chrome.js` añade menús con clic, tooltips con atajo y la barra de estado inferior.

## Cómo añadir una herramienta

1. Añade el botón en `index.html` (`<button class="tool" data-tool="mi">`) y el icono en `js/ui/icons.js`.
2. Registra nombre, atajo y ayuda en `js/tools/tool-manager.js` (`NAMES`, `KEYS`, `TIPS`).
3. Crea `js/tools/mi-herramienta.js` y cárgalo en `index.html` antes de `pointer-input.js`.
4. Desde `js/tools/pointer-input.js` llama a tu herramienta en `pointerdown` / `pointermove` / `finish`.

## Herramienta Pluma (`js/tools/pen.js`)

| Acción | Resultado |
|---|---|
| Clic | Punto de esquina |
| Clic y arrastrar | Punto suave (tiradores simétricos) |
| Shift | Ángulos de 45° (puntos y tiradores) |
| Alt mientras arrastras | Rompe la simetría: solo se mueve el tirador de salida |
| Alt + arrastrar desde el último punto | Saca un tirador nuevo (esquina después de una curva) |
| Espacio mientras arrastras | Mueve el punto que estás colocando |
| Ctrl / Cmd + arrastrar | Selección directa temporal: mueve puntos y tiradores |
| Clic en el primer punto | Cierra el trazo (arrastrar ajusta sus tiradores) |
| Clic en el último punto | Retrae su tirador de salida (curva → esquina) |
| Retroceso / Supr / Ctrl+Z | Borra el último punto |
| Imán (panel «Borrador e imán») | Ajusta puntos a otros trazos, guías y cuadrícula |
| «Rellenar al dibujar» | Al cerrar el trazo crea un relleno debajo del contorno |
| Enter · Esc | Termina abierto · cancela |
| Clic en un tramo del trazo seleccionado | Añade un punto |
| Clic en un punto del trazo seleccionado | Lo elimina |
| Alt + clic en un punto | Suave → esquina · Alt + arrastrar: esquina → suave |
| Clic en el extremo de un trazo abierto | Continúa dibujándolo |
| Clic en el extremo de otro trazo | Los une |

El cursor cambia según la acción (pluma simple, `o` cerrar, `/` continuar, `+` añadir, `−` quitar, `^` convertir).

## Herramientas nuevas en v5.1

| Herramienta | Archivo | Resumen |
|---|---|---|
| Nodos (A) | `tools/node-edit.js` | Multiselección, marquesina, arrastrar tramos, suave↔esquina, cortar, cerrar, invertir, simplificar |
| Tijeras (C) | `tools/node-edit.js` | Corta un trazo donde se hace clic |
| Selección (V) | `tools/selection-tools.js` | Asas de escala/rotación, Alt = duplicar, marquesina, copiar/pegar, orden, alinear, flechas |
| Borrador (E) | `tools/eraser.js` | Modo «parte del trazo» (corta) o «trazo completo», tamaño propio |
| Polígono (N), Estrella (W) | `tools/extra-tools.js` | Bézier cerrado editable |
| Cuentagotas (I), Zoom (Z) | `tools/extra-tools.js` | Toma atributos / zoom a zona |
| Imán | `tools/snap.js` | Puntos, guías de alineación y cuadrícula |

Atajos: Ctrl+C/X/V/D, Ctrl+] / [ (orden), Ctrl+0 ajustar, Ctrl+1 100 %, Ctrl+± zoom, flechas (Shift ×10).

## Formato del código

Se usa Prettier (`.prettierrc.json`): `npx prettier --write "js/**/*.js" "css/*.css" index.html`.
